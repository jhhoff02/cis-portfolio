﻿/*
 * Grading ID: A9703
 * Program 1
 * Due: September 27, 2016
 * CIS 199-01
 * This program contains labels, textbox inputs, and a button on a form. 
 * The user enters information about a paint job, and clicks the calculate button. 
 * The output labels display formatted calculations based on the user input.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }

        private void calculateBtn_Click(object sender, EventArgs e)
        {
            const float SQUARE_FEET = 275f; //Named constant that holds the square feet painted per 1 gallon of paint
            const float WAGE = 12.50f; //Named constant that holds wage per hour of the painter
            const float HOURS_PER_GAL = 8f; //Named constant that holds number of labor hours per 1 gallon of paint
            float parsedSqFt; //Float variable that stores the square feet after the TryParse
            int parsedCoats; //Int variable that stores the number of coats after the TryParse
            float parsedPrice; //Float variable that stores the price after the TryParse

            float totalSqFtResult; //Float variable that stores the calculated value for Total Square Feet
            int gallonsNeededResult; //Int variable that stores the calculated value for Gallons Needed
            float laborHoursResult; //Float variable that stores the calculated value for Labor Hours
            float paintCostResult; //Float variable that stores the calculated value for Paint Cost
            float laborCostResult; //Float variable that stores the calculated value for Labor Cost
            float totalCostResult; //Float variable that stores the calculated value for Total Cost


           

            //Tries to parse coatsTextBox and store it as a float in parsedCoats. Displays error message if it fails.
            if (int.TryParse(coatsTextBox.Text, out parsedCoats))
            {
                //Tries to parse sqFtTextBox and store it as a float in parsedSqFt. Displays error message if it fails.
                if (float.TryParse(sqFtTextBox.Text, out parsedSqFt))
                {
                    //Tries to parse priceTextBox and store it as a float in parsedPrice. Displays error message if it fails.
                    if (float.TryParse(priceTextBox.Text, out parsedPrice))
                    {
                        //Calculations Below
                        totalSqFtResult = parsedSqFt * parsedCoats;
                        gallonsNeededResult = (int)Math.Ceiling(totalSqFtResult / SQUARE_FEET);
                        laborHoursResult = (totalSqFtResult/ SQUARE_FEET) * HOURS_PER_GAL;
                        paintCostResult = gallonsNeededResult * parsedPrice;
                        laborCostResult = laborHoursResult * WAGE;
                        totalCostResult = paintCostResult + laborCostResult;

                        //Formatting and Display code below
                        totalSqFtOutputLbl.Text = totalSqFtResult.ToString("F1");
                        gallonsNeededOutputLbl.Text = gallonsNeededResult.ToString("N0");
                        laborHrsOutputLbl.Text = laborHoursResult.ToString("F1");
                        paintCostOutputLbl.Text = paintCostResult.ToString("C2");
                        laborCostOutputLbl.Text = laborCostResult.ToString("C2");
                        totalCostOutputLbl.Text = totalCostResult.ToString("C2");
                    }
                    else
                    {
                        MessageBox.Show("This is not a valid input for Price per Gallon");
                    };
                }
                else
                {
                    MessageBox.Show("This is not a valid input for Square Feet");
                };
            }
            else
            {
                MessageBox.Show("This is not a valid input for Number of Coats");
            };
        }
    }
}
