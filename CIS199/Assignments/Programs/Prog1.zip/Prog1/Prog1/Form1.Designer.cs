﻿namespace Prog1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateBtn = new System.Windows.Forms.Button();
            this.titleLbl = new System.Windows.Forms.Label();
            this.sqFtLbl = new System.Windows.Forms.Label();
            this.coatsLbl = new System.Windows.Forms.Label();
            this.priceLbl = new System.Windows.Forms.Label();
            this.totalSqFtOutputLbl = new System.Windows.Forms.Label();
            this.gallonsNeededOutputLbl = new System.Windows.Forms.Label();
            this.laborHrsOutputLbl = new System.Windows.Forms.Label();
            this.paintCostOutputLbl = new System.Windows.Forms.Label();
            this.laborCostOutputLbl = new System.Windows.Forms.Label();
            this.totalCostOutputLbl = new System.Windows.Forms.Label();
            this.totalSqFtLbl = new System.Windows.Forms.Label();
            this.gallonsNeededLbl = new System.Windows.Forms.Label();
            this.laborHrsLbl = new System.Windows.Forms.Label();
            this.paintCostLbl = new System.Windows.Forms.Label();
            this.laborCostLbl = new System.Windows.Forms.Label();
            this.totalCostLbl = new System.Windows.Forms.Label();
            this.sqFtTextBox = new System.Windows.Forms.TextBox();
            this.coatsTextBox = new System.Windows.Forms.TextBox();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(85, 381);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(75, 23);
            this.calculateBtn.TabIndex = 0;
            this.calculateBtn.Text = "Calculate";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Location = new System.Drawing.Point(182, 31);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(155, 17);
            this.titleLbl.TabIndex = 1;
            this.titleLbl.Text = "Paint Project Calculator";
            // 
            // sqFtLbl
            // 
            this.sqFtLbl.AutoSize = true;
            this.sqFtLbl.Location = new System.Drawing.Point(82, 106);
            this.sqFtLbl.Name = "sqFtLbl";
            this.sqFtLbl.Size = new System.Drawing.Size(86, 17);
            this.sqFtLbl.TabIndex = 2;
            this.sqFtLbl.Text = "Square Feet";
            // 
            // coatsLbl
            // 
            this.coatsLbl.AutoSize = true;
            this.coatsLbl.Location = new System.Drawing.Point(71, 202);
            this.coatsLbl.Name = "coatsLbl";
            this.coatsLbl.Size = new System.Drawing.Size(114, 17);
            this.coatsLbl.TabIndex = 3;
            this.coatsLbl.Text = "Number of Coats";
            // 
            // priceLbl
            // 
            this.priceLbl.AutoSize = true;
            this.priceLbl.Location = new System.Drawing.Point(71, 300);
            this.priceLbl.Name = "priceLbl";
            this.priceLbl.Size = new System.Drawing.Size(110, 17);
            this.priceLbl.TabIndex = 4;
            this.priceLbl.Text = "Price per Gallon";
            // 
            // totalSqFtOutputLbl
            // 
            this.totalSqFtOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSqFtOutputLbl.Location = new System.Drawing.Point(373, 100);
            this.totalSqFtOutputLbl.Name = "totalSqFtOutputLbl";
            this.totalSqFtOutputLbl.Size = new System.Drawing.Size(100, 23);
            this.totalSqFtOutputLbl.TabIndex = 5;
            // 
            // gallonsNeededOutputLbl
            // 
            this.gallonsNeededOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsNeededOutputLbl.Location = new System.Drawing.Point(373, 153);
            this.gallonsNeededOutputLbl.Name = "gallonsNeededOutputLbl";
            this.gallonsNeededOutputLbl.Size = new System.Drawing.Size(100, 23);
            this.gallonsNeededOutputLbl.TabIndex = 6;
            // 
            // laborHrsOutputLbl
            // 
            this.laborHrsOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborHrsOutputLbl.Location = new System.Drawing.Point(373, 201);
            this.laborHrsOutputLbl.Name = "laborHrsOutputLbl";
            this.laborHrsOutputLbl.Size = new System.Drawing.Size(100, 23);
            this.laborHrsOutputLbl.TabIndex = 7;
            // 
            // paintCostOutputLbl
            // 
            this.paintCostOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintCostOutputLbl.Location = new System.Drawing.Point(373, 259);
            this.paintCostOutputLbl.Name = "paintCostOutputLbl";
            this.paintCostOutputLbl.Size = new System.Drawing.Size(100, 23);
            this.paintCostOutputLbl.TabIndex = 8;
            // 
            // laborCostOutputLbl
            // 
            this.laborCostOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborCostOutputLbl.Location = new System.Drawing.Point(373, 312);
            this.laborCostOutputLbl.Name = "laborCostOutputLbl";
            this.laborCostOutputLbl.Size = new System.Drawing.Size(100, 23);
            this.laborCostOutputLbl.TabIndex = 9;
            // 
            // totalCostOutputLbl
            // 
            this.totalCostOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostOutputLbl.Location = new System.Drawing.Point(373, 365);
            this.totalCostOutputLbl.Name = "totalCostOutputLbl";
            this.totalCostOutputLbl.Size = new System.Drawing.Size(100, 23);
            this.totalCostOutputLbl.TabIndex = 10;
            // 
            // totalSqFtLbl
            // 
            this.totalSqFtLbl.AutoSize = true;
            this.totalSqFtLbl.Location = new System.Drawing.Point(245, 101);
            this.totalSqFtLbl.Name = "totalSqFtLbl";
            this.totalSqFtLbl.Size = new System.Drawing.Size(122, 17);
            this.totalSqFtLbl.TabIndex = 11;
            this.totalSqFtLbl.Text = "Total Square Feet";
            // 
            // gallonsNeededLbl
            // 
            this.gallonsNeededLbl.AutoSize = true;
            this.gallonsNeededLbl.Location = new System.Drawing.Point(257, 154);
            this.gallonsNeededLbl.Name = "gallonsNeededLbl";
            this.gallonsNeededLbl.Size = new System.Drawing.Size(110, 17);
            this.gallonsNeededLbl.TabIndex = 12;
            this.gallonsNeededLbl.Text = "Gallons Needed";
            // 
            // laborHrsLbl
            // 
            this.laborHrsLbl.AutoSize = true;
            this.laborHrsLbl.Location = new System.Drawing.Point(280, 207);
            this.laborHrsLbl.Name = "laborHrsLbl";
            this.laborHrsLbl.Size = new System.Drawing.Size(87, 17);
            this.laborHrsLbl.TabIndex = 13;
            this.laborHrsLbl.Text = "Labor Hours";
            // 
            // paintCostLbl
            // 
            this.paintCostLbl.AutoSize = true;
            this.paintCostLbl.Location = new System.Drawing.Point(283, 260);
            this.paintCostLbl.Name = "paintCostLbl";
            this.paintCostLbl.Size = new System.Drawing.Size(72, 17);
            this.paintCostLbl.TabIndex = 14;
            this.paintCostLbl.Text = "Paint Cost";
            // 
            // laborCostLbl
            // 
            this.laborCostLbl.AutoSize = true;
            this.laborCostLbl.Location = new System.Drawing.Point(283, 313);
            this.laborCostLbl.Name = "laborCostLbl";
            this.laborCostLbl.Size = new System.Drawing.Size(77, 17);
            this.laborCostLbl.TabIndex = 15;
            this.laborCostLbl.Text = "Labor Cost";
            // 
            // totalCostLbl
            // 
            this.totalCostLbl.AutoSize = true;
            this.totalCostLbl.Location = new System.Drawing.Point(283, 366);
            this.totalCostLbl.Name = "totalCostLbl";
            this.totalCostLbl.Size = new System.Drawing.Size(72, 17);
            this.totalCostLbl.TabIndex = 16;
            this.totalCostLbl.Text = "Total Cost";
            // 
            // sqFtTextBox
            // 
            this.sqFtTextBox.Location = new System.Drawing.Point(74, 139);
            this.sqFtTextBox.Name = "sqFtTextBox";
            this.sqFtTextBox.Size = new System.Drawing.Size(100, 22);
            this.sqFtTextBox.TabIndex = 17;
            // 
            // coatsTextBox
            // 
            this.coatsTextBox.Location = new System.Drawing.Point(74, 232);
            this.coatsTextBox.Name = "coatsTextBox";
            this.coatsTextBox.Size = new System.Drawing.Size(100, 22);
            this.coatsTextBox.TabIndex = 18;
            // 
            // priceTextBox
            // 
            this.priceTextBox.Location = new System.Drawing.Point(74, 328);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(100, 22);
            this.priceTextBox.TabIndex = 19;
            // 
            // Program1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 441);
            this.Controls.Add(this.priceTextBox);
            this.Controls.Add(this.coatsTextBox);
            this.Controls.Add(this.sqFtTextBox);
            this.Controls.Add(this.totalCostLbl);
            this.Controls.Add(this.laborCostLbl);
            this.Controls.Add(this.paintCostLbl);
            this.Controls.Add(this.laborHrsLbl);
            this.Controls.Add(this.gallonsNeededLbl);
            this.Controls.Add(this.totalSqFtLbl);
            this.Controls.Add(this.totalCostOutputLbl);
            this.Controls.Add(this.laborCostOutputLbl);
            this.Controls.Add(this.paintCostOutputLbl);
            this.Controls.Add(this.laborHrsOutputLbl);
            this.Controls.Add(this.gallonsNeededOutputLbl);
            this.Controls.Add(this.totalSqFtOutputLbl);
            this.Controls.Add(this.priceLbl);
            this.Controls.Add(this.coatsLbl);
            this.Controls.Add(this.sqFtLbl);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.calculateBtn);
            this.Name = "Program1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateBtn;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Label sqFtLbl;
        private System.Windows.Forms.Label coatsLbl;
        private System.Windows.Forms.Label priceLbl;
        private System.Windows.Forms.Label totalSqFtOutputLbl;
        private System.Windows.Forms.Label gallonsNeededOutputLbl;
        private System.Windows.Forms.Label laborHrsOutputLbl;
        private System.Windows.Forms.Label paintCostOutputLbl;
        private System.Windows.Forms.Label laborCostOutputLbl;
        private System.Windows.Forms.Label totalCostOutputLbl;
        private System.Windows.Forms.Label totalSqFtLbl;
        private System.Windows.Forms.Label gallonsNeededLbl;
        private System.Windows.Forms.Label laborHrsLbl;
        private System.Windows.Forms.Label paintCostLbl;
        private System.Windows.Forms.Label laborCostLbl;
        private System.Windows.Forms.Label totalCostLbl;
        private System.Windows.Forms.TextBox sqFtTextBox;
        private System.Windows.Forms.TextBox coatsTextBox;
        private System.Windows.Forms.TextBox priceTextBox;
    }
}

