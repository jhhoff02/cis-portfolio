﻿namespace Prog2
{
    partial class program2Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLbl = new System.Windows.Forms.Label();
            this.creditHoursLbl = new System.Windows.Forms.Label();
            this.nameLbl = new System.Windows.Forms.Label();
            this.creditHrsInputBox = new System.Windows.Forms.TextBox();
            this.lastNameInputBox = new System.Windows.Forms.TextBox();
            this.registrationLbl = new System.Windows.Forms.Label();
            this.registrationOutputLbl = new System.Windows.Forms.Label();
            this.determineApptBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.titleLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.titleLbl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.titleLbl.Location = new System.Drawing.Point(121, 9);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(187, 22);
            this.titleLbl.TabIndex = 0;
            this.titleLbl.Text = "Spring 2017 Registration";
            // 
            // creditHoursLbl
            // 
            this.creditHoursLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creditHoursLbl.Location = new System.Drawing.Point(1, 81);
            this.creditHoursLbl.Name = "creditHoursLbl";
            this.creditHoursLbl.Size = new System.Drawing.Size(145, 31);
            this.creditHoursLbl.TabIndex = 1;
            this.creditHoursLbl.Text = "Completed Credit Hours (prior to Fall 2016)";
            this.creditHoursLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(180, 99);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(67, 13);
            this.nameLbl.TabIndex = 2;
            this.nameLbl.Text = "Last Name";
            this.nameLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // creditHrsInputBox
            // 
            this.creditHrsInputBox.Location = new System.Drawing.Point(16, 115);
            this.creditHrsInputBox.Name = "creditHrsInputBox";
            this.creditHrsInputBox.Size = new System.Drawing.Size(100, 20);
            this.creditHrsInputBox.TabIndex = 3;
            // 
            // lastNameInputBox
            // 
            this.lastNameInputBox.Location = new System.Drawing.Point(162, 115);
            this.lastNameInputBox.Name = "lastNameInputBox";
            this.lastNameInputBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameInputBox.TabIndex = 4;
            // 
            // registrationLbl
            // 
            this.registrationLbl.AutoSize = true;
            this.registrationLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registrationLbl.Location = new System.Drawing.Point(13, 178);
            this.registrationLbl.Name = "registrationLbl";
            this.registrationLbl.Size = new System.Drawing.Size(183, 13);
            this.registrationLbl.TabIndex = 5;
            this.registrationLbl.Text = "Your Registration Appointment:";
            // 
            // registrationOutputLbl
            // 
            this.registrationOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.registrationOutputLbl.Location = new System.Drawing.Point(13, 201);
            this.registrationOutputLbl.Name = "registrationOutputLbl";
            this.registrationOutputLbl.Size = new System.Drawing.Size(201, 37);
            this.registrationOutputLbl.TabIndex = 6;
            // 
            // determineApptBtn
            // 
            this.determineApptBtn.Location = new System.Drawing.Point(298, 106);
            this.determineApptBtn.Name = "determineApptBtn";
            this.determineApptBtn.Size = new System.Drawing.Size(99, 36);
            this.determineApptBtn.TabIndex = 7;
            this.determineApptBtn.Text = "Tell Me When to Register";
            this.determineApptBtn.UseVisualStyleBackColor = true;
            this.determineApptBtn.Click += new System.EventHandler(this.determineApptBtn_Click);
            // 
            // program2Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 304);
            this.Controls.Add(this.determineApptBtn);
            this.Controls.Add(this.registrationOutputLbl);
            this.Controls.Add(this.registrationLbl);
            this.Controls.Add(this.lastNameInputBox);
            this.Controls.Add(this.creditHrsInputBox);
            this.Controls.Add(this.nameLbl);
            this.Controls.Add(this.creditHoursLbl);
            this.Controls.Add(this.titleLbl);
            this.Name = "program2Form";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Label creditHoursLbl;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.TextBox creditHrsInputBox;
        private System.Windows.Forms.TextBox lastNameInputBox;
        private System.Windows.Forms.Label registrationLbl;
        private System.Windows.Forms.Label registrationOutputLbl;
        private System.Windows.Forms.Button determineApptBtn;
    }
}

