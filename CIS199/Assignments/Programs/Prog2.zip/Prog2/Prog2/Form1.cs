﻿/*
 * Grading ID: A9703
 * Program 2
 * Due: October 16, 2016
 * CIS 199-01
 * This program contains labels, textbox inputs, and a button on a form. 
 * The student enters their last name and credit hours earned before Fall 2016, 
 * and the program displays the earliest date and time the student can register
 * for Spring 2017 classes.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class program2Form : Form
    {

        public program2Form()
        {
            InitializeComponent();
        }

        private void determineApptBtn_Click(object sender, EventArgs e)
        {
            const float LOW_CREDIT_HOURS = 30.0f; //Named constant that holds a value for 30 credit hours
            const float MED_CREDIT_HOURS = 60.0f; //Named constant that holds a value for 60 credit hours
            const float HIGH_CREDIT_HOURS = 90.0f; //Named constant that holds a value for 90 credit hours
            const string REG_TIME_EARLY = "8:30"; // String constant that stores an early registration time
            const string REG_TIME_2ND_EARLY = "10.00"; // String constant that stores the second earliest registration time
            const string REG_TIME_3RD_EARLY = "11:30"; // String constant that stores the third earliest registration time
            const string REG_TIME_2ND_LATE = "2:00"; // String constant that stores the second latest registration time
            const string REG_TIME_LATE = "4:00"; // String constant that stores a late registration time
            const string REG_DAY_SENIOR = "Friday, November 4th"; // String constant that stores the earliest registration day
            const string REG_DAY_JUNIOR = "Monday, November 7th"; // String constant that stores the second earliest registration day
            const string REG_DAY_SOPHOMORE_1ST = "Wednesday, November 9th"; // String constant that stores the third earliest registration day
            const string REG_DAY_SOPHOMORE_2ND = "Thursday, November 10th"; // String constant that stores the third latest registration day
            const string REG_DAY_FRESHMAN_1ST = "Friday, November 11th"; // String constant that stores the second latest registration day
            const string REG_DAY_FRESHMAN_2ND = "Monday, November 14th"; // String constant that stores a late registration day
            string determinedClass; // String variable that will store the student's class level once it is determined
            string determinedTime; // String variable that will store the time the student should register
            string determinedDay; // String variable that will store the day the student should register
            char lastNameStart; // Char variable that will store the first character of the student's last name
            float parsedCreditHrs; // Float variable that stores the credit hours input after the TryParse


            //Tries to parse creditHrsInputBox and store it as a float in parsedCreditHrs. Displays error message if it fails.
            if (float.TryParse(creditHrsInputBox.Text, out parsedCreditHrs) && parsedCreditHrs > 0)
            {
                lastNameStart = Char.ToLower(lastNameInputBox.Text[0]);
                //Makes sure value for name input is not empty. Displays error message if it fails.
                if (lastNameInputBox.Text.Length > 0 && Char.IsLetter(lastNameStart))
                {
                    if(parsedCreditHrs >= MED_CREDIT_HOURS)
                    {
                        //Determine registration day and then display output
                        if (lastNameStart <= 'd')
                        {
                            determinedTime = REG_TIME_2ND_LATE;
                        } else if (lastNameStart <= 'i')
                        {
                            determinedTime = REG_TIME_LATE;
                        } else if (lastNameStart <= 'o')
                        {
                            determinedTime = REG_TIME_EARLY;
                        } else if (lastNameStart <= 's')
                        {
                            determinedTime = REG_TIME_2ND_EARLY;
                        } else
                        {
                            determinedTime = REG_TIME_3RD_EARLY;
                        }
                        if (parsedCreditHrs >= HIGH_CREDIT_HOURS)
                        {
                            determinedClass = "Senior";
                            determinedDay = REG_DAY_SENIOR;
                            registrationOutputLbl.Text = determinedClass + ": " + determinedDay + " at " + determinedTime;

                        }
                        else
                        {
                            determinedClass = "Junior";
                            determinedDay = REG_DAY_JUNIOR;
                            registrationOutputLbl.Text = determinedClass + ": " + determinedDay + " at " + determinedTime;
                        }
                    } else {
                        if ((lastNameStart <= 'b') || (lastNameStart <= 'o' && lastNameStart >= 'm'))
                        {
                            determinedTime = REG_TIME_2ND_EARLY;
                        }
                        else if ((lastNameStart <= 'd') || (lastNameStart <= 'q' && lastNameStart >= 'p'))
                        {
                            determinedTime = REG_TIME_3RD_EARLY;
                        }
                        else if ((lastNameStart <= 'f') || (lastNameStart <= 's' && lastNameStart >= 'r'))
                        {
                            determinedTime = REG_TIME_2ND_LATE;
                        }
                        else if ((lastNameStart <= 'i') || (lastNameStart <= 'v' && lastNameStart >= 't'))
                        {
                            determinedTime = REG_TIME_LATE;
                        }
                        else
                        {
                            determinedTime = REG_TIME_EARLY;
                        }
                        //Determine registration day and then display output
                        if (parsedCreditHrs < LOW_CREDIT_HOURS)
                        {
                            determinedClass = "Freshman";
                            if (lastNameStart <= 'v' && lastNameStart >= 'j')
                            {
                                determinedDay = REG_DAY_FRESHMAN_1ST;
                                registrationOutputLbl.Text = determinedClass + ": " + determinedDay + " at " + determinedTime;
                            } else
                            {
                                determinedDay = REG_DAY_FRESHMAN_2ND;
                                registrationOutputLbl.Text = determinedClass + ": " + determinedDay + " at " + determinedTime;
                            }
                            

                        }
                        else
                        {
                            determinedClass = "Sophomore";
                            if (lastNameStart <= 'v' && lastNameStart >= 'j')
                            {
                                determinedDay = REG_DAY_SOPHOMORE_1ST;
                                registrationOutputLbl.Text = determinedClass + ": " + determinedDay + " at " + determinedTime;
                            } else
                            {
                                determinedDay = REG_DAY_SOPHOMORE_2ND;
                                registrationOutputLbl.Text = determinedClass + ": " + determinedDay + " at " + determinedTime;
                            }
                            
                        }
                    }

                }
                else
                {
                    MessageBox.Show("Please enter a valid name");
                };
            }
            else
            {
                MessageBox.Show("This is not a valid input for Credit Hours");
            };
        }
    }
}
