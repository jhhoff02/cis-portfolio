﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog4
{
    public class LibraryBook
    {
        private string _title; //private integer used as the title parameter of the LibraryBook constructor
        private string _author; //private integer used as the author parameter of the LibraryBook constructor
        private string _publisher; //private integer used as the publisher parameter of the LibraryBook constructor
        private int _copyrightYear; //private integer used as the copyright year parameter of the LibraryBook constructor
        private string _callNumber; //private integer used as the call number parameter of the LibraryBook constructor
        private bool checkedOut = false; //bool variable to track the status of a book (checked out or not)

        public virtual string Title { get { return _title; } set { _title = value; } } //LibraryBook property for getting/setting the Title
        public virtual string Author { get { return _author; } set { _author = value; } } //LibraryBook property for getting/setting the Author
        public virtual string Publisher { get { return _publisher; } set { _publisher = value; } } //LibraryBook property for getting/setting the Publisher
        public virtual int CopyrightYear { //LibraryBook property for getting/setting the CopyrightYear
            get { return _copyrightYear; }
            set {   if (value >= 0)
                    {
                        _copyrightYear = value;
                    } else
                    {
                        _copyrightYear = 2016;
                    }
            }
        }
        public virtual string CallNumber { get { return _callNumber; } set { _callNumber = value; } } //LibraryBook property for getting/setting the CallNumber

        //Pre-conditions: The 5 arguments must be passed into this constructor and match the respective data types. Arguments must be compatible with the property they are altering.
        //Post-conditions: This constructor sets the LibraryBook properties equal to the arguments passed in.
        public LibraryBook(string bookTitle, string bookAuthor, string bookPublisher, int bookCopyrightYear, string bookCallNumber)
        {
            Title = bookTitle;
            Author = bookAuthor;
            Publisher = bookPublisher;
            CopyrightYear = bookCopyrightYear;
            CallNumber = bookCallNumber;
        }

        //Pre-conditions: No arguments are passed into this method. A bool variable named 'checkedOut' must exist
        //Post-conditions: This method sets the bool checkedOut to true
        public void CheckOut()
        {
             checkedOut = true;
        }
        //Pre-conditions: No arguments are passed into this method. A bool variable named 'checkedOut' must exist
        //Post-conditions: This method sets the bool checkedOut to false
        public void ReturnToShelf()
        {
             checkedOut = false;
        }
        //Pre-conditions: No arguments are passed into this method, a bool variable named 'checkedOut' must exist.
        //Post-conditions: This method returns the bool value of 'checkedOut'
        public bool IsCheckedOut()
        {
            return checkedOut;
        }

        //Pre-conditions: Does not accept arguments. Book title, author, copyright year, call number, and checked out status must be compatible with the ToString() formatting
        //Post-conditions: This method returns a fully formatted string including the important information about the library book
        public override string ToString()
        {
            return "Title: " + Title.ToString() + Environment.NewLine + "Author: " + Author.ToString() + Environment.NewLine + "Publisher: " + Publisher.ToString() + Environment.NewLine +
                   "Copyright Year: " + CopyrightYear.ToString() + Environment.NewLine + "Call Number: " + CallNumber.ToString() + Environment.NewLine + "Checked Out?: " + checkedOut;
        }
    }
}
