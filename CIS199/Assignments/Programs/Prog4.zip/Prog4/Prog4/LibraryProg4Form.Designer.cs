﻿namespace Prog4
{
    partial class LibraryProg4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.libraryListBox = new System.Windows.Forms.ListBox();
            this.titleLbl = new System.Windows.Forms.Label();
            this.authorLbl = new System.Windows.Forms.Label();
            this.publisherLbl = new System.Windows.Forms.Label();
            this.copyrightLbl = new System.Windows.Forms.Label();
            this.callNumberLbl = new System.Windows.Forms.Label();
            this.titleTxtBox = new System.Windows.Forms.TextBox();
            this.authorTxtBox = new System.Windows.Forms.TextBox();
            this.publisherTxtBox = new System.Windows.Forms.TextBox();
            this.copyrightTxtBox = new System.Windows.Forms.TextBox();
            this.callNumberTxtBox = new System.Windows.Forms.TextBox();
            this.addBookBtn = new System.Windows.Forms.Button();
            this.detailsBtn = new System.Windows.Forms.Button();
            this.checkOutBtn = new System.Windows.Forms.Button();
            this.returnBtn = new System.Windows.Forms.Button();
            this.libraryLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // libraryListBox
            // 
            this.libraryListBox.FormattingEnabled = true;
            this.libraryListBox.Location = new System.Drawing.Point(213, 12);
            this.libraryListBox.Name = "libraryListBox";
            this.libraryListBox.Size = new System.Drawing.Size(143, 329);
            this.libraryListBox.TabIndex = 0;
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Location = new System.Drawing.Point(71, 61);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(27, 13);
            this.titleLbl.TabIndex = 1;
            this.titleLbl.Text = "Title";
            // 
            // authorLbl
            // 
            this.authorLbl.AutoSize = true;
            this.authorLbl.Location = new System.Drawing.Point(60, 103);
            this.authorLbl.Name = "authorLbl";
            this.authorLbl.Size = new System.Drawing.Size(38, 13);
            this.authorLbl.TabIndex = 2;
            this.authorLbl.Text = "Author";
            // 
            // publisherLbl
            // 
            this.publisherLbl.AutoSize = true;
            this.publisherLbl.Location = new System.Drawing.Point(48, 145);
            this.publisherLbl.Name = "publisherLbl";
            this.publisherLbl.Size = new System.Drawing.Size(50, 13);
            this.publisherLbl.TabIndex = 3;
            this.publisherLbl.Text = "Publisher";
            // 
            // copyrightLbl
            // 
            this.copyrightLbl.AutoSize = true;
            this.copyrightLbl.Location = new System.Drawing.Point(22, 187);
            this.copyrightLbl.Name = "copyrightLbl";
            this.copyrightLbl.Size = new System.Drawing.Size(76, 13);
            this.copyrightLbl.TabIndex = 4;
            this.copyrightLbl.Text = "Copyright Year";
            // 
            // callNumberLbl
            // 
            this.callNumberLbl.AutoSize = true;
            this.callNumberLbl.Location = new System.Drawing.Point(37, 229);
            this.callNumberLbl.Name = "callNumberLbl";
            this.callNumberLbl.Size = new System.Drawing.Size(64, 13);
            this.callNumberLbl.TabIndex = 5;
            this.callNumberLbl.Text = "Call Number";
            // 
            // titleTxtBox
            // 
            this.titleTxtBox.Location = new System.Drawing.Point(107, 58);
            this.titleTxtBox.Name = "titleTxtBox";
            this.titleTxtBox.Size = new System.Drawing.Size(100, 20);
            this.titleTxtBox.TabIndex = 6;
            // 
            // authorTxtBox
            // 
            this.authorTxtBox.Location = new System.Drawing.Point(107, 100);
            this.authorTxtBox.Name = "authorTxtBox";
            this.authorTxtBox.Size = new System.Drawing.Size(100, 20);
            this.authorTxtBox.TabIndex = 7;
            // 
            // publisherTxtBox
            // 
            this.publisherTxtBox.Location = new System.Drawing.Point(107, 142);
            this.publisherTxtBox.Name = "publisherTxtBox";
            this.publisherTxtBox.Size = new System.Drawing.Size(100, 20);
            this.publisherTxtBox.TabIndex = 8;
            // 
            // copyrightTxtBox
            // 
            this.copyrightTxtBox.Location = new System.Drawing.Point(107, 184);
            this.copyrightTxtBox.Name = "copyrightTxtBox";
            this.copyrightTxtBox.Size = new System.Drawing.Size(100, 20);
            this.copyrightTxtBox.TabIndex = 9;
            // 
            // callNumberTxtBox
            // 
            this.callNumberTxtBox.Location = new System.Drawing.Point(107, 226);
            this.callNumberTxtBox.Name = "callNumberTxtBox";
            this.callNumberTxtBox.Size = new System.Drawing.Size(100, 20);
            this.callNumberTxtBox.TabIndex = 10;
            // 
            // addBookBtn
            // 
            this.addBookBtn.Location = new System.Drawing.Point(119, 273);
            this.addBookBtn.Name = "addBookBtn";
            this.addBookBtn.Size = new System.Drawing.Size(75, 23);
            this.addBookBtn.TabIndex = 11;
            this.addBookBtn.Text = "Add Book";
            this.addBookBtn.UseVisualStyleBackColor = true;
            this.addBookBtn.Click += new System.EventHandler(this.addBookBtn_Click);
            // 
            // detailsBtn
            // 
            this.detailsBtn.Location = new System.Drawing.Point(362, 47);
            this.detailsBtn.Name = "detailsBtn";
            this.detailsBtn.Size = new System.Drawing.Size(75, 23);
            this.detailsBtn.TabIndex = 12;
            this.detailsBtn.Text = "Details";
            this.detailsBtn.UseVisualStyleBackColor = true;
            this.detailsBtn.Click += new System.EventHandler(this.detailsBtn_Click);
            // 
            // checkOutBtn
            // 
            this.checkOutBtn.Location = new System.Drawing.Point(362, 104);
            this.checkOutBtn.Name = "checkOutBtn";
            this.checkOutBtn.Size = new System.Drawing.Size(75, 23);
            this.checkOutBtn.TabIndex = 13;
            this.checkOutBtn.Text = "Check Out";
            this.checkOutBtn.UseVisualStyleBackColor = true;
            this.checkOutBtn.Click += new System.EventHandler(this.checkOutBtn_Click);
            // 
            // returnBtn
            // 
            this.returnBtn.Location = new System.Drawing.Point(362, 161);
            this.returnBtn.Name = "returnBtn";
            this.returnBtn.Size = new System.Drawing.Size(75, 23);
            this.returnBtn.TabIndex = 14;
            this.returnBtn.Text = "Return";
            this.returnBtn.UseVisualStyleBackColor = true;
            this.returnBtn.Click += new System.EventHandler(this.returnBtn_Click);
            // 
            // libraryLbl
            // 
            this.libraryLbl.AutoSize = true;
            this.libraryLbl.Location = new System.Drawing.Point(60, 12);
            this.libraryLbl.Name = "libraryLbl";
            this.libraryLbl.Size = new System.Drawing.Size(113, 13);
            this.libraryLbl.TabIndex = 15;
            this.libraryLbl.Text = "Enter book information";
            // 
            // LibraryProg4Form
            // 
            this.AcceptButton = this.addBookBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 354);
            this.Controls.Add(this.libraryLbl);
            this.Controls.Add(this.returnBtn);
            this.Controls.Add(this.checkOutBtn);
            this.Controls.Add(this.detailsBtn);
            this.Controls.Add(this.addBookBtn);
            this.Controls.Add(this.callNumberTxtBox);
            this.Controls.Add(this.copyrightTxtBox);
            this.Controls.Add(this.publisherTxtBox);
            this.Controls.Add(this.authorTxtBox);
            this.Controls.Add(this.titleTxtBox);
            this.Controls.Add(this.callNumberLbl);
            this.Controls.Add(this.copyrightLbl);
            this.Controls.Add(this.publisherLbl);
            this.Controls.Add(this.authorLbl);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.libraryListBox);
            this.Name = "LibraryProg4Form";
            this.Text = "Prog 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox libraryListBox;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Label authorLbl;
        private System.Windows.Forms.Label publisherLbl;
        private System.Windows.Forms.Label copyrightLbl;
        private System.Windows.Forms.Label callNumberLbl;
        private System.Windows.Forms.TextBox titleTxtBox;
        private System.Windows.Forms.TextBox authorTxtBox;
        private System.Windows.Forms.TextBox publisherTxtBox;
        private System.Windows.Forms.TextBox copyrightTxtBox;
        private System.Windows.Forms.TextBox callNumberTxtBox;
        private System.Windows.Forms.Button addBookBtn;
        private System.Windows.Forms.Button detailsBtn;
        private System.Windows.Forms.Button checkOutBtn;
        private System.Windows.Forms.Button returnBtn;
        private System.Windows.Forms.Label libraryLbl;
    }
}

