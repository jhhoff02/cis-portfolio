﻿/*
 * Grading ID: A9703
 * Program 4
 * Due: December 6, 2016
 * CIS 199-01
 * This program contains labels, 5 textbox inputs, a list box, and buttons on a form. 
 * The user enters information about a new library book, and clicks "Add" to add the info to the list box. 
 * The user can view details about any book in the list, and check out or return a book.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog4
{
    public partial class LibraryProg4Form : Form
    {
        private int parsedCopyright; //int variable for storing user input for copyright year after the TryParse
        public LibraryProg4Form()
        {
            InitializeComponent();
        }

        //Pre-conditions: No arguments are passed into this method. A bool variable named 'checkedOut' must exist
        //Post-conditions: This method sets the bool checkedOut to true
        private void addBookBtn_Click(object sender, EventArgs e)
        {
            string titleInput = titleTxtBox.Text; //string variable for storing user input for title
            string authorInput = authorTxtBox.Text; //string variable for storing user input for author
            string publisherInput = publisherTxtBox.Text; //string variable for storing user input for publisher
            string callNumberInput = callNumberTxtBox.Text; //string variable for storing user input for call number

            if(int.TryParse(copyrightTxtBox.Text, out parsedCopyright))
            {
                if (titleInput.Length <= 0 || authorInput.Length <= 0 || publisherInput.Length <= 0 || callNumberInput.Length <= 0)
                {
                    MessageBox.Show("Please make sure all fields have values");
                }
                else
                {
                    LibraryBook newBook = new LibraryBook(titleInput, authorInput, publisherInput, parsedCopyright, callNumberInput); //object instance of the LibraryBook class, initialized with arguments input by the user
                    libraryListBox.DisplayMember = "Title"; //Each object in the list box will only display the value for the object's Title property
                    libraryListBox.Items.Add(newBook);
                }
            }
            else
            {
                MessageBox.Show("Please enter an integer for the Copyright Year");
            }
        }

        //Pre-conditions: No arguments are passed into this method. A bool variable named 'checkedOut' must exist
        //Post-conditions: This method sets the bool checkedOut to true
        private void detailsBtn_Click(object sender, EventArgs e)
        {
            if(libraryListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a book");
            }
            else
            {
                MessageBox.Show(libraryListBox.SelectedItem.ToString());
            }
        }

        //Pre-conditions: No arguments are passed into this method. A bool variable named 'checkedOut' must exist
        //Post-conditions: This method sets the bool checkedOut to true
        private void checkOutBtn_Click(object sender, EventArgs e)
        {
            if (libraryListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a book");
            }
            else
            {
                //libraryListBox.SelectedItem.CheckOut();
                MessageBox.Show("Book has been checked out");
            }
        }

        //Pre-conditions: No arguments are passed into this method. A bool variable named 'checkedOut' must exist
        //Post-conditions: This method sets the bool checkedOut to true
        private void returnBtn_Click(object sender, EventArgs e)
        {
            if (libraryListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a book");
            }
            else
            {
                //libraryListBox.SelectedItem.ReturnToShelf();
                MessageBox.Show("Book has been returned");
            }
        }
    }
}
