﻿/*
 * Grading ID: A9703
 * Program 3
 * Due: November 20, 2016
 * CIS 199-01
 * This program contains labels, textbox inputs, and a button on a form. 
 * The student enters their last name and credit hours earned before Fall 2016, 
 * and the program displays the earliest date and time the student can register
 * for Spring 2017 classes.
 */

// This application calculates the earliest registration date
// and time for an undergraduate student given their credit hours
// and last name.
// Decisions based on UofL Fall/Summer 2016 Priority Registration Schedule

// Solution 3
// This solution keeps the first letter of the last name as a char
// and uses if/else logic for the times.
// It uses defined strings for the dates and times to make it easier
// to maintain.
// It only uses programming elements introduced in the text or
// in class.
// This solution takes advantage of the fact that there really are
// only two different time patterns used. One for juniors and seniors
// and one for sophomores and freshmen. The pattern for sophomores
// and freshmen is complicated by the fact the certain letter ranges
// get one date and other letter ranges get another date.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }         
        //Preconditions:  user enters float value for credit hours, and a valid string beginning with a letter
        //Postconditions: program will determine earliest date and time the student can register for classes
        private void findRegTimeBtn_Click(object sender, EventArgs e)
        {

            char[] alphabetEarlySrJr = {'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' }; //alphabet array for early Junior/Senior registration times
            char[] alphabetLateSrJr = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };//alphabet array for late Junior/Senior registration times

            char[] alphabetEarlyFrSoDay2 = { 'w', 'x', 'y', 'z' };//alphabet array for early Freshman/Sophomore registration times Day 1
            char[] alphabetLateFrSoDay2 = { 'a', 'b', 'c', 'd','e', 'f', 'g', 'h', 'i' };//alphabet array for late Freshman/Sophomore registration times Day 1

            char[] alphabetFrSoDay1 = { 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v' };//alphabet array for Freshman/Sophomore registration times Day 2

            bool found = false; //Boolean flag, stores true if value is found

            const float SENIOR_HOURS = 90;    // Min hours for Senior
            const float JUNIOR_HOURS = 60;    // Min hours for Junior
            const float SOPHOMORE_HOURS = 30; // Min hours for Soph.

            const string DAY1 = "November 4";  // 1st day of registration
            const string DAY2 = "November 7";  // 2nd day of registration
            const string DAY3 = "November 9";  // 3rd day of registration
            const string DAY4 = "November 10"; // 4th day of registration
            const string DAY5 = "November 11"; // 5th day of registration
            const string DAY6 = "November 14"; // 6th day of registration

            const string TIME1 = "8:30"; // 1st time of registration
            const string TIME2 = "10:00"; // 2nd time of registration
            const string TIME3 = "11:30"; // 3rd time of registration
            const string TIME4 = "2:00"; // 4th time of registration
            const string TIME5 = "4:00"; // 5th time of registration

            string lastNameStr;       // Entered last name
            char lastNameLetterCh;    // First letter of last name, as char
            string dateStr = "Error"; // Holds date of registration
            string timeStr = "Error"; // Holds time of registration
            float creditHours;        // Entered credit hours

            if (float.TryParse(creditHrTxt.Text, out creditHours) && creditHours >= 0) // Valid hours
            {
                lastNameStr = lastNameTxt.Text;
                if (lastNameStr.Length > 0) // Empty string?
                {
                    lastNameLetterCh = lastNameStr[0];   // First char of last name
                    lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case

                    if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                    {
                        int index = 0; // int variable for keeping track of index in arrays
                        // Juniors and Seniors share same schedule but different days
                        if (creditHours >= JUNIOR_HOURS)
                        {
                            if (creditHours >= SENIOR_HOURS)
                                dateStr = DAY1;
                            else // Must be juniors
                                dateStr = DAY2;
                            //Determine registration day and then display output
                            while (index <= alphabetEarlySrJr.Length - 1 && !found)
                            {
                                if (lastNameLetterCh == char.ToUpper(alphabetEarlySrJr[index]))
                                {
                                    found = true;
                                    if (lastNameLetterCh <= char.ToUpper(alphabetLateSrJr[5]))
                                        timeStr = TIME1;
                                    else if (lastNameLetterCh <= char.ToUpper(alphabetLateSrJr[9]))
                                        timeStr = TIME2;
                                    else
                                        timeStr = TIME3;
                                }
                                else
                                {
                                    index++;
                                }
                            }
                            if (found)
                            {
                                dateTimeLbl.Text = dateStr + " at " + timeStr;
                            }
                            else
                            {
                                index = 0;
                                while (index <= alphabetLateSrJr.Length - 1 && !found)
                                {
                                    if (lastNameLetterCh == char.ToUpper(alphabetLateSrJr[index]))
                                    {
                                        found = true;
                                        if (lastNameLetterCh <= char.ToUpper(alphabetLateSrJr[3]))
                                            timeStr = TIME4;
                                        else
                                            timeStr = TIME5;
                                    }
                                    else
                                    {
                                        index++;
                                    }
                                }
                                dateTimeLbl.Text = dateStr + " at " + timeStr;
                            }
                        }
                        // Sophomores and Freshmen
                        else // Must be soph/fresh
                        {
                            if (creditHours >= SOPHOMORE_HOURS)
                            {
                                // J-V on one day
                                if ((lastNameLetterCh >= 'J') && // >= J and
                                    (lastNameLetterCh <= 'V'))   // <= V
                                    dateStr = DAY3;
                                else // All other letters on next day
                                    dateStr = DAY4;
                            }
                            else // must be freshman
                            {
                                // J-V on one day
                                if ((lastNameLetterCh >= 'J') && // >= J and
                                    (lastNameLetterCh <= 'V'))   // <= V
                                    dateStr = DAY5;
                                else // All other letters on next day
                                    dateStr = DAY6;
                            }

                            while (index <= alphabetFrSoDay1.Length - 1 && !found)
                            {
                                if (lastNameLetterCh == char.ToUpper(alphabetFrSoDay1[index]))
                                {
                                    found = true;
                                    if (lastNameLetterCh <= char.ToUpper(alphabetFrSoDay1[2]))
                                        timeStr = TIME1;
                                    else if (lastNameLetterCh <= char.ToUpper(alphabetFrSoDay1[5]))
                                        timeStr = TIME2;
                                    else if (lastNameLetterCh <= char.ToUpper(alphabetFrSoDay1[7]))
                                        timeStr = TIME3;
                                    else if (lastNameLetterCh <= char.ToUpper(alphabetFrSoDay1[10]))
                                        timeStr = TIME4;
                                    else
                                        timeStr = TIME5;
                                }
                                else
                                {
                                    index++;
                                }
                            }
                            if (found)
                            {
                                dateTimeLbl.Text = dateStr + " at " + timeStr;
                            }
                            else
                            {
                                index = 0;
                                while (index <= alphabetEarlyFrSoDay2.Length - 1 && !found)
                                {
                                    if (lastNameLetterCh == char.ToUpper(alphabetEarlyFrSoDay2[index]))
                                    {
                                        found = true;
                                        if (lastNameLetterCh <= char.ToUpper(alphabetEarlyFrSoDay2[3]))
                                            timeStr = TIME1;
                                    }
                                    else
                                    {
                                        index++;
                                    }
                                }
                            }
                            if (found)
                            {
                                dateTimeLbl.Text = dateStr + " at " + timeStr;
                            }
                            else
                            {
                                index = 0;
                                while (index <= alphabetLateFrSoDay2.Length - 1 && !found)
                                {
                                    if (lastNameLetterCh == char.ToUpper(alphabetLateFrSoDay2[index]))
                                    {
                                        found = true;
                                        if (lastNameLetterCh <= alphabetLateFrSoDay2[1])
                                            timeStr = TIME2;
                                        else if (lastNameLetterCh <= alphabetLateFrSoDay2[3])
                                            timeStr = TIME3;
                                        else if (lastNameLetterCh <= alphabetLateFrSoDay2[5])
                                            timeStr = TIME4;
                                        else
                                            timeStr = TIME5;
                                    }
                                    else
                                    {
                                        index++;
                                    }
                                }
                                dateTimeLbl.Text = dateStr + " at " + timeStr;
                            }
                        }
                    }
                    else // First char not a letter
                        MessageBox.Show("Enter valid last name!");
                }
                else // Empty textbox
                    MessageBox.Show("Enter a last name!");
            }
            else // Can't parse credit hours
                MessageBox.Show("Please enter valid credit hours earned!");
        }
    }
}
