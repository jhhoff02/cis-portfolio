﻿/*
 GradingID: A9703
 Lab 1
 Due Date: 9/7/16
 CIS 199-01
 This program utilizes form controls and event handlers to create a GUI form window. 
    This program has several labels and buttons, as well as a picture. When you click on the buttons, 
    a Click event is fired that triggers another window to display information to the user.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1
{
    public partial class firstLabForm : Form
    {
        public firstLabForm()
        {
            InitializeComponent();
        }

        private void hobbies_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My hobbies are: coding, playing instruments, and studying.");
        }

        private void book_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My favorite book is: Siddhartha");
        }

        private void movie_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My favorite movie is: Inception");
        }
    }
}
