﻿namespace Lab1
{
    partial class firstLabForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kittenPicture = new System.Windows.Forms.PictureBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.hobbies = new System.Windows.Forms.Button();
            this.book = new System.Windows.Forms.Button();
            this.movie = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.kittenPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // kittenPicture
            // 
            this.kittenPicture.Image = global::Lab1.Properties.Resources.happy_kitten;
            this.kittenPicture.Location = new System.Drawing.Point(41, 32);
            this.kittenPicture.Name = "kittenPicture";
            this.kittenPicture.Size = new System.Drawing.Size(201, 117);
            this.kittenPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.kittenPicture.TabIndex = 0;
            this.kittenPicture.TabStop = false;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(66, 161);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(151, 20);
            this.nameLabel.TabIndex = 1;
            this.nameLabel.Text = "Jessica Hoffman";
            // 
            // hobbies
            // 
            this.hobbies.Location = new System.Drawing.Point(12, 210);
            this.hobbies.Name = "hobbies";
            this.hobbies.Size = new System.Drawing.Size(75, 23);
            this.hobbies.TabIndex = 2;
            this.hobbies.Text = "Hobbies";
            this.hobbies.UseVisualStyleBackColor = true;
            this.hobbies.Click += new System.EventHandler(this.hobbies_Click);
            // 
            // book
            // 
            this.book.Location = new System.Drawing.Point(102, 210);
            this.book.Name = "book";
            this.book.Size = new System.Drawing.Size(75, 23);
            this.book.TabIndex = 3;
            this.book.Text = "Book";
            this.book.UseVisualStyleBackColor = true;
            this.book.Click += new System.EventHandler(this.book_Click);
            // 
            // movie
            // 
            this.movie.Location = new System.Drawing.Point(195, 210);
            this.movie.Name = "movie";
            this.movie.Size = new System.Drawing.Size(75, 23);
            this.movie.TabIndex = 4;
            this.movie.Text = "Movie";
            this.movie.UseVisualStyleBackColor = true;
            this.movie.Click += new System.EventHandler(this.movie_Click);
            // 
            // firstLabForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 255);
            this.Controls.Add(this.movie);
            this.Controls.Add(this.book);
            this.Controls.Add(this.hobbies);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.kittenPicture);
            this.Name = "firstLabForm";
            this.Text = "Lab 1";
            ((System.ComponentModel.ISupportInitialize)(this.kittenPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox kittenPicture;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Button hobbies;
        private System.Windows.Forms.Button book;
        private System.Windows.Forms.Button movie;
    }
}

