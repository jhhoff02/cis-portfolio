﻿/*
 * Grading ID: A9703
 * Lab 7
 * Due: November 6, 2016
 * CIS 199-01
 * This program contains labels, a textbox input, a button, and radio buttons on a form. 
 * The user enters integer for month, selects desired language, and clicks the Lookup button. 
 * The program outputs the desired month in the specified language
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class lab7Form : Form
    {
        public lab7Form()
        {
            InitializeComponent();
        }

        //Click event for selecting method based on language. Displays error message for invalid input
        private void lookupBtn_Click(object sender, EventArgs e)
        {
            int parsedMonth; // int variable that stores the month number after the TryParse
            if(int.TryParse(inputBox.Text, out parsedMonth))
            {
                if(parsedMonth <= 0 || parsedMonth > 12)
                {
                    MessageBox.Show("Error!");
                } else
                {
                    //Selects method to use based on radio button selection
                    if (italRadioBtn.Checked)
                    {
                        outputLbl.Text = GetItalianMonth(parsedMonth);
                    }
                    else if (spanRadioBtn.Checked)
                    {
                        outputLbl.Text = GetSpanishMonth(parsedMonth);
                    }
                    else
                    {
                        outputLbl.Text = GetEnglishMonth(parsedMonth);
                    }
                }
                
            } else
            {
                MessageBox.Show("Error!");
            }
         }

        //Precondition: 0 < parsedMonth <= 12
        //Postcondition: method returns string from month array at the index passed into the method
        private string GetEnglishMonth(int inputMonth)
        {
            string[] englishMonths = new string[12] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }; //Array of strings referencing the storage of English months
            return englishMonths[inputMonth - 1]; 
        }

        //Precondition: 0 < parsedMonth <= 12
        //Postcondition: method returns string from month array at the index passed into the method
        private string GetSpanishMonth(int inputMonth)
        {
            string[] spanishMonths = new string[12] { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" }; //Array of strings referencing the storage of Spanish months
            return spanishMonths[inputMonth - 1];
        }

        //Precondition: 0 < parsedMonth <= 12
        //Postcondition: method returns string from month array at the index passed into the method
        private string GetItalianMonth(int inputMonth)
        {
            string[] italianMonths = new string[12] { "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre" }; //Array of strings referencing the storage of Italian months
            return italianMonths[inputMonth - 1];
        }
    }
}
