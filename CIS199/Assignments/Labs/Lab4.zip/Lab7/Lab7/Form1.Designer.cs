﻿namespace Lab7
{
    partial class lab7Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthLbl = new System.Windows.Forms.Label();
            this.inputBox = new System.Windows.Forms.TextBox();
            this.langGroupBox = new System.Windows.Forms.GroupBox();
            this.engRadioBtn = new System.Windows.Forms.RadioButton();
            this.spanRadioBtn = new System.Windows.Forms.RadioButton();
            this.italRadioBtn = new System.Windows.Forms.RadioButton();
            this.outputLbl = new System.Windows.Forms.Label();
            this.lookupBtn = new System.Windows.Forms.Button();
            this.langGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // monthLbl
            // 
            this.monthLbl.AutoSize = true;
            this.monthLbl.Location = new System.Drawing.Point(9, 45);
            this.monthLbl.Name = "monthLbl";
            this.monthLbl.Size = new System.Drawing.Size(59, 17);
            this.monthLbl.TabIndex = 0;
            this.monthLbl.Text = "Month #";
            // 
            // inputBox
            // 
            this.inputBox.Location = new System.Drawing.Point(84, 42);
            this.inputBox.Name = "inputBox";
            this.inputBox.Size = new System.Drawing.Size(100, 22);
            this.inputBox.TabIndex = 1;
            // 
            // langGroupBox
            // 
            this.langGroupBox.Controls.Add(this.italRadioBtn);
            this.langGroupBox.Controls.Add(this.spanRadioBtn);
            this.langGroupBox.Controls.Add(this.engRadioBtn);
            this.langGroupBox.Location = new System.Drawing.Point(12, 85);
            this.langGroupBox.Name = "langGroupBox";
            this.langGroupBox.Size = new System.Drawing.Size(148, 129);
            this.langGroupBox.TabIndex = 2;
            this.langGroupBox.TabStop = false;
            this.langGroupBox.Text = "Choose Language";
            // 
            // engRadioBtn
            // 
            this.engRadioBtn.AutoSize = true;
            this.engRadioBtn.Location = new System.Drawing.Point(20, 35);
            this.engRadioBtn.Name = "engRadioBtn";
            this.engRadioBtn.Size = new System.Drawing.Size(75, 21);
            this.engRadioBtn.TabIndex = 0;
            this.engRadioBtn.TabStop = true;
            this.engRadioBtn.Text = "English";
            this.engRadioBtn.UseVisualStyleBackColor = true;
            // 
            // spanRadioBtn
            // 
            this.spanRadioBtn.AutoSize = true;
            this.spanRadioBtn.Location = new System.Drawing.Point(20, 62);
            this.spanRadioBtn.Name = "spanRadioBtn";
            this.spanRadioBtn.Size = new System.Drawing.Size(80, 21);
            this.spanRadioBtn.TabIndex = 1;
            this.spanRadioBtn.TabStop = true;
            this.spanRadioBtn.Text = "Spanish";
            this.spanRadioBtn.UseVisualStyleBackColor = true;
            // 
            // italRadioBtn
            // 
            this.italRadioBtn.AutoSize = true;
            this.italRadioBtn.Location = new System.Drawing.Point(20, 89);
            this.italRadioBtn.Name = "italRadioBtn";
            this.italRadioBtn.Size = new System.Drawing.Size(66, 21);
            this.italRadioBtn.TabIndex = 2;
            this.italRadioBtn.TabStop = true;
            this.italRadioBtn.Text = "Italian";
            this.italRadioBtn.UseVisualStyleBackColor = true;
            // 
            // outputLbl
            // 
            this.outputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLbl.Location = new System.Drawing.Point(47, 246);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(162, 32);
            this.outputLbl.TabIndex = 3;
            // 
            // lookupBtn
            // 
            this.lookupBtn.Location = new System.Drawing.Point(96, 294);
            this.lookupBtn.Name = "lookupBtn";
            this.lookupBtn.Size = new System.Drawing.Size(75, 26);
            this.lookupBtn.TabIndex = 4;
            this.lookupBtn.Text = "Look Up";
            this.lookupBtn.UseVisualStyleBackColor = true;
            this.lookupBtn.Click += new System.EventHandler(this.lookupBtn_Click);
            // 
            // lab7Form
            // 
            this.AcceptButton = this.lookupBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(256, 360);
            this.Controls.Add(this.lookupBtn);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.langGroupBox);
            this.Controls.Add(this.inputBox);
            this.Controls.Add(this.monthLbl);
            this.Name = "lab7Form";
            this.Text = "Lab 7";
            this.langGroupBox.ResumeLayout(false);
            this.langGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label monthLbl;
        private System.Windows.Forms.TextBox inputBox;
        private System.Windows.Forms.GroupBox langGroupBox;
        private System.Windows.Forms.RadioButton italRadioBtn;
        private System.Windows.Forms.RadioButton spanRadioBtn;
        private System.Windows.Forms.RadioButton engRadioBtn;
        private System.Windows.Forms.Label outputLbl;
        private System.Windows.Forms.Button lookupBtn;
    }
}

