﻿namespace Lab5
{
    partial class Lab5Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.runLoopBtn = new System.Windows.Forms.Button();
            this.clearListBtn = new System.Windows.Forms.Button();
            this.fromLbl = new System.Windows.Forms.Label();
            this.toLbl = new System.Windows.Forms.Label();
            this.toInputBox = new System.Windows.Forms.TextBox();
            this.fromInputBox = new System.Windows.Forms.TextBox();
            this.loopsGroupBox = new System.Windows.Forms.GroupBox();
            this.doWhileRadioBtn = new System.Windows.Forms.RadioButton();
            this.forRadioBtn = new System.Windows.Forms.RadioButton();
            this.whileRadioBtn = new System.Windows.Forms.RadioButton();
            this.titleLbl = new System.Windows.Forms.Label();
            this.outputListBox = new System.Windows.Forms.ListBox();
            this.loopsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // runLoopBtn
            // 
            this.runLoopBtn.Location = new System.Drawing.Point(16, 326);
            this.runLoopBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.runLoopBtn.Name = "runLoopBtn";
            this.runLoopBtn.Size = new System.Drawing.Size(100, 28);
            this.runLoopBtn.TabIndex = 0;
            this.runLoopBtn.Text = "Run Loop";
            this.runLoopBtn.UseVisualStyleBackColor = true;
            this.runLoopBtn.Click += new System.EventHandler(this.runLoopBtn_Click);
            // 
            // clearListBtn
            // 
            this.clearListBtn.Location = new System.Drawing.Point(16, 373);
            this.clearListBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.clearListBtn.Name = "clearListBtn";
            this.clearListBtn.Size = new System.Drawing.Size(100, 28);
            this.clearListBtn.TabIndex = 1;
            this.clearListBtn.Text = "Clear List";
            this.clearListBtn.UseVisualStyleBackColor = true;
            this.clearListBtn.Click += new System.EventHandler(this.clearListBtn_Click);
            // 
            // fromLbl
            // 
            this.fromLbl.AutoSize = true;
            this.fromLbl.Location = new System.Drawing.Point(0, 43);
            this.fromLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.fromLbl.Name = "fromLbl";
            this.fromLbl.Size = new System.Drawing.Size(44, 17);
            this.fromLbl.TabIndex = 2;
            this.fromLbl.Text = "From:";
            // 
            // toLbl
            // 
            this.toLbl.AutoSize = true;
            this.toLbl.Location = new System.Drawing.Point(0, 103);
            this.toLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.toLbl.Name = "toLbl";
            this.toLbl.Size = new System.Drawing.Size(29, 17);
            this.toLbl.TabIndex = 3;
            this.toLbl.Text = "To:";
            // 
            // toInputBox
            // 
            this.toInputBox.Location = new System.Drawing.Point(4, 123);
            this.toInputBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.toInputBox.Name = "toInputBox";
            this.toInputBox.Size = new System.Drawing.Size(132, 22);
            this.toInputBox.TabIndex = 4;
            // 
            // fromInputBox
            // 
            this.fromInputBox.Location = new System.Drawing.Point(4, 63);
            this.fromInputBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.fromInputBox.Name = "fromInputBox";
            this.fromInputBox.Size = new System.Drawing.Size(132, 22);
            this.fromInputBox.TabIndex = 5;
            // 
            // loopsGroupBox
            // 
            this.loopsGroupBox.Controls.Add(this.doWhileRadioBtn);
            this.loopsGroupBox.Controls.Add(this.forRadioBtn);
            this.loopsGroupBox.Controls.Add(this.whileRadioBtn);
            this.loopsGroupBox.Location = new System.Drawing.Point(4, 178);
            this.loopsGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loopsGroupBox.Name = "loopsGroupBox";
            this.loopsGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loopsGroupBox.Size = new System.Drawing.Size(133, 117);
            this.loopsGroupBox.TabIndex = 6;
            this.loopsGroupBox.TabStop = false;
            this.loopsGroupBox.Text = "Loop Using:";
            // 
            // doWhileRadioBtn
            // 
            this.doWhileRadioBtn.AutoSize = true;
            this.doWhileRadioBtn.Location = new System.Drawing.Point(12, 80);
            this.doWhileRadioBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.doWhileRadioBtn.Name = "doWhileRadioBtn";
            this.doWhileRadioBtn.Size = new System.Drawing.Size(81, 21);
            this.doWhileRadioBtn.TabIndex = 2;
            this.doWhileRadioBtn.TabStop = true;
            this.doWhileRadioBtn.Text = "do-while";
            this.doWhileRadioBtn.UseVisualStyleBackColor = true;
            // 
            // forRadioBtn
            // 
            this.forRadioBtn.AutoSize = true;
            this.forRadioBtn.Location = new System.Drawing.Point(12, 52);
            this.forRadioBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.forRadioBtn.Name = "forRadioBtn";
            this.forRadioBtn.Size = new System.Drawing.Size(46, 21);
            this.forRadioBtn.TabIndex = 1;
            this.forRadioBtn.TabStop = true;
            this.forRadioBtn.Text = "for";
            this.forRadioBtn.UseVisualStyleBackColor = true;
            // 
            // whileRadioBtn
            // 
            this.whileRadioBtn.AutoSize = true;
            this.whileRadioBtn.Location = new System.Drawing.Point(12, 23);
            this.whileRadioBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.whileRadioBtn.Name = "whileRadioBtn";
            this.whileRadioBtn.Size = new System.Drawing.Size(60, 21);
            this.whileRadioBtn.TabIndex = 0;
            this.whileRadioBtn.TabStop = true;
            this.whileRadioBtn.Text = "while";
            this.whileRadioBtn.UseVisualStyleBackColor = true;
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.titleLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLbl.Location = new System.Drawing.Point(4, 10);
            this.titleLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(117, 22);
            this.titleLbl.TabIndex = 7;
            this.titleLbl.Text = "Loop Program";
            // 
            // outputListBox
            // 
            this.outputListBox.FormattingEnabled = true;
            this.outputListBox.ItemHeight = 16;
            this.outputListBox.Location = new System.Drawing.Point(205, 15);
            this.outputListBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.outputListBox.Name = "outputListBox";
            this.outputListBox.Size = new System.Drawing.Size(168, 404);
            this.outputListBox.TabIndex = 8;
            // 
            // Lab5Form
            // 
            this.AcceptButton = this.runLoopBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearListBtn;
            this.ClientSize = new System.Drawing.Size(391, 441);
            this.Controls.Add(this.outputListBox);
            this.Controls.Add(this.titleLbl);
            this.Controls.Add(this.loopsGroupBox);
            this.Controls.Add(this.fromInputBox);
            this.Controls.Add(this.toInputBox);
            this.Controls.Add(this.toLbl);
            this.Controls.Add(this.fromLbl);
            this.Controls.Add(this.clearListBtn);
            this.Controls.Add(this.runLoopBtn);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Lab5Form";
            this.Text = "Lab 5";
            this.loopsGroupBox.ResumeLayout(false);
            this.loopsGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button runLoopBtn;
        private System.Windows.Forms.Button clearListBtn;
        private System.Windows.Forms.Label fromLbl;
        private System.Windows.Forms.Label toLbl;
        private System.Windows.Forms.TextBox toInputBox;
        private System.Windows.Forms.TextBox fromInputBox;
        private System.Windows.Forms.GroupBox loopsGroupBox;
        private System.Windows.Forms.RadioButton doWhileRadioBtn;
        private System.Windows.Forms.RadioButton forRadioBtn;
        private System.Windows.Forms.RadioButton whileRadioBtn;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.ListBox outputListBox;
    }
}

