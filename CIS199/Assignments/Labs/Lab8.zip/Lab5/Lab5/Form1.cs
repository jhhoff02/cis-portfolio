﻿/*
 * Grading ID: A9703
 * Lab 5
 * Due: October 23, 2016
 * CIS 199-01
 * This program contains labels, 2 textbox inputs, buttons, radio buttons, and a list box on a form. 
 * The user enters 2 integer values for the start and end of the range, selects desired loop, and clicks the Run Loop button. 
 * The program outputs all integers within that range to the list box
 * The user can clear the list with the Clear List button
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Lab5Form : Form
    {
        public Lab5Form()
        {
            InitializeComponent();
        }

        //Click event for Run Loop button. Will run the designated loop with the user's ranges.
        private void runLoopBtn_Click(object sender, EventArgs e)
        {
            int parsedRangeStart; // int variable that stores the range start after the TryParse
            int parsedRangeEnd; // int variable that stores the range end after the TryParse

            //Begin parsing for invalid inputs and provide error messages. Otherwise perform the loop based on the user's ranges.
            if (int.TryParse(fromInputBox.Text, out parsedRangeStart))
            {
                if (int.TryParse(toInputBox.Text, out parsedRangeEnd))
                {
                    if(whileRadioBtn.Checked || forRadioBtn.Checked || doWhileRadioBtn.Checked)
                    {
                        if (whileRadioBtn.Checked)
                        {
                            while(parsedRangeStart <= parsedRangeEnd)
                            {
                                outputListBox.Items.Add(parsedRangeStart);
                                parsedRangeStart++;
                            }
                        }
                        else if (forRadioBtn.Checked)
                        {
                            for(var i = parsedRangeStart; i <= parsedRangeEnd; i++)
                            {
                                outputListBox.Items.Add(parsedRangeStart);
                                parsedRangeStart++;
                            }
                        }
                        else
                        {
                            do
                            {
                                outputListBox.Items.Add(parsedRangeStart);
                                parsedRangeStart++;
                            } while (parsedRangeStart <= parsedRangeEnd);
                        }
                    } else
                    {
                        MessageBox.Show("Please select one of the loops options");
                    }
                    
                }
                else
                {
                    MessageBox.Show("This is not a valid input for end of range");
                };
            }
            else
            {
                MessageBox.Show("This is not a valid input for start of range");
            };
        }
    
        //Click event for clearing the List Box items.
        private void clearListBtn_Click(object sender, EventArgs e)
        {
            outputListBox.Items.Clear();
        }
    }
}
