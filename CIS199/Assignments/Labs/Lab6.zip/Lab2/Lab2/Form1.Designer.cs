﻿namespace Lab2
{
    partial class lab2Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameLbl = new System.Windows.Forms.Label();
            this.middleNameLbl = new System.Windows.Forms.Label();
            this.lastNameLbl = new System.Windows.Forms.Label();
            this.preferredTitleLbl = new System.Windows.Forms.Label();
            this.outputLbl = new System.Windows.Forms.Label();
            this.firstNameInput = new System.Windows.Forms.TextBox();
            this.middleNameInput = new System.Windows.Forms.TextBox();
            this.lastNameInput = new System.Windows.Forms.TextBox();
            this.preferredTitleInput = new System.Windows.Forms.TextBox();
            this.format1Btn = new System.Windows.Forms.Button();
            this.format2Btn = new System.Windows.Forms.Button();
            this.format3Btn = new System.Windows.Forms.Button();
            this.format4Btn = new System.Windows.Forms.Button();
            this.format5Btn = new System.Windows.Forms.Button();
            this.format6Btn = new System.Windows.Forms.Button();
            this.directionsLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // firstNameLbl
            // 
            this.firstNameLbl.AutoSize = true;
            this.firstNameLbl.Location = new System.Drawing.Point(140, 39);
            this.firstNameLbl.Name = "firstNameLbl";
            this.firstNameLbl.Size = new System.Drawing.Size(58, 13);
            this.firstNameLbl.TabIndex = 0;
            this.firstNameLbl.Text = "First name:";
            // 
            // middleNameLbl
            // 
            this.middleNameLbl.AutoSize = true;
            this.middleNameLbl.Location = new System.Drawing.Point(128, 65);
            this.middleNameLbl.Name = "middleNameLbl";
            this.middleNameLbl.Size = new System.Drawing.Size(70, 13);
            this.middleNameLbl.TabIndex = 1;
            this.middleNameLbl.Text = "Middle name:";
            // 
            // lastNameLbl
            // 
            this.lastNameLbl.AutoSize = true;
            this.lastNameLbl.Location = new System.Drawing.Point(139, 95);
            this.lastNameLbl.Name = "lastNameLbl";
            this.lastNameLbl.Size = new System.Drawing.Size(59, 13);
            this.lastNameLbl.TabIndex = 2;
            this.lastNameLbl.Text = "Last name:";
            // 
            // preferredTitleLbl
            // 
            this.preferredTitleLbl.AutoSize = true;
            this.preferredTitleLbl.Location = new System.Drawing.Point(12, 121);
            this.preferredTitleLbl.Name = "preferredTitleLbl";
            this.preferredTitleLbl.Size = new System.Drawing.Size(186, 13);
            this.preferredTitleLbl.TabIndex = 3;
            this.preferredTitleLbl.Text = "Preferred title (Mr., Mrs., Ms., Dr., etc):";
            // 
            // outputLbl
            // 
            this.outputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLbl.Location = new System.Drawing.Point(96, 168);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(269, 29);
            this.outputLbl.TabIndex = 4;
            // 
            // firstNameInput
            // 
            this.firstNameInput.Location = new System.Drawing.Point(204, 36);
            this.firstNameInput.Name = "firstNameInput";
            this.firstNameInput.Size = new System.Drawing.Size(100, 20);
            this.firstNameInput.TabIndex = 5;
            // 
            // middleNameInput
            // 
            this.middleNameInput.Location = new System.Drawing.Point(204, 62);
            this.middleNameInput.Name = "middleNameInput";
            this.middleNameInput.Size = new System.Drawing.Size(100, 20);
            this.middleNameInput.TabIndex = 6;
            // 
            // lastNameInput
            // 
            this.lastNameInput.Location = new System.Drawing.Point(204, 92);
            this.lastNameInput.Name = "lastNameInput";
            this.lastNameInput.Size = new System.Drawing.Size(100, 20);
            this.lastNameInput.TabIndex = 7;
            // 
            // preferredTitleInput
            // 
            this.preferredTitleInput.Location = new System.Drawing.Point(204, 118);
            this.preferredTitleInput.Name = "preferredTitleInput";
            this.preferredTitleInput.Size = new System.Drawing.Size(100, 20);
            this.preferredTitleInput.TabIndex = 8;
            // 
            // format1Btn
            // 
            this.format1Btn.Location = new System.Drawing.Point(21, 219);
            this.format1Btn.Name = "format1Btn";
            this.format1Btn.Size = new System.Drawing.Size(75, 23);
            this.format1Btn.TabIndex = 9;
            this.format1Btn.Text = "Format 1";
            this.format1Btn.UseVisualStyleBackColor = true;
            this.format1Btn.Click += new System.EventHandler(this.format1Btn_Click);
            // 
            // format2Btn
            // 
            this.format2Btn.Location = new System.Drawing.Point(129, 219);
            this.format2Btn.Name = "format2Btn";
            this.format2Btn.Size = new System.Drawing.Size(75, 23);
            this.format2Btn.TabIndex = 10;
            this.format2Btn.Text = "Format 2";
            this.format2Btn.UseVisualStyleBackColor = true;
            this.format2Btn.Click += new System.EventHandler(this.format2Btn_Click);
            // 
            // format3Btn
            // 
            this.format3Btn.Location = new System.Drawing.Point(246, 219);
            this.format3Btn.Name = "format3Btn";
            this.format3Btn.Size = new System.Drawing.Size(75, 23);
            this.format3Btn.TabIndex = 11;
            this.format3Btn.Text = "Format 3";
            this.format3Btn.UseVisualStyleBackColor = true;
            this.format3Btn.Click += new System.EventHandler(this.format3Btn_Click);
            // 
            // format4Btn
            // 
            this.format4Btn.Location = new System.Drawing.Point(370, 219);
            this.format4Btn.Name = "format4Btn";
            this.format4Btn.Size = new System.Drawing.Size(75, 23);
            this.format4Btn.TabIndex = 12;
            this.format4Btn.Text = "Format 4";
            this.format4Btn.UseVisualStyleBackColor = true;
            this.format4Btn.Click += new System.EventHandler(this.format4Btn_Click);
            // 
            // format5Btn
            // 
            this.format5Btn.Location = new System.Drawing.Point(79, 265);
            this.format5Btn.Name = "format5Btn";
            this.format5Btn.Size = new System.Drawing.Size(75, 23);
            this.format5Btn.TabIndex = 13;
            this.format5Btn.Text = "Format 5";
            this.format5Btn.UseVisualStyleBackColor = true;
            this.format5Btn.Click += new System.EventHandler(this.format5Btn_Click);
            // 
            // format6Btn
            // 
            this.format6Btn.Location = new System.Drawing.Point(312, 265);
            this.format6Btn.Name = "format6Btn";
            this.format6Btn.Size = new System.Drawing.Size(75, 23);
            this.format6Btn.TabIndex = 14;
            this.format6Btn.Text = "Format 6";
            this.format6Btn.UseVisualStyleBackColor = true;
            this.format6Btn.Click += new System.EventHandler(this.format6Btn_Click);
            // 
            // directionsLbl
            // 
            this.directionsLbl.AutoSize = true;
            this.directionsLbl.Location = new System.Drawing.Point(148, 9);
            this.directionsLbl.Name = "directionsLbl";
            this.directionsLbl.Size = new System.Drawing.Size(170, 13);
            this.directionsLbl.TabIndex = 15;
            this.directionsLbl.Text = "Please enter letters only in all fields";
            // 
            // lab2Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 313);
            this.Controls.Add(this.directionsLbl);
            this.Controls.Add(this.format6Btn);
            this.Controls.Add(this.format5Btn);
            this.Controls.Add(this.format4Btn);
            this.Controls.Add(this.format3Btn);
            this.Controls.Add(this.format2Btn);
            this.Controls.Add(this.format1Btn);
            this.Controls.Add(this.preferredTitleInput);
            this.Controls.Add(this.lastNameInput);
            this.Controls.Add(this.middleNameInput);
            this.Controls.Add(this.firstNameInput);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.preferredTitleLbl);
            this.Controls.Add(this.lastNameLbl);
            this.Controls.Add(this.middleNameLbl);
            this.Controls.Add(this.firstNameLbl);
            this.Name = "lab2Form";
            this.Text = "Lab2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNameLbl;
        private System.Windows.Forms.Label middleNameLbl;
        private System.Windows.Forms.Label lastNameLbl;
        private System.Windows.Forms.Label preferredTitleLbl;
        private System.Windows.Forms.Label outputLbl;
        private System.Windows.Forms.TextBox firstNameInput;
        private System.Windows.Forms.TextBox middleNameInput;
        private System.Windows.Forms.TextBox lastNameInput;
        private System.Windows.Forms.TextBox preferredTitleInput;
        private System.Windows.Forms.Button format1Btn;
        private System.Windows.Forms.Button format2Btn;
        private System.Windows.Forms.Button format3Btn;
        private System.Windows.Forms.Button format4Btn;
        private System.Windows.Forms.Button format5Btn;
        private System.Windows.Forms.Button format6Btn;
        private System.Windows.Forms.Label directionsLbl;
    }
}

