﻿/*
 * Grading ID: A9703
 * Lab 2
 * Due: September 18, 2016
 * CIS 199-01
 * This program contains labels, textbox inputs, and buttons on a form. 
 * The user enters their various names, and the buttons format the inputs. 
 * The label with a border displays the formatted output string.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2 //The Lab2 namespace contains a class related to this lab.
{
    //The lab2Form class contains Click event handler methods.
    public partial class lab2Form : Form 
    {
        //This method initializes a form
        public lab2Form() 
        {
            InitializeComponent();
        }

        //This event handler formats user text inputs according to format 1. Ex: "PreferredTitle. FirstName MiddleName LastName
        private void format1Btn_Click(object sender, EventArgs e) 
        {
            string formattedOutput1; //This string variable is built using user input. Then, the outputLbl's Text property is assigned to the string variable.
            formattedOutput1 = preferredTitleInput.Text + " " + firstNameInput.Text + " " + middleNameInput.Text + " " + lastNameInput.Text;
            outputLbl.Text = formattedOutput1;
        }

        //This event handler formats user text inputs according to format 2. Ex: "FirstName MiddleName LastName"
        private void format2Btn_Click(object sender, EventArgs e) 
        {
            string formattedOutput2; //This string variable is built using user input. Then, the outputLbl's Text property is assigned to the string variable.
            formattedOutput2 = firstNameInput.Text + " " + middleNameInput.Text + " " + lastNameInput.Text;
            outputLbl.Text = formattedOutput2;
        }

        //This event handler formats user text inputs according to format 3. Ex: "FirstName LastName"
        private void format3Btn_Click(object sender, EventArgs e) 
        {
            string formattedOutput3; //This string variable is built using user input. Then, the outputLbl's Text property is assigned to the string variable.
            formattedOutput3 = firstNameInput.Text + " "  + lastNameInput.Text;
            outputLbl.Text = formattedOutput3;
        }

        //This event handler formats user text inputs according to format 4. Ex: "LastName, FirstName MiddleName, PreferredTitle"
        private void format4Btn_Click(object sender, EventArgs e) 
        {
            string formattedOutput4; //This string variable is built using user input. Then, the outputLbl's Text property is assigned to the string variable.
            formattedOutput4 = lastNameInput.Text + ", " + firstNameInput.Text + " " + middleNameInput.Text + ", " + preferredTitleInput.Text;
            outputLbl.Text = formattedOutput4;
        }

        //This event handler formats user text inputs according to format 5. Ex: "LastName, FirstName MiddleName"
        private void format5Btn_Click(object sender, EventArgs e) 
        {
            string formattedOutput5; //This string variable is built using user input. Then, the outputLbl's Text property is assigned to the string variable.
            formattedOutput5 = lastNameInput.Text + ", " + firstNameInput.Text + " " + middleNameInput.Text;
            outputLbl.Text = formattedOutput5;
        }

        //This event handler formats user text inputs according to format 6. Ex: "LastName, FirstName"
        private void format6Btn_Click(object sender, EventArgs e) 
        {
            string formattedOutput6; //This string variable is built using user input. Then, the outputLbl's Text property is assigned to the string variable.
            formattedOutput6 = lastNameInput.Text + ", " + firstNameInput.Text;
            outputLbl.Text = formattedOutput6;
        }
    }
}
