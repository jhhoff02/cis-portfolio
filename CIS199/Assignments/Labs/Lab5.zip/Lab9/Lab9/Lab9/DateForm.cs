﻿/*
 * Grading ID: A9703
 * Lab 9
 * Due: November 29, 2016
 * CIS 199-01
 * This program contains labels, 3 textbox inputs, and buttons on a form. 
 * The user enters month, day, and year integer values and clicks the Update buttons for each value. 
 * The program initializes the formatted date with 1/1/2000, but will display the user-inputted date if the parse is successful.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class lab9Form : Form
    {
        public int parsedMonthInput = 1; //int variable for storing month after it is parsed
        public int parsedDayInput = 1; //int variable for storing day after it is parsed
        public int parsedYearInput = 2000; //int variable for storing year after it is parsed
        public lab9Form()
        {
            InitializeComponent();
        }

        private void lab9Form_Load(object sender, EventArgs e)
        {
            Date newDate = new Date(parsedMonthInput, parsedDayInput, parsedYearInput); //object instance of the Date class, initialized with the date 1/1/2000 upon loading
            outputLbl.Text = newDate.ToString(); //displays new loaded date on the form
        }

        //Pre-conditions: The user enters something in the monthTxtBox and the monthBtn is clicked
        //Post-conditions: after this event handler is called, the month is updated based on user input if it is parsed successfully
        private void monthBtn_Click(object sender, EventArgs e)
        {
            string monthInput = monthTxtBox.Text; //string variable for storing user input for month
            if (int.TryParse(monthInput, out parsedMonthInput))
            {
                Date newDate = new Date(parsedMonthInput, parsedDayInput, parsedYearInput);
                outputLbl.Text = newDate.ToString();
            } else
            {
                MessageBox.Show("Please enter a valid month integer");
            }
        }

        //Pre-conditions: The user enters something in the dayTxtBox and the dayBtn is clicked
        //Post-conditions: after this event handler is called, the day is updated based on user input if it is parsed successfully
        private void dayBtn_Click(object sender, EventArgs e)
        {
            string dayInput = dayTxtBox.Text; //string variable for storing user input for day
            if (int.TryParse(dayInput, out parsedDayInput))
            {
                Date newDate = new Date(parsedMonthInput, parsedDayInput, parsedYearInput);
                outputLbl.Text = newDate.ToString();
            }
            else
            {
                MessageBox.Show("Please enter a valid day integer");
            }
        }

        //Pre-conditions: The user enters something in the yearTxtBox and the yearBtn is clicked
        //Post-conditions: after this event handler is called, the year is updated based on user input if it is parsed successfully
        private void yearBtn_Click(object sender, EventArgs e)
        {
            string yearInput = yearTxtBox.Text; //string variable for storing user input for year
            if (int.TryParse(yearInput, out parsedYearInput))
            {
                Date newDate = new Date(parsedMonthInput, parsedDayInput, parsedYearInput);
                outputLbl.Text = newDate.ToString();
            }
            else
            {
                MessageBox.Show("Please enter a valid year integer");
            }
        }
    }
}
