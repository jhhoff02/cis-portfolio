﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9
{
    //class containing description and actions for the Date class
    public class Date
    {
        private int _month; //private integer used as the month parameter of the Date constructor
        private int _day; //private integer used as the day parameter of the Date constructor
        private int _year; //private integer used as the year parameter of the Date constructor

        public virtual int Month { get; set; } //Date property for getting/setting the Month
        public virtual int Day { get; set; } //Date property for getting/setting the Day
        public virtual int Year { get; set; } //Date property for getting/setting the Year

        //Pre-conditions: parameters _month, _day, and _year must be integers, this parsing should happen before the method is called
        //Post-conditions: after this method is called, the Month, Day, and Year properties of the Date class are set to the respective arguments used to call the method,
        // or for invalid inputs, default values are provided.
        public Date( int _month, int _day, int _year)
        {
            if(_month > 12 || _month < 1)
            {
                Month = 1;
            } else
            {
                Month = _month; //sets Month property equal to input
            }
            if(_day > 31 || _day < 1)
            {
                Day = 1;
            } else
            {
                Day = _day; //sets Day property equal to input
            }
            if(_year < 0)
            {
                Year = 2000;
            } else
            {
                Year = _year; //sets Year property equal to input
            }
        }

        //Pre-conditions: Month, Day, and Year properties of the Date class must be compatible with the ToString() formatting (either D2 or D4)
        //Post-conditions: This method returns a fully formatted string including the Month, Day, and Year properties
        public override string ToString()
        {
            return Month.ToString("D2") + "/" + Day.ToString("D2") + "/" + Year.ToString("D4");
        }

    }
}
