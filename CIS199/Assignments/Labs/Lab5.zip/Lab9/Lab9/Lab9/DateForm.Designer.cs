﻿namespace Lab9
{
    partial class lab9Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateLbl = new System.Windows.Forms.Label();
            this.outputLbl = new System.Windows.Forms.Label();
            this.monthLbl = new System.Windows.Forms.Label();
            this.dayLbl = new System.Windows.Forms.Label();
            this.yearLbl = new System.Windows.Forms.Label();
            this.yearTxtBox = new System.Windows.Forms.TextBox();
            this.dayTxtBox = new System.Windows.Forms.TextBox();
            this.monthTxtBox = new System.Windows.Forms.TextBox();
            this.monthBtn = new System.Windows.Forms.Button();
            this.dayBtn = new System.Windows.Forms.Button();
            this.yearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dateLbl
            // 
            this.dateLbl.AutoSize = true;
            this.dateLbl.Location = new System.Drawing.Point(42, 19);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(33, 13);
            this.dateLbl.TabIndex = 0;
            this.dateLbl.Text = "Date:";
            // 
            // outputLbl
            // 
            this.outputLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLbl.Location = new System.Drawing.Point(109, 9);
            this.outputLbl.Name = "outputLbl";
            this.outputLbl.Size = new System.Drawing.Size(100, 23);
            this.outputLbl.TabIndex = 1;
            this.outputLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // monthLbl
            // 
            this.monthLbl.AutoSize = true;
            this.monthLbl.Location = new System.Drawing.Point(42, 62);
            this.monthLbl.Name = "monthLbl";
            this.monthLbl.Size = new System.Drawing.Size(40, 13);
            this.monthLbl.TabIndex = 2;
            this.monthLbl.Text = "Month:";
            // 
            // dayLbl
            // 
            this.dayLbl.AutoSize = true;
            this.dayLbl.Location = new System.Drawing.Point(42, 105);
            this.dayLbl.Name = "dayLbl";
            this.dayLbl.Size = new System.Drawing.Size(29, 13);
            this.dayLbl.TabIndex = 3;
            this.dayLbl.Text = "Day:";
            // 
            // yearLbl
            // 
            this.yearLbl.AutoSize = true;
            this.yearLbl.Location = new System.Drawing.Point(42, 148);
            this.yearLbl.Name = "yearLbl";
            this.yearLbl.Size = new System.Drawing.Size(32, 13);
            this.yearLbl.TabIndex = 4;
            this.yearLbl.Text = "Year:";
            // 
            // yearTxtBox
            // 
            this.yearTxtBox.Location = new System.Drawing.Point(109, 144);
            this.yearTxtBox.Name = "yearTxtBox";
            this.yearTxtBox.Size = new System.Drawing.Size(100, 20);
            this.yearTxtBox.TabIndex = 5;
            // 
            // dayTxtBox
            // 
            this.dayTxtBox.Location = new System.Drawing.Point(109, 100);
            this.dayTxtBox.Name = "dayTxtBox";
            this.dayTxtBox.Size = new System.Drawing.Size(100, 20);
            this.dayTxtBox.TabIndex = 6;
            // 
            // monthTxtBox
            // 
            this.monthTxtBox.Location = new System.Drawing.Point(109, 56);
            this.monthTxtBox.Name = "monthTxtBox";
            this.monthTxtBox.Size = new System.Drawing.Size(100, 20);
            this.monthTxtBox.TabIndex = 7;
            // 
            // monthBtn
            // 
            this.monthBtn.Location = new System.Drawing.Point(229, 52);
            this.monthBtn.Name = "monthBtn";
            this.monthBtn.Size = new System.Drawing.Size(98, 23);
            this.monthBtn.TabIndex = 8;
            this.monthBtn.Text = "Update Month";
            this.monthBtn.UseVisualStyleBackColor = true;
            this.monthBtn.Click += new System.EventHandler(this.monthBtn_Click);
            // 
            // dayBtn
            // 
            this.dayBtn.Location = new System.Drawing.Point(229, 95);
            this.dayBtn.Name = "dayBtn";
            this.dayBtn.Size = new System.Drawing.Size(98, 23);
            this.dayBtn.TabIndex = 9;
            this.dayBtn.Text = "Update Day";
            this.dayBtn.UseVisualStyleBackColor = true;
            this.dayBtn.Click += new System.EventHandler(this.dayBtn_Click);
            // 
            // yearBtn
            // 
            this.yearBtn.Location = new System.Drawing.Point(229, 141);
            this.yearBtn.Name = "yearBtn";
            this.yearBtn.Size = new System.Drawing.Size(98, 23);
            this.yearBtn.TabIndex = 10;
            this.yearBtn.Text = "Update Year";
            this.yearBtn.UseVisualStyleBackColor = true;
            this.yearBtn.Click += new System.EventHandler(this.yearBtn_Click);
            // 
            // lab9Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 192);
            this.Controls.Add(this.yearBtn);
            this.Controls.Add(this.dayBtn);
            this.Controls.Add(this.monthBtn);
            this.Controls.Add(this.monthTxtBox);
            this.Controls.Add(this.dayTxtBox);
            this.Controls.Add(this.yearTxtBox);
            this.Controls.Add(this.yearLbl);
            this.Controls.Add(this.dayLbl);
            this.Controls.Add(this.monthLbl);
            this.Controls.Add(this.outputLbl);
            this.Controls.Add(this.dateLbl);
            this.Name = "lab9Form";
            this.Text = "Lab 9";
            this.Load += new System.EventHandler(this.lab9Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.Label outputLbl;
        private System.Windows.Forms.Label monthLbl;
        private System.Windows.Forms.Label dayLbl;
        private System.Windows.Forms.Label yearLbl;
        private System.Windows.Forms.TextBox yearTxtBox;
        private System.Windows.Forms.TextBox dayTxtBox;
        private System.Windows.Forms.TextBox monthTxtBox;
        private System.Windows.Forms.Button monthBtn;
        private System.Windows.Forms.Button dayBtn;
        private System.Windows.Forms.Button yearBtn;
    }
}

