﻿namespace Lab3
{
    partial class lab3Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionLbl = new System.Windows.Forms.Label();
            this.percent15Lbl = new System.Windows.Forms.Label();
            this.percent18Lbl = new System.Windows.Forms.Label();
            this.percent20Lbl = new System.Windows.Forms.Label();
            this.output15Lbl = new System.Windows.Forms.Label();
            this.output18Lbl = new System.Windows.Forms.Label();
            this.output20Lbl = new System.Windows.Forms.Label();
            this.topicLbl = new System.Windows.Forms.Label();
            this.inputLbl = new System.Windows.Forms.TextBox();
            this.calculateBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionLbl
            // 
            this.instructionLbl.AutoSize = true;
            this.instructionLbl.Location = new System.Drawing.Point(12, 53);
            this.instructionLbl.Name = "instructionLbl";
            this.instructionLbl.Size = new System.Drawing.Size(98, 13);
            this.instructionLbl.TabIndex = 0;
            this.instructionLbl.Text = "Enter price of meal:";
            // 
            // percent15Lbl
            // 
            this.percent15Lbl.AutoSize = true;
            this.percent15Lbl.Location = new System.Drawing.Point(65, 89);
            this.percent15Lbl.Name = "percent15Lbl";
            this.percent15Lbl.Size = new System.Drawing.Size(0, 13);
            this.percent15Lbl.TabIndex = 1;
            // 
            // percent18Lbl
            // 
            this.percent18Lbl.AutoSize = true;
            this.percent18Lbl.Location = new System.Drawing.Point(65, 123);
            this.percent18Lbl.Name = "percent18Lbl";
            this.percent18Lbl.Size = new System.Drawing.Size(0, 13);
            this.percent18Lbl.TabIndex = 2;
            // 
            // percent20Lbl
            // 
            this.percent20Lbl.AutoSize = true;
            this.percent20Lbl.Location = new System.Drawing.Point(65, 157);
            this.percent20Lbl.Name = "percent20Lbl";
            this.percent20Lbl.Size = new System.Drawing.Size(0, 13);
            this.percent20Lbl.TabIndex = 3;
            // 
            // output15Lbl
            // 
            this.output15Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output15Lbl.Location = new System.Drawing.Point(116, 88);
            this.output15Lbl.Name = "output15Lbl";
            this.output15Lbl.Size = new System.Drawing.Size(100, 23);
            this.output15Lbl.TabIndex = 4;
            // 
            // output18Lbl
            // 
            this.output18Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output18Lbl.Location = new System.Drawing.Point(116, 122);
            this.output18Lbl.Name = "output18Lbl";
            this.output18Lbl.Size = new System.Drawing.Size(100, 23);
            this.output18Lbl.TabIndex = 5;
            // 
            // output20Lbl
            // 
            this.output20Lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output20Lbl.Location = new System.Drawing.Point(116, 156);
            this.output20Lbl.Name = "output20Lbl";
            this.output20Lbl.Size = new System.Drawing.Size(100, 23);
            this.output20Lbl.TabIndex = 6;
            // 
            // topicLbl
            // 
            this.topicLbl.AutoSize = true;
            this.topicLbl.Location = new System.Drawing.Point(110, 19);
            this.topicLbl.Name = "topicLbl";
            this.topicLbl.Size = new System.Drawing.Size(72, 13);
            this.topicLbl.TabIndex = 7;
            this.topicLbl.Text = "Tip Calculator";
            // 
            // inputLbl
            // 
            this.inputLbl.Location = new System.Drawing.Point(116, 50);
            this.inputLbl.Name = "inputLbl";
            this.inputLbl.Size = new System.Drawing.Size(100, 20);
            this.inputLbl.TabIndex = 8;
            // 
            // calculateBtn
            // 
            this.calculateBtn.Location = new System.Drawing.Point(109, 196);
            this.calculateBtn.Name = "calculateBtn";
            this.calculateBtn.Size = new System.Drawing.Size(107, 23);
            this.calculateBtn.TabIndex = 9;
            this.calculateBtn.Text = "Calculate Tip";
            this.calculateBtn.UseVisualStyleBackColor = true;
            this.calculateBtn.Click += new System.EventHandler(this.calculateBtn_Click);
            // 
            // lab3Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.calculateBtn);
            this.Controls.Add(this.inputLbl);
            this.Controls.Add(this.topicLbl);
            this.Controls.Add(this.output20Lbl);
            this.Controls.Add(this.output18Lbl);
            this.Controls.Add(this.output15Lbl);
            this.Controls.Add(this.percent20Lbl);
            this.Controls.Add(this.percent18Lbl);
            this.Controls.Add(this.percent15Lbl);
            this.Controls.Add(this.instructionLbl);
            this.Name = "lab3Form";
            this.Text = "Lab 3";
            this.Load += new System.EventHandler(this.lab3Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLbl;
        private System.Windows.Forms.Label percent15Lbl;
        private System.Windows.Forms.Label percent18Lbl;
        private System.Windows.Forms.Label percent20Lbl;
        private System.Windows.Forms.Label output15Lbl;
        private System.Windows.Forms.Label output18Lbl;
        private System.Windows.Forms.Label output20Lbl;
        private System.Windows.Forms.Label topicLbl;
        private System.Windows.Forms.TextBox inputLbl;
        private System.Windows.Forms.Button calculateBtn;
    }
}

