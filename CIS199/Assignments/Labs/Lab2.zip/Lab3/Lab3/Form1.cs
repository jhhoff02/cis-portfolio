﻿/*
 * Grading ID: A9703
 * Lab 3
 * Due: September 25, 2016
 * CIS 199-01
 * This program contains labels, a textbox input, and a button on a form. 
 * The user enters check amount, and clicks the button. 
 * The outputs labels display the respective tip amounts for 15%, 18%, and 20% formatted as currency.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class lab3Form : Form
    {
        public lab3Form()
        {
            InitializeComponent();
        }

        private void calculateBtn_Click(object sender, EventArgs e) //This Click event handler runs when the user clicks the "Calculate Tip" button
        {
            const float LOW_TIP_RATE = 0.15f; //Named constant that holds the floating point 0.15
            const float MEDIUM_TIP_RATE = 0.18f; //Named constant that holds the floating point 0.18
            const float HIGH_TIP_RATE = 0.20f; //Named constant that holds the floating point 0.20
            float parsedInput = float.Parse(inputLbl.Text); //Float variable that stores the number conversion of the string user input
            float percent15Result; //This float variable will store the calculated 15% tip amount before it is formatted as a string
            float percent18Result; //This float variable will store the calculated 18% tip amount before it is formatted as a string
            float percent20Result; //This float variable will store the calculated 20% tip amount before it is formatted as a string

            percent15Result = LOW_TIP_RATE * parsedInput;
            percent18Result = MEDIUM_TIP_RATE * parsedInput;
            percent20Result = HIGH_TIP_RATE * parsedInput;

            output15Lbl.Text = percent15Result.ToString("C");
            output18Lbl.Text = percent18Result.ToString("C");
            output20Lbl.Text = percent20Result.ToString("C");
        }

        private void lab3Form_Load(object sender, EventArgs e) //This Load event handler runs when the program is started without user interaction
        {
            percent15Lbl.Text = "15%"; //Initializes percent15Lbl to 15% to avoid hardcoding in Text property
            percent18Lbl.Text = "18%"; //Initializes percent15Lbl to 18% to avoid hardcoding in Text property
            percent20Lbl.Text = "20%"; //Initializes percent15Lbl to 20% to avoid hardcoding in Text property
        }
    }
}
