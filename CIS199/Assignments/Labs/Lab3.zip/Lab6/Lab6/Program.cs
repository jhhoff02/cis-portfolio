﻿/*
 * Grading ID: A9703
 * Lab 6
 * Due: October 30, 2016
 * CIS 199-01
 * This console application displays various star patterns using nested loops
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX_ROWS = 10; //Constant integer variable specifying the max number of rows of stars to be printed

            //Begin Pattern A loops
            Console.Write("Pattern A");
            Console.WriteLine();
            Console.WriteLine();
            for (int row = 1; row <= MAX_ROWS; row++) //Outer loop for printing rows
            {
                for (int star = 1; star <= row; star++)  //Inner loop for printing stars
                    Console.Write("*");
                Console.WriteLine();
            }
            Console.WriteLine();

            //Begin Pattern B loops
            Console.Write("Pattern B");
            Console.WriteLine();
            Console.WriteLine();
            for (int row = 1; row <= MAX_ROWS; row++) //Outer loop for printing rows
            {
                for (int star = 10; star >= row; star--) //Inner loop for printing stars
                    Console.Write("*");
                Console.WriteLine();
            }

            Console.WriteLine();

            //Begin Pattern C loops
            Console.Write("Pattern C");
            Console.WriteLine();
            Console.WriteLine();
            for (int row = 1; row <= MAX_ROWS; row++) //Outer loop for printing rows
            {
                for (int space = 9; space > MAX_ROWS - row; space--) //Inner loop for printing spaces
                { 
                    Console.Write(" ");
                }
                for (int star = 10; star >= row; star--) //Inner loop for printing stars
                {
                    Console.Write("*");
                }
                Console.WriteLine("");
            }

            Console.WriteLine();

            //Begin Pattern D loops
            Console.Write("Pattern D");
            Console.WriteLine();
            Console.WriteLine();
            for (int row = 1; row <= MAX_ROWS; row++) //Outer loop for printing rows
            {
                for (int space = 1; space <= MAX_ROWS - row; space++) //Inner loop for printing spaces
                {
                    Console.Write(" ");
                }
                for (int star = 1; star <= row; star++) //Inner loop for printing stars
                {
                    Console.Write("*");
                }
                Console.WriteLine("");
            }
        }
    }
}
