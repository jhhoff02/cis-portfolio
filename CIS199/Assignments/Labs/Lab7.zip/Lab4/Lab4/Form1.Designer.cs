﻿namespace Lab4
{
    partial class lab4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.instructionsLbl = new System.Windows.Forms.Label();
            this.gpaLbl = new System.Windows.Forms.Label();
            this.testScoreLbl = new System.Windows.Forms.Label();
            this.gpaInputBox = new System.Windows.Forms.TextBox();
            this.testScoreInputBox = new System.Windows.Forms.TextBox();
            this.admissionsLbl = new System.Windows.Forms.Label();
            this.rejectionsLbl = new System.Windows.Forms.Label();
            this.admissionsOutputLbl = new System.Windows.Forms.Label();
            this.rejectionsOutputLbl = new System.Windows.Forms.Label();
            this.applyBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // instructionsLbl
            // 
            this.instructionsLbl.AutoSize = true;
            this.instructionsLbl.Location = new System.Drawing.Point(12, 9);
            this.instructionsLbl.Name = "instructionsLbl";
            this.instructionsLbl.Size = new System.Drawing.Size(176, 17);
            this.instructionsLbl.TabIndex = 0;
            this.instructionsLbl.Text = "Enter GPA and Test Score";
            // 
            // gpaLbl
            // 
            this.gpaLbl.AutoSize = true;
            this.gpaLbl.Location = new System.Drawing.Point(51, 43);
            this.gpaLbl.Name = "gpaLbl";
            this.gpaLbl.Size = new System.Drawing.Size(37, 17);
            this.gpaLbl.TabIndex = 1;
            this.gpaLbl.Text = "GPA";
            // 
            // testScoreLbl
            // 
            this.testScoreLbl.AutoSize = true;
            this.testScoreLbl.Location = new System.Drawing.Point(35, 110);
            this.testScoreLbl.Name = "testScoreLbl";
            this.testScoreLbl.Size = new System.Drawing.Size(77, 17);
            this.testScoreLbl.TabIndex = 2;
            this.testScoreLbl.Text = "Test Score";
            // 
            // gpaInputBox
            // 
            this.gpaInputBox.Location = new System.Drawing.Point(21, 70);
            this.gpaInputBox.Name = "gpaInputBox";
            this.gpaInputBox.Size = new System.Drawing.Size(100, 22);
            this.gpaInputBox.TabIndex = 3;
            // 
            // testScoreInputBox
            // 
            this.testScoreInputBox.Location = new System.Drawing.Point(21, 135);
            this.testScoreInputBox.Name = "testScoreInputBox";
            this.testScoreInputBox.Size = new System.Drawing.Size(100, 22);
            this.testScoreInputBox.TabIndex = 4;
            // 
            // admissionsLbl
            // 
            this.admissionsLbl.AutoSize = true;
            this.admissionsLbl.Location = new System.Drawing.Point(198, 70);
            this.admissionsLbl.Name = "admissionsLbl";
            this.admissionsLbl.Size = new System.Drawing.Size(115, 17);
            this.admissionsLbl.TabIndex = 5;
            this.admissionsLbl.Text = "Total Admissions";
            // 
            // rejectionsLbl
            // 
            this.rejectionsLbl.AutoSize = true;
            this.rejectionsLbl.Location = new System.Drawing.Point(198, 135);
            this.rejectionsLbl.Name = "rejectionsLbl";
            this.rejectionsLbl.Size = new System.Drawing.Size(110, 17);
            this.rejectionsLbl.TabIndex = 6;
            this.rejectionsLbl.Text = "Total Rejections";
            // 
            // admissionsOutputLbl
            // 
            this.admissionsOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.admissionsOutputLbl.Location = new System.Drawing.Point(201, 92);
            this.admissionsOutputLbl.Name = "admissionsOutputLbl";
            this.admissionsOutputLbl.Size = new System.Drawing.Size(100, 23);
            this.admissionsOutputLbl.TabIndex = 7;
            // 
            // rejectionsOutputLbl
            // 
            this.rejectionsOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rejectionsOutputLbl.Location = new System.Drawing.Point(201, 157);
            this.rejectionsOutputLbl.Name = "rejectionsOutputLbl";
            this.rejectionsOutputLbl.Size = new System.Drawing.Size(100, 23);
            this.rejectionsOutputLbl.TabIndex = 8;
            // 
            // applyBtn
            // 
            this.applyBtn.Location = new System.Drawing.Point(28, 173);
            this.applyBtn.Name = "applyBtn";
            this.applyBtn.Size = new System.Drawing.Size(84, 26);
            this.applyBtn.TabIndex = 9;
            this.applyBtn.Text = "Apply";
            this.applyBtn.UseVisualStyleBackColor = true;
            this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
            // 
            // lab4Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 211);
            this.Controls.Add(this.applyBtn);
            this.Controls.Add(this.rejectionsOutputLbl);
            this.Controls.Add(this.admissionsOutputLbl);
            this.Controls.Add(this.rejectionsLbl);
            this.Controls.Add(this.admissionsLbl);
            this.Controls.Add(this.testScoreInputBox);
            this.Controls.Add(this.gpaInputBox);
            this.Controls.Add(this.testScoreLbl);
            this.Controls.Add(this.gpaLbl);
            this.Controls.Add(this.instructionsLbl);
            this.Name = "lab4Form";
            this.Text = "Lab 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionsLbl;
        private System.Windows.Forms.Label gpaLbl;
        private System.Windows.Forms.Label testScoreLbl;
        private System.Windows.Forms.TextBox gpaInputBox;
        private System.Windows.Forms.TextBox testScoreInputBox;
        private System.Windows.Forms.Label admissionsLbl;
        private System.Windows.Forms.Label rejectionsLbl;
        private System.Windows.Forms.Label admissionsOutputLbl;
        private System.Windows.Forms.Label rejectionsOutputLbl;
        private System.Windows.Forms.Button applyBtn;
    }
}

