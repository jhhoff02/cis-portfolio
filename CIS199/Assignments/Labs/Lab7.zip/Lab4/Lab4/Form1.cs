﻿/*
 * Grading ID: A9703
 * Lab 4
 * Due: October 2, 2016
 * CIS 199-01
 * This program contains labels, 2 textbox inputs, and a button on a form. 
 * The user enters GPA and test score, and clicks the button. 
 * The program displays "Accept" or "Reject" based on decisions made in the code.
 * The program also keeps running totals for the number of times applications were accepted or rejected.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class lab4Form : Form
    {
        private uint admissionsCount = 0; //Variable that will hold the count of admissions while the program is running
        private uint rejectionsCount = 0; //Variable that will hold the count of rejections while the program is running
        public lab4Form()
        {
            InitializeComponent();
        }

        //Click event handler that decides whether the applicant is accepted or rejected
        private void applyBtn_Click(object sender, EventArgs e)
        {
            const float GPA = 3.0f; //Named constant that holds an important GPA as a float
            const uint LOW_TEST_SCORE = 60; //Named constant that holds a low test score as an unsigned int
            const uint HIGH_TEST_SCORE = 80; //Named constant that holds a high test score as an unsigned int
            float parsedGPA; // Float variable that stores the GPA after the TryParse
            uint parsedTestScore; // Unsigned int variable that stores the test score after the TryParse

            //Tries to parse gpaInputBox and store it as a float in parsedGPA. Displays error message if it fails.
            if (float.TryParse(gpaInputBox.Text, out parsedGPA))
            {
                //Tries to parse testScoreInputBox and store it as a uint in parsedTestScore. Displays error message if it fails.
                if (uint.TryParse(testScoreInputBox.Text, out parsedTestScore))
                {
                    //Calculations and Decisions Below
                    if(parsedGPA >= GPA)
                    {
                        if(parsedTestScore >= LOW_TEST_SCORE)
                        {
                            MessageBox.Show("You have been accepted!");
                            admissionsCount += 1;
                        } else
                        {
                            MessageBox.Show("You have been rejected.");
                            rejectionsCount += 1;
                        }
                    } else
                    {
                        if(parsedTestScore >= HIGH_TEST_SCORE)
                        {
                            MessageBox.Show("You have been accepted!");
                            admissionsCount += 1;
                        } else
                        {
                            MessageBox.Show("You have been rejected.");
                            rejectionsCount += 1;
                        }
                    }

                    //Formatting and Display code below
                    admissionsOutputLbl.Text = admissionsCount.ToString("N0");
                    rejectionsOutputLbl.Text = rejectionsCount.ToString("N0");
                }
                else
                {
                    MessageBox.Show("This is not a valid input for Test Score");
                };
            }
            else
            {
                MessageBox.Show("This is not a valid input for GPA");
            };
        }
    
    }
}
