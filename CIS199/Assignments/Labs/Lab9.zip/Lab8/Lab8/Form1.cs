﻿/*
 * Grading ID: A9703
 * Lab 8
 * Due: November 13, 2016
 * CIS 199-01
 * This program contains labels, a button, and a textbox on a form. 
 * The user enters distance as an integer, and the program outputs the price for their ticket based on distance input.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab8
{
    public partial class lab8Form : Form
    {
        public lab8Form()
        {
            InitializeComponent();
        }

        private void getPriceBtn_Click(object sender, EventArgs e)
        {
            int parsedMiles; // int variable that stores distance in miles after the TryParse
            int[] milesRangeLow = { 0, 100, 300, 500 }; //Array of integers used to determine distance ranges
            float[] prices = { 25.00f, 40.00f, 55.00f, 70.00f }; //Array of float values for ticket prices
            bool found = false; //Boolean flag, stores true if value is found

            //Begin TryParse to parse int from user miles input, displays error message for invalid inputs
            if (int.TryParse(inputTextBox.Text, out parsedMiles) && parsedMiles > 0)
            {
                int index = milesRangeLow.Length - 1; // int variable for keeping track of index in arrays
                //Begin while loop for locating correct price based on distance
                while(index >= 0 && !found)
                {
                    if(parsedMiles >= milesRangeLow[index])
                    {
                        found = true;
                    } else
                    {
                        index--;
                    }
                }
                //Display price if found in array
                if (found)
                {
                    outputLbl.Text = prices[index].ToString("C2");
                }
            }
            else
            {
                MessageBox.Show("Please enter a positive whole number");
            }
        }
    }
}
