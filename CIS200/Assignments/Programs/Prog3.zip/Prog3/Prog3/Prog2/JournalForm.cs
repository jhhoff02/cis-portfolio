﻿// Program 3
// Grading ID: D4929
// Due Date: 4/3/17
// Course Section: CIS 200-01

// File: JournalForm.cs
// This class creates the Journal dialog box form GUI. It performs validation
// and provides String properties for each field.
// JournalForm IS-A ItemFormBase

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class JournalForm : ItemFormBase
    {
        public JournalForm()
        {
            InitializeComponent();
        }

        internal String ItemVolume
        {
            // Precondition:  None
            // Postcondition: The text of form's volume field has been returned
            get
            {
                return volumeTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's volume field has been set to the specified value
            set
            {
                volumeTxtBox.Text = value;
            }
        }

        internal String ItemNumber
        {
            // Precondition:  None
            // Postcondition: The text of form's number field has been returned
            get
            {
                return numTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's number field has been set to the specified value
            set
            {
                numTxtBox.Text = value;
            }
        }

        internal String ItemDiscipline
        {
            // Precondition:  None
            // Postcondition: The text of form's discipline field has been returned
            get
            {
                return disciplineTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's discipline field has been set to the specified value
            set
            {
                disciplineTxtBox.Text = value;
            }
        }

        internal String ItemEditor
        {
            // Precondition:  None
            // Postcondition: The text of form's editor field has been returned
            get
            {
                return editorTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's editor field has been set to the specified value
            set
            {
                editorTxtBox.Text = value;
            }
        }
    }
}
