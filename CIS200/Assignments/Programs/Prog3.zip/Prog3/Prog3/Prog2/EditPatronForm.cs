﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class EditPatronForm : Form
    {
        private List<LibraryPatron> _patrons; // List of library patrons

        // Precondition:  Edit, Patron is chosen from menu
        // Postcondition: The form's GUI is prepared for display. _patrons is populated with the 
        // available LibraryPatrons to choose from
        public EditPatronForm(List<LibraryPatron> patronList)
        {
            InitializeComponent();
            _patrons = patronList;
        }

        internal int ItemIndex
        {
            // Precondition:  None
            // Postcondition: The index of form's selected patron combo box has been returned
            get
            {
                return itemCbo.SelectedIndex;
            }
        }

        // Precondition:  None
        // Postcondition: The list of patrons is used to populate the
        //                item combo box
        private void EditPatronForm_Load(object sender, EventArgs e)
        {
            foreach (LibraryPatron patron in _patrons)
                itemCbo.Items.Add(patron.PatronName + ", " + patron.PatronID);
        }

        // Precondition:  User pressed on okBtn
        // Postcondition: Form closes and sends OK result
        private void okBtn_Click(object sender, EventArgs e)
        {
            if (itemCbo.SelectedIndex > -1)
            {
                this.DialogResult = DialogResult.OK; // Causes form to close and return OK result
                this.Close(); //Close form because patron form is going to open.
            }
            else
            {
                if (_patrons.Count < 1) //Prompt to insert patrons if there are none
                    MessageBox.Show("There are no patrons to choose from, open a Library file or insert a patron");
                else //Prompt select patron
                    MessageBox.Show("Please select a patron to continue");
            }
        }

        // Precondition:  User pressed on cancelBtn
        // Postcondition: Form closes and sends Cancel result
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; //Close form
        }
    }
}
