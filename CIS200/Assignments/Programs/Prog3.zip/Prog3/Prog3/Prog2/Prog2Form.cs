﻿// Program 3
// Grading ID: D4929
// Due Date: 4/3/17
// Course Section: CIS 200-01

// File: Prog2Form.cs
// This class creates the main GUI for Program 2. It provides a
// File menu with About and Exit items, an Insert menu with Patron and
// Book items, an Item menu with Check Out and Return items, and a
// Report menu with Patron List, Item List, and Checked Out Items items.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace LibraryItems
{
    public partial class Prog2Form : Form
    {
        private Library _lib; // The library

        // Precondition:  None
        // Postcondition: The form's GUI is prepared for display. A few test items and patrons
        //                are added to the library
        public Prog2Form()
        {
            InitializeComponent();

            _lib = new Library(); // Create the library
        }

        // Precondition:  File, About menu item activated
        // Postcondition: Information about author displayed in dialog box
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine; // NewLine shortcut

            MessageBox.Show($"Program 3{NL}By: Jessica Hoffman{NL}CIS 200-01{NL}Spring 2017",
                "About Program 3");
        }

        // Precondition:  File, Exit menu item activated
        // Postcondition: The application is exited
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Precondition:  Report, Patron List menu item activated
        // Postcondition: The list of patrons is displayed in the reportTxt
        //                text box
        private void patronListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            List<LibraryPatron> patrons;                // List of patrons
            string NL = Environment.NewLine;            // NewLine shortcut

            patrons = _lib.GetPatronsList();

            result.Append($"Patron List - {patrons.Count} patrons{NL}{NL}");

            foreach (LibraryPatron p in patrons)
                result.Append($"{p}{NL}{NL}");

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Report, Item List menu item activated
        // Postcondition: The list of items is displayed in the reportTxt
        //                text box
        private void itemListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            List<LibraryItem> items;                    // List of library items
            string NL = Environment.NewLine;            // NewLine shortcut

            items = _lib.GetItemsList();

            result.Append($"Item List - {items.Count} items{NL}{NL}");

            foreach (LibraryItem item in items)
                result.Append($"{item}{NL}{NL}");

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Report, Checked Out Items menu item activated
        // Postcondition: The list of checked out items is displayed in the
        //                reportTxt text box
        private void checkedOutItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // Holds text as report being built
                                                        // StringBuilder more efficient than String
            List<LibraryItem> items;                    // List of library items
            string NL = Environment.NewLine;            // NewLine shortcut

            items = _lib.GetItemsList();

            // LINQ: selects checked out items
            var checkedOutItems =
                from item in items
                where item.IsCheckedOut()
                select item;

            result.Append($"Checked Out Items - {checkedOutItems.Count()} items{NL}{NL}");

            foreach (LibraryItem item in checkedOutItems)
                result.Append($"{item}{NL}{NL}");

            reportTxt.Text = result.ToString();

            // Put cursor at start of report
            reportTxt.SelectionStart = 0;
        }

        // Precondition:  Insert, Patron menu item activated
        // Postcondition: The Patron dialog box is displayed. If data entered
        //                are OK, a LibraryPatron is created and added to the library
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PatronForm patronForm = new PatronForm(); // The patron dialog box form

            DialogResult result = patronForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                // Use form's properties to get patron info to send to library
                _lib.AddPatron(patronForm.PatronName, patronForm.PatronID);
            }

            patronForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        // Precondition:  Insert, Book menu item activated
        // Postcondition: The Book dialog box is displayed. If data entered
        //                are OK, a LibraryBook is created and added to the library
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookForm bookForm = new BookForm(); // The book dialog box form

            DialogResult result = bookForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try
                {
                    // Use form's properties to get book info to send to library
                    _lib.AddLibraryBook(bookForm.ItemTitle, bookForm.ItemPublisher, int.Parse(bookForm.ItemCopyrightYear),
                        int.Parse(bookForm.ItemLoanPeriod), bookForm.ItemCallNumber, bookForm.BookAuthor);
                }

                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Book Validation!", "Validation Error");
                }
            }

            bookForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        // Precondition:  Item, Check Out menu item activated
        // Postcondition: The Checkout dialog box is displayed. If data entered
        //                are OK, an item is checked out from the library by a patron
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Extra Credit - Only display items that aren't already checked out

            List<LibraryItem> notCheckedOutList; // List of items not checked out
            List<int> notCheckedOutIndices;      // List of index values of items not checked out
            List<LibraryItem> items;             // List of library items
            List<LibraryPatron> patrons;         // List of patrons

            items = _lib.GetItemsList();
            patrons = _lib.GetPatronsList();
            notCheckedOutList = new List<LibraryItem>();
            notCheckedOutIndices = new List<int>();

            for (int i = 0; i < items.Count(); ++i)
                if (!items[i].IsCheckedOut()) // Not checked out
                {
                    notCheckedOutList.Add(items[i]);
                    notCheckedOutIndices.Add(i);
                }

            if ((notCheckedOutList.Count() == 0) || (patrons.Count() == 0)) // Must have items and patrons
                MessageBox.Show("Must have items and patrons to check out!", "Check Out Error");
            else
            {
                CheckoutForm checkoutForm = new CheckoutForm(notCheckedOutList, patrons); // The check out dialog box form

                DialogResult result = checkoutForm.ShowDialog(); // Show form as dialog and store result

                if (result == DialogResult.OK) // Only add if OK
                {
                    try
                    {
                        int itemIndex; // Index of item from full list of items

                        itemIndex = notCheckedOutIndices[checkoutForm.ItemIndex]; // Look up index from full list
                        _lib.CheckOut(itemIndex, checkoutForm.PatronIndex);
                    }
                    catch (ArgumentOutOfRangeException) // This should never happen
                    {
                        MessageBox.Show("Problem with Check Out Index!", "Check Out Error");
                    }
                }

                checkoutForm.Dispose(); // Good .NET practice - will get garbage collected anyway
            }
        }

        // Precondition:  Item, Return menu item activated
        // Postcondition: The Return dialog box is displayed. If data entered
        //                are OK, an item is returned to the library
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Extra Credit - Only display items that are already checked out

            List<LibraryItem> checkedOutList; // List of items checked out
            List<int> checkedOutIndices;      // List of index values of items checked out
            List<LibraryItem> items;     // List of library items

            items = _lib.GetItemsList();
            checkedOutList = new List<LibraryItem>();
            checkedOutIndices = new List<int>();

            for (int i = 0; i < items.Count(); ++i)
                if (items[i].IsCheckedOut()) // Checked out
                {
                    checkedOutList.Add(items[i]);
                    checkedOutIndices.Add(i);
                }

            if ((checkedOutList.Count() == 0)) // Must have checked out items
                MessageBox.Show("Must have items to return!", "Return Error");
            else
            {
                ReturnForm returnForm = new ReturnForm(checkedOutList); // The return dialog box form

                DialogResult result = returnForm.ShowDialog(); // Show form as dialog and store result

                if (result == DialogResult.OK) // Only add if OK
                {
                    try
                    {
                        int itemIndex; // Index of item from full list of items

                        itemIndex = checkedOutIndices[returnForm.ItemIndex]; // Look up index from full list
                        _lib.ReturnToShelf(itemIndex);
                    }
                    catch (ArgumentOutOfRangeException) // This should never happen
                    {
                        MessageBox.Show("Problem with Return Index!", "Return Error");
                    }
                }

                returnForm.Dispose(); // Good .NET practice - will get garbage collected anyway
            }
        }

        // Precondition:  File, Open Library menu item activated
        // Postcondition: The user is prompted to select a Library file to open. If file chosen is valid,
        // the data in the file will replace the existing library.
        private void openLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FileStream loadedData; //FileStream obj using user's file name
            Library record; //Library obj that stores deserialized data from chosen file
            BinaryFormatter reader; //Binary Formatter obj

            using (var fileChooser = new SaveFileDialog())
                {
                    DialogResult result = fileChooser.ShowDialog(); // Show file chooser as dialog and store result
                    string userFileName = fileChooser.FileName; //temp string variable to store user input for file name
                    
                    if (result == DialogResult.OK && userFileName.Length > 0) //Open File
                    {
                        try
                        {
                            loadedData = new FileStream(userFileName, FileMode.Open, FileAccess.Read); //FileStream obj using user's file name
                            reader = new BinaryFormatter(); //Binary Formatter obj
                                try
                                {
                                    record = (Library)reader.Deserialize(loadedData);
                                    _lib = record; //overwrite current library with file data
                                }
                                catch (SerializationException)
                                {
                                    MessageBox.Show("Something went wrong. Please make sure your Library file is valid.");
                                }
                            
                        }
                        catch (FileNotFoundException)
                        {
                            MessageBox.Show("This file does not exist.");
                        }
                    }
                    else if(result == DialogResult.OK && userFileName.Length <= 0)
                    {
                        MessageBox.Show("No File Chosen");
                    }
                    else if(result == DialogResult.Cancel)
                    {
                        //Do Nothing
                    }
                }
        }

        // Precondition:  File, Save Library menu item activated
        // Postcondition: The program tries to save the current library as a file. If the file is serialized successfully,
        // it will be saved. The user can then open the file in the future. 
        private void saveLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveLibraryForm saveForm = new SaveLibraryForm(); // The save library dialog box form

            DialogResult result = saveForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only exec if OK
            {
                try
                {
                    BinaryFormatter reader = new BinaryFormatter(); //Create BinaryFormatter object
                    Stream stream = new FileStream($"{saveForm.FileName}.dat", FileMode.Create, FileAccess.Write, FileShare.None); //Create stream using user's file name
                    reader.Serialize(stream, _lib); //serialize current library
                    stream.Close();

                    saveForm.Close();
                }
                catch (IOException)
                {
                    MessageBox.Show("Something went wrong. Please make sure your Library file is valid.");
                }
            }
            saveForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        // Precondition:  Edit, Patron menu item activated
        // Postcondition: The Edit Patron dialog box is displayed. The user selects patron to edit from list of patrons
        // If data entered is valid, this data replaces the existing data for that patron (does not create new patron)
        private void patronToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            EditPatronForm editPatronForm = new EditPatronForm(_lib._patrons); // The edit patron dialog box form

            DialogResult editPatronResult = editPatronForm.ShowDialog(); // Show form as dialog and store result

            if (editPatronResult == DialogResult.OK) // Only exec if OK
            {
                PatronForm patronForm = new PatronForm(); // The book dialog box form

                LibraryPatron selectedPatron = _lib._patrons[editPatronForm.ItemIndex]; //Create temp LibraryPatron obj with values of selected patron
                patronForm.PatronName = selectedPatron.PatronName;
                patronForm.PatronID = selectedPatron.PatronID;

                DialogResult patronFormResult = patronForm.ShowDialog(); // Show form as dialog and store result

                if (patronFormResult == DialogResult.OK) // Only add if OK
                {
                    try
                    {
                        selectedPatron.PatronName = patronForm.PatronName; //Overwrite relevant PatronName with user's edit
                        selectedPatron.PatronID = patronForm.PatronID; //Overwrite relevant PatronID with user's edit
                    }

                    catch (FormatException) // This should never happen if form validation works!
                    {
                        MessageBox.Show("Problem with Patron Validation!", "Validation Error");
                    }
                }

                patronForm.Dispose(); // Good .NET practice - will get garbage collected anyway
            }

            editPatronForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        // Precondition:  Edit, Book menu item activated
        // Postcondition: The Edit Book dialog box is displayed. The user selects item to edit from list of items.
        // based on the type of item selected, the appropriate form will be displayed
        private void bookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            EditBookForm editBookForm = new EditBookForm(_lib._items); // The edit book dialog box form

            DialogResult editBookResult = editBookForm.ShowDialog(); // Show form as dialog and store result

            if(editBookResult == DialogResult.OK) // Only exec if OK
            {
                LibraryItem selectedBook = _lib._items[editBookForm.ItemIndex]; //Create temp LibraryItem obj with values of selected book
                if (selectedBook.GetType() == typeof(LibraryBook))
                {
                    EditBook((LibraryBook)selectedBook, editBookForm.ItemIndex);
                }
                else if (selectedBook.GetType() == typeof(LibraryJournal))
                {
                    EditJournal((LibraryJournal)selectedBook, editBookForm.ItemIndex);
                }
                else if (selectedBook.GetType() == typeof(LibraryMagazine))
                {
                    EditMagazine((LibraryMagazine)selectedBook, editBookForm.ItemIndex);
                }
                else if (selectedBook.GetType() == typeof(LibraryMovie))
                {
                    EditMovie((LibraryMovie)selectedBook, editBookForm.ItemIndex);
                }
                else if (selectedBook.GetType() == typeof(LibraryMusic))
                {
                    EditMusic((LibraryMusic)selectedBook, editBookForm.ItemIndex);
                }
            } 
            editBookForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        //Precondition: The item selected for editing is a LibraryBook
        //Postcondition: If data entered is valid, this data replaces the existing data for that item (does not create new item)
        private void EditBook(LibraryBook item, int itemIndex)
        {
            BookForm bookForm = new BookForm(); //The edit book dialog box form
            bookForm.ItemTitle = item.Title;
            bookForm.ItemPublisher = item.Publisher;
            bookForm.ItemCopyrightYear = item.CopyrightYear.ToString();
            bookForm.ItemLoanPeriod = item.LoanPeriod.ToString();
            bookForm.ItemCallNumber = item.CallNumber;
            bookForm.BookAuthor = item.Author;
            DialogResult result = bookForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try //Overwrite relevant Item properties with user's edits
                {
                    int parsedCR; //int variable for parsed CR year
                    int parsedLP; //int variable for parsed loan period
                    
                    //Precondition: The user entered data for copyright year
                    //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                    // property, otherwise, an error is displayed
                    if (int.TryParse(bookForm.ItemCopyrightYear, out parsedCR) && !String.IsNullOrWhiteSpace(bookForm.ItemCopyrightYear))
                    {
                        //Precondition: The user entered data for loan period
                        //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                        // property, otherwise, an error is displayed
                        if (int.TryParse(bookForm.ItemLoanPeriod, out parsedLP) && !String.IsNullOrWhiteSpace(bookForm.ItemLoanPeriod))
                        {
                            if (!String.IsNullOrWhiteSpace(bookForm.ItemTitle) &&
                                !String.IsNullOrWhiteSpace(bookForm.ItemPublisher) &&
                                !String.IsNullOrWhiteSpace(bookForm.ItemCallNumber) &&
                                !String.IsNullOrWhiteSpace(bookForm.BookAuthor))
                            {
                                item.Title = bookForm.ItemTitle;
                                item.Publisher = bookForm.ItemPublisher;
                                item.CopyrightYear = parsedCR;
                                item.LoanPeriod = parsedLP;
                                item.CallNumber = bookForm.ItemCallNumber;
                                item.Author = bookForm.BookAuthor;
                            }
                            else
                            {
                                MessageBox.Show("Edit aborted, one or more required fields were left blank");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Edit aborted, loan period was invalid");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Edit aborted, copyright year was invalid");
                    }
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Validation!", "Validation Error");
                }
            }
            bookForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        //Precondition: The item selected for editing is a LibraryJournal
        //Postcondition: If data entered is valid, this data replaces the existing data for that item (does not create new item)
        private void EditJournal(LibraryJournal item, int itemIndex)
        {
            JournalForm journalForm = new JournalForm(); //The edit journal dialog box form
            journalForm.ItemTitle = item.Title;
            journalForm.ItemPublisher = item.Publisher;
            journalForm.ItemCopyrightYear = item.CopyrightYear.ToString();
            journalForm.ItemLoanPeriod = item.LoanPeriod.ToString();
            journalForm.ItemCallNumber = item.CallNumber;
            journalForm.ItemVolume = item.Volume.ToString();
            journalForm.ItemNumber = item.Number.ToString();
            journalForm.ItemDiscipline = item.Discipline;
            journalForm.ItemEditor = item.Editor;
            DialogResult result = journalForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try //Overwrite relevant Item properties with user's edits
                {
                    int parsedCR; //int variable for parsed CR year
                    int parsedLP; //int variable for parsed loan period
                    int parsedVolume; //int variable for parsed volume
                    int parsedNumber; //int variable for parsed number
                    
                    //Precondition: The user entered data for copyright year
                    //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                    // property, otherwise, an error is displayed
                    if (int.TryParse(journalForm.ItemCopyrightYear, out parsedCR) && !String.IsNullOrWhiteSpace(journalForm.ItemCopyrightYear))
                    {
                        //Precondition: The user entered data for loan period
                        //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                        // property, otherwise, an error is displayed
                        if (int.TryParse(journalForm.ItemLoanPeriod, out parsedLP) && !String.IsNullOrWhiteSpace(journalForm.ItemLoanPeriod))
                        {
                            //Precondition: The user entered data for volume
                            //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                            // property, otherwise, an error is displayed
                            if (int.TryParse(journalForm.ItemVolume, out parsedVolume) && !String.IsNullOrWhiteSpace(journalForm.ItemVolume))
                            {
                                //Precondition: The user entered data for number
                                //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                                // property, otherwise, an error is displayed
                                if (int.TryParse(journalForm.ItemNumber, out parsedNumber) && !String.IsNullOrWhiteSpace(journalForm.ItemNumber))
                                {
                                    if (!String.IsNullOrWhiteSpace(journalForm.ItemTitle) &&
                                           !String.IsNullOrWhiteSpace(journalForm.ItemPublisher) &&
                                           !String.IsNullOrWhiteSpace(journalForm.ItemCallNumber) &&
                                           !String.IsNullOrWhiteSpace(journalForm.ItemDiscipline) &&
                                           !String.IsNullOrWhiteSpace(journalForm.ItemEditor))
                                    {
                                        item.Title = journalForm.ItemTitle;
                                        item.Publisher = journalForm.ItemPublisher;
                                        item.CopyrightYear = parsedCR;
                                        item.LoanPeriod = parsedLP;
                                        item.CallNumber = journalForm.ItemCallNumber;
                                        item.Volume = parsedVolume;
                                        item.Number = parsedNumber;
                                        item.Discipline = journalForm.ItemDiscipline;
                                        item.Editor = journalForm.ItemEditor;
                                    }
                                    else
                                    {
                                        MessageBox.Show("Edit aborted, one or more required fields were left blank");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Edit aborted, number was invalid");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Edit aborted, volume was invalid");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Edit aborted, loan period was invalid");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Edit aborted, copyright year was invalid");
                    }
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Validation!", "Validation Error");
                }
            }
            journalForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        //Precondition: The item selected for editing is a LibraryMagazine
        //Postcondition: If data entered is valid, this data replaces the existing data for that item (does not create new item)
        private void EditMagazine(LibraryMagazine item, int itemIndex)
        {
            MagazineForm magazineForm = new MagazineForm(); //The edit magazine dialog box form
            magazineForm.ItemTitle = item.Title;
            magazineForm.ItemPublisher = item.Publisher;
            magazineForm.ItemCopyrightYear = item.CopyrightYear.ToString();
            magazineForm.ItemLoanPeriod = item.LoanPeriod.ToString();
            magazineForm.ItemCallNumber = item.CallNumber;
            magazineForm.ItemVolume = item.Volume.ToString();
            magazineForm.ItemNumber = item.Number.ToString();
            DialogResult result = magazineForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try //Overwrite relevant Item properties with user's edits
                {
                    int parsedCR; //int variable for parsed CR year
                    int parsedLP; //int variable for parsed loan period
                    int parsedVolume; //int variable for parsed volume
                    int parsedNumber; //int variable for parsed number
                    
                    //Precondition: The user entered data for copyright year
                    //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                    // property, otherwise, an error is displayed
                    if (int.TryParse(magazineForm.ItemCopyrightYear, out parsedCR) && !String.IsNullOrWhiteSpace(magazineForm.ItemCopyrightYear))
                    {
                        //Precondition: The user entered data for loan period
                        //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                        // property, otherwise, an error is displayed
                        if (int.TryParse(magazineForm.ItemLoanPeriod, out parsedLP) && !String.IsNullOrWhiteSpace(magazineForm.ItemLoanPeriod))
                        {
                            //Precondition: The user entered data for volume
                            //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                            // property, otherwise, an error is displayed
                            if (int.TryParse(magazineForm.ItemVolume, out parsedVolume) && !String.IsNullOrWhiteSpace(magazineForm.ItemVolume))
                            {
                                //Precondition: The user entered data for number
                                //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                                // property, otherwise, an error is displayed
                                if (int.TryParse(magazineForm.ItemNumber, out parsedNumber) && !String.IsNullOrWhiteSpace(magazineForm.ItemNumber))
                                {
                                    if (!String.IsNullOrWhiteSpace(magazineForm.ItemTitle) &&
                                           !String.IsNullOrWhiteSpace(magazineForm.ItemPublisher) &&
                                           !String.IsNullOrWhiteSpace(magazineForm.ItemCallNumber))
                                    {
                                        item.Title = magazineForm.ItemTitle;
                                        item.Publisher = magazineForm.ItemPublisher;
                                        item.CopyrightYear = parsedCR;
                                        item.LoanPeriod = parsedLP;
                                        item.CallNumber = magazineForm.ItemCallNumber;
                                        item.Volume = parsedVolume;
                                        item.Number = parsedNumber;
                                    }
                                    else
                                    {
                                        MessageBox.Show("Edit aborted, one or more required fields were left blank");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Edit aborted, number was invalid");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Edit aborted, volume was invalid");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Edit aborted, loan period was invalid");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Edit aborted, copyright year was invalid");
                    }
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Validation!", "Validation Error");
                }
            }
            magazineForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        //Precondition: The item selected for editing is a LibraryMovie
        //Postcondition: If data entered is valid, this data replaces the existing data for that item (does not create new item)
        private void EditMovie(LibraryMovie item, int itemIndex)
        {
            MovieForm movieForm = new MovieForm(); //The edit movie dialog box form
            movieForm.ItemTitle = item.Title;
            movieForm.ItemPublisher = item.Publisher;
            movieForm.ItemCopyrightYear = item.CopyrightYear.ToString();
            movieForm.ItemLoanPeriod = item.LoanPeriod.ToString();
            movieForm.ItemCallNumber = item.CallNumber;
            movieForm.ItemDuration = item.Duration.ToString();
            movieForm.ItemDirector = item.Director;
            movieForm.ItemMedium = item.Medium.ToString();
            movieForm.ItemRating = item.Rating.ToString();
            DialogResult result = movieForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try //Overwrite relevant Item properties with user's edits
                {
                    int parsedCR; //int variable for parsed CR year
                    int parsedLP; //int variable for parsed loan period
                    double parsedDuration; //double variable for parsed duration
                    LibraryMediaItem.MediaType parsedMediaType; //MediaType enum variable for parsed medium
                    LibraryMovie.MPAARatings parsedRating; //MPAARatings enum variable for parsed rating
                    
                    //Precondition: The user entered data for copyright year
                    //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                    // property, otherwise, an error is displayed
                    if (int.TryParse(movieForm.ItemCopyrightYear, out parsedCR) && !String.IsNullOrWhiteSpace(movieForm.ItemCopyrightYear))
                    {
                        //Precondition: The user entered data for loan period
                        //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                        // property, otherwise, an error is displayed
                        if (int.TryParse(movieForm.ItemLoanPeriod, out parsedLP) && !String.IsNullOrWhiteSpace(movieForm.ItemLoanPeriod))
                        {
                            //Precondition: The user entered data for duration
                            //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                            // property, otherwise, an error is displayed
                            if (double.TryParse(movieForm.ItemDuration, out parsedDuration) && !String.IsNullOrWhiteSpace(movieForm.ItemDuration))
                            {
                                //Precondition: The user entered data for medium
                                //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                                // property, otherwise, an error is displayed
                                if (LibraryMediaItem.MediaType.TryParse(movieForm.ItemMedium, out parsedMediaType) && !String.IsNullOrWhiteSpace(movieForm.ItemMedium))
                                {
                                    //Precondition: The user entered data for ratings
                                    //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                                    // property, otherwise, an error is displayed
                                    if (LibraryMovie.MPAARatings.TryParse(movieForm.ItemRating, out parsedRating) && !String.IsNullOrWhiteSpace(movieForm.ItemRating))
                                    {
                                        if (!String.IsNullOrWhiteSpace(movieForm.ItemTitle) &&
                                           !String.IsNullOrWhiteSpace(movieForm.ItemPublisher) &&
                                           !String.IsNullOrWhiteSpace(movieForm.ItemCallNumber) &&
                                           !String.IsNullOrWhiteSpace(movieForm.ItemDirector))
                                        {
                                            item.Title = movieForm.ItemTitle;
                                            item.Publisher = movieForm.ItemPublisher;
                                            item.CopyrightYear = parsedCR;
                                            item.LoanPeriod = parsedLP;
                                            item.CallNumber = movieForm.ItemCallNumber;
                                            item.Duration = parsedDuration;
                                            item.Director = movieForm.ItemDirector;
                                            item.Medium = parsedMediaType;
                                            item.Rating = parsedRating;
                                        }
                                        else
                                        {
                                            MessageBox.Show("Edit aborted, one or more required fields were left blank");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Edit aborted, rating was invalid");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Edit aborted, medium was invalid");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Edit aborted, duration was invalid");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Edit aborted, loan period was invalid");
                        }
                    } 
                    else
                    {
                        MessageBox.Show("Edit aborted, copyright year was invalid");
                    }
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Validation!", "Validation Error");
                }
            }
            movieForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }

        //Precondition: The item selected for editing is a LibraryMusic
        //Postcondition: If data entered is valid, this data replaces the existing data for that item (does not create new item)
        private void EditMusic(LibraryMusic item, int itemIndex)
        {
            MusicForm musicForm = new MusicForm(); //The edit music dialog box form
            musicForm.ItemTitle = item.Title;
            musicForm.ItemPublisher = item.Publisher;
            musicForm.ItemCopyrightYear = item.CopyrightYear.ToString();
            musicForm.ItemLoanPeriod = item.LoanPeriod.ToString();
            musicForm.ItemCallNumber = item.CallNumber;
            musicForm.ItemDuration = item.Duration.ToString();
            musicForm.ItemArtist = item.Artist;
            musicForm.ItemMedium = item.Medium.ToString();
            musicForm.ItemNumTracks = item.NumTracks.ToString();
            DialogResult result = musicForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK) // Only add if OK
            {
                try //Overwrite relevant Item properties with user's edits
                {
                    int parsedCR; //int variable for parsed CR year
                    int parsedLP; //int variable for parsed loan period
                    double parsedDuration; //double variable for parsed duration
                    LibraryMediaItem.MediaType parsedMediaType; //MediaType enum variable for parsed medium
                    int parsedNumTracks; //int variable for parsed num tracks

                    //Precondition: The user entered data for copyright year
                    //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                    // property, otherwise, an error is displayed
                    if (int.TryParse(musicForm.ItemCopyrightYear, out parsedCR) && !String.IsNullOrWhiteSpace(musicForm.ItemCopyrightYear))
                    {
                        //Precondition: The user entered data for loan period
                        //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                        // property, otherwise, an error is displayed
                        if (int.TryParse(musicForm.ItemLoanPeriod, out parsedLP) && !String.IsNullOrWhiteSpace(musicForm.ItemLoanPeriod))
                        {
                            //Precondition: The user entered data for duration
                            //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                            // property, otherwise, an error is displayed
                            if (double.TryParse(musicForm.ItemDuration, out parsedDuration) && !String.IsNullOrWhiteSpace(musicForm.ItemDuration))
                            {
                                //Precondition: The user entered data for medium
                                //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                                // property, otherwise, an error is displayed
                                if (LibraryMediaItem.MediaType.TryParse(musicForm.ItemMedium, out parsedMediaType) && !String.IsNullOrWhiteSpace(musicForm.ItemMedium))
                                {
                                    //Precondition: The user entered data for num tracks
                                    //Postcondition: If data entered is valid, the parsed value is assigned to the item's associated
                                    // property, otherwise, an error is displayed
                                    if (int.TryParse(musicForm.ItemNumTracks, out parsedNumTracks) && !String.IsNullOrWhiteSpace(musicForm.ItemNumTracks))
                                    {
                                        if(!String.IsNullOrWhiteSpace(musicForm.ItemTitle) && 
                                           !String.IsNullOrWhiteSpace(musicForm.ItemPublisher) &&
                                           !String.IsNullOrWhiteSpace(musicForm.ItemCallNumber) &&
                                           !String.IsNullOrWhiteSpace(musicForm.ItemArtist))
                                        {
                                            item.Title = musicForm.ItemTitle;
                                            item.Publisher = musicForm.ItemPublisher;
                                            item.CopyrightYear = parsedCR;
                                            item.LoanPeriod = parsedLP;
                                            item.CallNumber = musicForm.ItemCallNumber;
                                            item.Duration = parsedDuration;
                                            item.Artist = musicForm.ItemArtist;
                                            item.Medium = parsedMediaType;
                                            item.NumTracks = parsedNumTracks;
                                        }
                                        else
                                        {
                                            MessageBox.Show("Edit aborted, one or more required fields were left blank");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Edit aborted, num tracks was invalid");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Edit aborted, medium was invalid");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Edit aborted, duration was invalid");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Edit aborted, loan period was invalid");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Edit aborted, copyright year was invalid");
                    }
                }
                catch (FormatException) // This should never happen if form validation works!
                {
                    MessageBox.Show("Problem with Validation!", "Validation Error");
                }
            }
            musicForm.Dispose(); // Good .NET practice - will get garbage collected anyway
        }
    }
}
