﻿namespace LibraryItems
{
    partial class MusicForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.durationLbl = new System.Windows.Forms.Label();
            this.artistLbl = new System.Windows.Forms.Label();
            this.mediumLbl = new System.Windows.Forms.Label();
            this.numTracksLbl = new System.Windows.Forms.Label();
            this.durationTxtBox = new System.Windows.Forms.TextBox();
            this.artistTxtBox = new System.Windows.Forms.TextBox();
            this.mediumTxtBox = new System.Windows.Forms.TextBox();
            this.numTracksTxtBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(123, 267);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(41, 267);
            // 
            // durationLbl
            // 
            this.durationLbl.AutoSize = true;
            this.durationLbl.Location = new System.Drawing.Point(19, 141);
            this.durationLbl.Name = "durationLbl";
            this.durationLbl.Size = new System.Drawing.Size(50, 13);
            this.durationLbl.TabIndex = 17;
            this.durationLbl.Text = "Duration:";
            // 
            // artistLbl
            // 
            this.artistLbl.AutoSize = true;
            this.artistLbl.Location = new System.Drawing.Point(32, 168);
            this.artistLbl.Name = "artistLbl";
            this.artistLbl.Size = new System.Drawing.Size(33, 13);
            this.artistLbl.TabIndex = 18;
            this.artistLbl.Text = "Artist:";
            // 
            // mediumLbl
            // 
            this.mediumLbl.AutoSize = true;
            this.mediumLbl.Location = new System.Drawing.Point(22, 194);
            this.mediumLbl.Name = "mediumLbl";
            this.mediumLbl.Size = new System.Drawing.Size(47, 13);
            this.mediumLbl.TabIndex = 19;
            this.mediumLbl.Text = "Medium:";
            // 
            // numTracksLbl
            // 
            this.numTracksLbl.AutoSize = true;
            this.numTracksLbl.Location = new System.Drawing.Point(5, 219);
            this.numTracksLbl.Name = "numTracksLbl";
            this.numTracksLbl.Size = new System.Drawing.Size(68, 13);
            this.numTracksLbl.TabIndex = 20;
            this.numTracksLbl.Text = "Num Tracks:";
            // 
            // durationTxtBox
            // 
            this.durationTxtBox.Location = new System.Drawing.Point(78, 139);
            this.durationTxtBox.Name = "durationTxtBox";
            this.durationTxtBox.Size = new System.Drawing.Size(100, 20);
            this.durationTxtBox.TabIndex = 21;
            // 
            // artistTxtBox
            // 
            this.artistTxtBox.Location = new System.Drawing.Point(77, 165);
            this.artistTxtBox.Name = "artistTxtBox";
            this.artistTxtBox.Size = new System.Drawing.Size(100, 20);
            this.artistTxtBox.TabIndex = 22;
            // 
            // mediumTxtBox
            // 
            this.mediumTxtBox.Location = new System.Drawing.Point(77, 191);
            this.mediumTxtBox.Name = "mediumTxtBox";
            this.mediumTxtBox.Size = new System.Drawing.Size(100, 20);
            this.mediumTxtBox.TabIndex = 23;
            // 
            // numTracksTxtBox
            // 
            this.numTracksTxtBox.Location = new System.Drawing.Point(77, 217);
            this.numTracksTxtBox.Name = "numTracksTxtBox";
            this.numTracksTxtBox.Size = new System.Drawing.Size(100, 20);
            this.numTracksTxtBox.TabIndex = 24;
            // 
            // MusicForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(238, 310);
            this.Controls.Add(this.numTracksTxtBox);
            this.Controls.Add(this.mediumTxtBox);
            this.Controls.Add(this.artistTxtBox);
            this.Controls.Add(this.durationTxtBox);
            this.Controls.Add(this.numTracksLbl);
            this.Controls.Add(this.mediumLbl);
            this.Controls.Add(this.artistLbl);
            this.Controls.Add(this.durationLbl);
            this.Name = "MusicForm";
            this.Text = "Edit Music";
            this.Controls.SetChildIndex(this.itemTitleLbl, 0);
            this.Controls.SetChildIndex(this.itemTitleTxt, 0);
            this.Controls.SetChildIndex(this.itemPublisherLbl, 0);
            this.Controls.SetChildIndex(this.itemPublisherTxt, 0);
            this.Controls.SetChildIndex(this.itemCopyrightLbl, 0);
            this.Controls.SetChildIndex(this.itemCopyrightTxt, 0);
            this.Controls.SetChildIndex(this.itemLoanPeriodLbl, 0);
            this.Controls.SetChildIndex(this.itemLoanPeriodTxt, 0);
            this.Controls.SetChildIndex(this.itemCallNumberLbl, 0);
            this.Controls.SetChildIndex(this.itemCallNumberTxt, 0);
            this.Controls.SetChildIndex(this.okBtn, 0);
            this.Controls.SetChildIndex(this.cancelBtn, 0);
            this.Controls.SetChildIndex(this.durationLbl, 0);
            this.Controls.SetChildIndex(this.artistLbl, 0);
            this.Controls.SetChildIndex(this.mediumLbl, 0);
            this.Controls.SetChildIndex(this.numTracksLbl, 0);
            this.Controls.SetChildIndex(this.durationTxtBox, 0);
            this.Controls.SetChildIndex(this.artistTxtBox, 0);
            this.Controls.SetChildIndex(this.mediumTxtBox, 0);
            this.Controls.SetChildIndex(this.numTracksTxtBox, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label durationLbl;
        private System.Windows.Forms.Label artistLbl;
        private System.Windows.Forms.Label mediumLbl;
        private System.Windows.Forms.Label numTracksLbl;
        private System.Windows.Forms.TextBox durationTxtBox;
        private System.Windows.Forms.TextBox artistTxtBox;
        private System.Windows.Forms.TextBox mediumTxtBox;
        private System.Windows.Forms.TextBox numTracksTxtBox;
    }
}