﻿// Program 3
// Grading ID: D4929
// Due Date: 4/3/17
// Course Section: CIS 200-01

// File: MovieForm.cs
// This class creates the Movie dialog box form GUI. It performs validation
// and provides String properties for each field.
// MovieForm IS-A ItemFormBase

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class MovieForm : ItemFormBase
    {
        public MovieForm()
        {
            InitializeComponent();
        }
        internal String ItemDuration
        {
            // Precondition:  None
            // Postcondition: The text of form's duration field has been returned
            get
            {
                return durationTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's duration field has been set to the specified value
            set
            {
                durationTxtBox.Text = value;
            }
        }

        internal String ItemDirector
        {
            // Precondition:  None
            // Postcondition: The text of form's director field has been returned
            get
            {
                return directorTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's director field has been set to the specified value
            set
            {
                directorTxtBox.Text = value;
            }
        }

        internal String ItemMedium
        {
            // Precondition:  None
            // Postcondition: The text of form's medium field has been returned
            get
            {
                return mediumTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's medium field has been set to the specified value
            set
            {
                mediumTxtBox.Text = value;
            }
        }

        internal String ItemRating
        {
            // Precondition:  None
            // Postcondition: The text of form's rating field has been returned
            get
            {
                return ratingTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's rating field has been set to the specified value
            set
            {
                ratingTxtBox.Text = value;
            }
        }
    }
}
