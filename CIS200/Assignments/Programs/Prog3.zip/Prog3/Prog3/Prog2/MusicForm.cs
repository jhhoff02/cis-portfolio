﻿// Program 3
// Grading ID: D4929
// Due Date: 4/3/17
// Course Section: CIS 200-01

// File: MusicForm.cs
// This class creates the Music dialog box form GUI. It performs validation
// and provides String properties for each field.
// MusicForm IS-A ItemFormBase

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class MusicForm : ItemFormBase
    {
        public MusicForm()
        {
            InitializeComponent();
        }

        internal String ItemDuration
        {
            // Precondition:  None
            // Postcondition: The text of form's duration field has been returned
            get
            {
                return durationTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's duration field has been set to the specified value
            set
            {
                durationTxtBox.Text = value;
            }
        }

        internal String ItemArtist
        {
            // Precondition:  None
            // Postcondition: The text of form's artist field has been returned
            get
            {
                return artistTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's artist field has been set to the specified value
            set
            {
                artistTxtBox.Text = value;
            }
        }

        internal String ItemMedium
        {
            // Precondition:  None
            // Postcondition: The text of form's medium field has been returned
            get
            {
                return mediumTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's medium field has been set to the specified value
            set
            {
                mediumTxtBox.Text = value;
            }
        }

        internal String ItemNumTracks
        {
            // Precondition:  None
            // Postcondition: The text of form's num tracks field has been returned
            get
            {
                return numTracksTxtBox.Text;
            }

            // Precondition:  None
            // Postcondition: The text of form's num tracks field has been set to the specified value
            set
            {
                numTracksTxtBox.Text = value;
            }
        }
    }
}
