﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class EditBookForm : Form
    {
        private List<LibraryItem> _items; // List of library items

        // Precondition:  Edit, Book is chosen from menu
        // Postcondition: The form's GUI is prepared for display. _items is populated with the 
        // available LibraryItems to choose from
        public EditBookForm(List<LibraryItem> itemList)
        {
            InitializeComponent();
            _items = itemList;
        }

        internal int ItemIndex
        {
            // Precondition:  None
            // Postcondition: The index of form's selected item combo box has been returned
            get
            {
                return itemCbo.SelectedIndex;
            }
        }

        // Precondition:  None
        // Postcondition: The list of items is used to populate the
        //                item combo box
        private void EditBookForm_Load(object sender, EventArgs e)
        {
            foreach (LibraryItem item in _items)
                itemCbo.Items.Add(item.Title + ", " + item.CallNumber);
        }

        // Precondition:  User pressed on okBtn
        // Postcondition: Form closes and sends OK result
        private void okBtn_Click(object sender, EventArgs e)
        {
            if (itemCbo.SelectedIndex > -1)
            {
                this.DialogResult = DialogResult.OK; // Causes form to close and return OK result
                this.Close(); //Close form because book form is going to open.
            }
            else
            {
                if(_items.Count < 1) //Prompt to insert items if there are none
                    MessageBox.Show("There are no items to choose from, open a Library file or insert an item");
                else //Prompt to select item
                    MessageBox.Show("Please select an item to continue");
            }
        }

        // Precondition:  User pressed on cancelBtn
        // Postcondition: Form closes and sends Cancel result
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; //Close form
        }
    }
}
