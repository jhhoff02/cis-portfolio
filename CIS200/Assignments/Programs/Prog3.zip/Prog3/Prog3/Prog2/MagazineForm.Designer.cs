﻿namespace LibraryItems
{
    partial class MagazineForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numTxtBox = new System.Windows.Forms.TextBox();
            this.volumeTxtBox = new System.Windows.Forms.TextBox();
            this.numLbl = new System.Windows.Forms.Label();
            this.volLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(122, 201);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(40, 201);
            // 
            // numTxtBox
            // 
            this.numTxtBox.Location = new System.Drawing.Point(78, 164);
            this.numTxtBox.Name = "numTxtBox";
            this.numTxtBox.Size = new System.Drawing.Size(100, 20);
            this.numTxtBox.TabIndex = 26;
            // 
            // volumeTxtBox
            // 
            this.volumeTxtBox.Location = new System.Drawing.Point(78, 138);
            this.volumeTxtBox.Name = "volumeTxtBox";
            this.volumeTxtBox.Size = new System.Drawing.Size(100, 20);
            this.volumeTxtBox.TabIndex = 25;
            // 
            // numLbl
            // 
            this.numLbl.AutoSize = true;
            this.numLbl.Location = new System.Drawing.Point(27, 167);
            this.numLbl.Name = "numLbl";
            this.numLbl.Size = new System.Drawing.Size(47, 13);
            this.numLbl.TabIndex = 24;
            this.numLbl.Text = "Number:";
            // 
            // volLbl
            // 
            this.volLbl.AutoSize = true;
            this.volLbl.Location = new System.Drawing.Point(27, 141);
            this.volLbl.Name = "volLbl";
            this.volLbl.Size = new System.Drawing.Size(45, 13);
            this.volLbl.TabIndex = 23;
            this.volLbl.Text = "Volume:";
            // 
            // MagazineForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(236, 262);
            this.Controls.Add(this.numTxtBox);
            this.Controls.Add(this.volumeTxtBox);
            this.Controls.Add(this.numLbl);
            this.Controls.Add(this.volLbl);
            this.Name = "MagazineForm";
            this.Text = "Edit Magazine";
            this.Controls.SetChildIndex(this.itemTitleLbl, 0);
            this.Controls.SetChildIndex(this.itemTitleTxt, 0);
            this.Controls.SetChildIndex(this.itemPublisherLbl, 0);
            this.Controls.SetChildIndex(this.itemPublisherTxt, 0);
            this.Controls.SetChildIndex(this.itemCopyrightLbl, 0);
            this.Controls.SetChildIndex(this.itemCopyrightTxt, 0);
            this.Controls.SetChildIndex(this.itemLoanPeriodLbl, 0);
            this.Controls.SetChildIndex(this.itemLoanPeriodTxt, 0);
            this.Controls.SetChildIndex(this.itemCallNumberLbl, 0);
            this.Controls.SetChildIndex(this.itemCallNumberTxt, 0);
            this.Controls.SetChildIndex(this.okBtn, 0);
            this.Controls.SetChildIndex(this.cancelBtn, 0);
            this.Controls.SetChildIndex(this.volLbl, 0);
            this.Controls.SetChildIndex(this.numLbl, 0);
            this.Controls.SetChildIndex(this.volumeTxtBox, 0);
            this.Controls.SetChildIndex(this.numTxtBox, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox numTxtBox;
        private System.Windows.Forms.TextBox volumeTxtBox;
        private System.Windows.Forms.Label numLbl;
        private System.Windows.Forms.Label volLbl;
    }
}