﻿namespace LibraryItems
{
    partial class SaveLibraryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fileNameLbl = new System.Windows.Forms.Label();
            this.fileNameTxt = new System.Windows.Forms.TextBox();
            this.fileExtLbl = new System.Windows.Forms.Label();
            this.instructionLbl = new System.Windows.Forms.Label();
            this.saveLibraryBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // fileNameLbl
            // 
            this.fileNameLbl.AutoSize = true;
            this.fileNameLbl.Location = new System.Drawing.Point(12, 20);
            this.fileNameLbl.Name = "fileNameLbl";
            this.fileNameLbl.Size = new System.Drawing.Size(57, 13);
            this.fileNameLbl.TabIndex = 0;
            this.fileNameLbl.Text = "File Name:";
            // 
            // fileNameTxt
            // 
            this.fileNameTxt.Location = new System.Drawing.Point(77, 17);
            this.fileNameTxt.Name = "fileNameTxt";
            this.fileNameTxt.Size = new System.Drawing.Size(142, 20);
            this.fileNameTxt.TabIndex = 1;
            // 
            // fileExtLbl
            // 
            this.fileExtLbl.AutoSize = true;
            this.fileExtLbl.Location = new System.Drawing.Point(225, 20);
            this.fileExtLbl.Name = "fileExtLbl";
            this.fileExtLbl.Size = new System.Drawing.Size(25, 13);
            this.fileExtLbl.TabIndex = 2;
            this.fileExtLbl.Text = ".dat";
            // 
            // instructionLbl
            // 
            this.instructionLbl.AutoSize = true;
            this.instructionLbl.Location = new System.Drawing.Point(12, 40);
            this.instructionLbl.Name = "instructionLbl";
            this.instructionLbl.Size = new System.Drawing.Size(350, 13);
            this.instructionLbl.TabIndex = 3;
            this.instructionLbl.Text = "Please exclude special characters. The file extension is already included.";
            // 
            // saveLibraryBtn
            // 
            this.saveLibraryBtn.Location = new System.Drawing.Point(256, 14);
            this.saveLibraryBtn.Name = "saveLibraryBtn";
            this.saveLibraryBtn.Size = new System.Drawing.Size(75, 23);
            this.saveLibraryBtn.TabIndex = 4;
            this.saveLibraryBtn.Text = "Save";
            this.saveLibraryBtn.UseVisualStyleBackColor = true;
            this.saveLibraryBtn.Click += new System.EventHandler(this.saveLibraryBtn_Click);
            // 
            // SaveLibraryForm
            // 
            this.AcceptButton = this.saveLibraryBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 62);
            this.Controls.Add(this.saveLibraryBtn);
            this.Controls.Add(this.instructionLbl);
            this.Controls.Add(this.fileExtLbl);
            this.Controls.Add(this.fileNameTxt);
            this.Controls.Add(this.fileNameLbl);
            this.Name = "SaveLibraryForm";
            this.Text = "Save Existing Library";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fileNameLbl;
        private System.Windows.Forms.TextBox fileNameTxt;
        private System.Windows.Forms.Label fileExtLbl;
        private System.Windows.Forms.Label instructionLbl;
        private System.Windows.Forms.Button saveLibraryBtn;
    }
}