﻿namespace LibraryItems
{
    partial class MovieForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.durationLbl = new System.Windows.Forms.Label();
            this.directorLbl = new System.Windows.Forms.Label();
            this.mediumLbl = new System.Windows.Forms.Label();
            this.ratingLbl = new System.Windows.Forms.Label();
            this.durationTxtBox = new System.Windows.Forms.TextBox();
            this.directorTxtBox = new System.Windows.Forms.TextBox();
            this.mediumTxtBox = new System.Windows.Forms.TextBox();
            this.ratingTxtBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // itemPublisherLbl
            // 
            this.itemPublisherLbl.Location = new System.Drawing.Point(19, 38);
            // 
            // itemPublisherTxt
            // 
            this.itemPublisherTxt.Location = new System.Drawing.Point(78, 35);
            // 
            // itemCopyrightLbl
            // 
            this.itemCopyrightLbl.Location = new System.Drawing.Point(18, 65);
            // 
            // itemCopyrightTxt
            // 
            this.itemCopyrightTxt.Location = new System.Drawing.Point(78, 62);
            // 
            // itemLoanPeriodLbl
            // 
            this.itemLoanPeriodLbl.Location = new System.Drawing.Point(5, 92);
            // 
            // itemLoanPeriodTxt
            // 
            this.itemLoanPeriodTxt.Location = new System.Drawing.Point(78, 89);
            // 
            // itemCallNumberLbl
            // 
            this.itemCallNumberLbl.Location = new System.Drawing.Point(5, 119);
            // 
            // itemCallNumberTxt
            // 
            this.itemCallNumberTxt.Location = new System.Drawing.Point(78, 116);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(120, 262);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(38, 262);
            // 
            // durationLbl
            // 
            this.durationLbl.AutoSize = true;
            this.durationLbl.Location = new System.Drawing.Point(22, 146);
            this.durationLbl.Name = "durationLbl";
            this.durationLbl.Size = new System.Drawing.Size(50, 13);
            this.durationLbl.TabIndex = 17;
            this.durationLbl.Text = "Duration:";
            // 
            // directorLbl
            // 
            this.directorLbl.AutoSize = true;
            this.directorLbl.Location = new System.Drawing.Point(22, 173);
            this.directorLbl.Name = "directorLbl";
            this.directorLbl.Size = new System.Drawing.Size(47, 13);
            this.directorLbl.TabIndex = 18;
            this.directorLbl.Text = "Director:";
            // 
            // mediumLbl
            // 
            this.mediumLbl.AutoSize = true;
            this.mediumLbl.Location = new System.Drawing.Point(22, 200);
            this.mediumLbl.Name = "mediumLbl";
            this.mediumLbl.Size = new System.Drawing.Size(47, 13);
            this.mediumLbl.TabIndex = 19;
            this.mediumLbl.Text = "Medium:";
            // 
            // ratingLbl
            // 
            this.ratingLbl.AutoSize = true;
            this.ratingLbl.Location = new System.Drawing.Point(22, 227);
            this.ratingLbl.Name = "ratingLbl";
            this.ratingLbl.Size = new System.Drawing.Size(41, 13);
            this.ratingLbl.TabIndex = 20;
            this.ratingLbl.Text = "Rating:";
            // 
            // durationTxtBox
            // 
            this.durationTxtBox.Location = new System.Drawing.Point(78, 143);
            this.durationTxtBox.Name = "durationTxtBox";
            this.durationTxtBox.Size = new System.Drawing.Size(100, 20);
            this.durationTxtBox.TabIndex = 21;
            // 
            // directorTxtBox
            // 
            this.directorTxtBox.Location = new System.Drawing.Point(78, 170);
            this.directorTxtBox.Name = "directorTxtBox";
            this.directorTxtBox.Size = new System.Drawing.Size(100, 20);
            this.directorTxtBox.TabIndex = 22;
            // 
            // mediumTxtBox
            // 
            this.mediumTxtBox.Location = new System.Drawing.Point(78, 197);
            this.mediumTxtBox.Name = "mediumTxtBox";
            this.mediumTxtBox.Size = new System.Drawing.Size(100, 20);
            this.mediumTxtBox.TabIndex = 23;
            // 
            // ratingTxtBox
            // 
            this.ratingTxtBox.Location = new System.Drawing.Point(78, 223);
            this.ratingTxtBox.Name = "ratingTxtBox";
            this.ratingTxtBox.Size = new System.Drawing.Size(100, 20);
            this.ratingTxtBox.TabIndex = 24;
            // 
            // MovieForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(233, 296);
            this.Controls.Add(this.ratingTxtBox);
            this.Controls.Add(this.mediumTxtBox);
            this.Controls.Add(this.directorTxtBox);
            this.Controls.Add(this.durationTxtBox);
            this.Controls.Add(this.ratingLbl);
            this.Controls.Add(this.mediumLbl);
            this.Controls.Add(this.directorLbl);
            this.Controls.Add(this.durationLbl);
            this.Name = "MovieForm";
            this.Text = "Edit Movie";
            this.Controls.SetChildIndex(this.itemTitleLbl, 0);
            this.Controls.SetChildIndex(this.itemTitleTxt, 0);
            this.Controls.SetChildIndex(this.itemPublisherLbl, 0);
            this.Controls.SetChildIndex(this.itemPublisherTxt, 0);
            this.Controls.SetChildIndex(this.itemCopyrightLbl, 0);
            this.Controls.SetChildIndex(this.itemCopyrightTxt, 0);
            this.Controls.SetChildIndex(this.itemLoanPeriodLbl, 0);
            this.Controls.SetChildIndex(this.itemLoanPeriodTxt, 0);
            this.Controls.SetChildIndex(this.itemCallNumberLbl, 0);
            this.Controls.SetChildIndex(this.itemCallNumberTxt, 0);
            this.Controls.SetChildIndex(this.okBtn, 0);
            this.Controls.SetChildIndex(this.cancelBtn, 0);
            this.Controls.SetChildIndex(this.durationLbl, 0);
            this.Controls.SetChildIndex(this.directorLbl, 0);
            this.Controls.SetChildIndex(this.mediumLbl, 0);
            this.Controls.SetChildIndex(this.ratingLbl, 0);
            this.Controls.SetChildIndex(this.durationTxtBox, 0);
            this.Controls.SetChildIndex(this.directorTxtBox, 0);
            this.Controls.SetChildIndex(this.mediumTxtBox, 0);
            this.Controls.SetChildIndex(this.ratingTxtBox, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label durationLbl;
        private System.Windows.Forms.Label directorLbl;
        private System.Windows.Forms.Label mediumLbl;
        private System.Windows.Forms.Label ratingLbl;
        private System.Windows.Forms.TextBox durationTxtBox;
        private System.Windows.Forms.TextBox directorTxtBox;
        private System.Windows.Forms.TextBox mediumTxtBox;
        private System.Windows.Forms.TextBox ratingTxtBox;
    }
}