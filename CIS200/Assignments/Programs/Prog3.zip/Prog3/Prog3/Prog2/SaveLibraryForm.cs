﻿// Program 3
// Grading ID: D4929
// Due Date: 4/3/17
// Course Section: CIS 200-01

// File: SaveLibraryForm.cs
// This class creates the SaveLibraryForm dialog box form GUI. It takes user input for the
// file name and sends it back to the Prog2Form for further processing (saving of the Library).

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class SaveLibraryForm : Form
    {
        private string _fileName; //private string backing field for storing the user input for the file name
        public SaveLibraryForm() //Initializes SaveLibraryForm
        {
            InitializeComponent();
        }

        internal String FileName
        {
            // Precondition:  None
            // Postcondition: The text of the file name field has been returned
            get
            {
                return _fileName;
            }

            // Precondition:  None
            // Postcondition: The text of the file name field has been set to the specified value
            set
            {
                _fileName = value;
            }
        }

        // Precondition:  File name input is not empty. 
        // Postcondition: If the file name is valid, it returns OK result to main form, 
        // which is where the file saving occurs using FileName
        private void saveLibraryBtn_Click(object sender, EventArgs e)
        {
            instructionLbl.ForeColor = Color.Black;
            instructionLbl.Text = "Please exclude special characters. The file extension is already included.";
            if (!string.IsNullOrWhiteSpace(fileNameTxt.Text) && 
                (fileNameTxt.Text.All(ch => Char.IsLetterOrDigit(ch) || 
                 ch == ' ' || ch == '_'))) // File name is not null or empty, and every char is a letter, number, space, or underscore.
            {
                _fileName = fileNameTxt.Text;
                FileName = _fileName; //Set form's FileName property to valid file name value to be used on the Prog2Form
                this.DialogResult = DialogResult.OK;
            }
            else //Display error
            {
                instructionLbl.ForeColor = Color.Red;
                instructionLbl.Text = "Please enter a valid file name";
            }
        }
    }
}
