﻿namespace LibraryItems
{
    partial class JournalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.volLbl = new System.Windows.Forms.Label();
            this.numLbl = new System.Windows.Forms.Label();
            this.disciplineLbl = new System.Windows.Forms.Label();
            this.editorLbl = new System.Windows.Forms.Label();
            this.volumeTxtBox = new System.Windows.Forms.TextBox();
            this.numTxtBox = new System.Windows.Forms.TextBox();
            this.disciplineTxtBox = new System.Windows.Forms.TextBox();
            this.editorTxtBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(129, 255);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(47, 255);
            // 
            // volLbl
            // 
            this.volLbl.AutoSize = true;
            this.volLbl.Location = new System.Drawing.Point(27, 141);
            this.volLbl.Name = "volLbl";
            this.volLbl.Size = new System.Drawing.Size(45, 13);
            this.volLbl.TabIndex = 17;
            this.volLbl.Text = "Volume:";
            // 
            // numLbl
            // 
            this.numLbl.AutoSize = true;
            this.numLbl.Location = new System.Drawing.Point(27, 167);
            this.numLbl.Name = "numLbl";
            this.numLbl.Size = new System.Drawing.Size(47, 13);
            this.numLbl.TabIndex = 18;
            this.numLbl.Text = "Number:";
            // 
            // disciplineLbl
            // 
            this.disciplineLbl.AutoSize = true;
            this.disciplineLbl.Location = new System.Drawing.Point(19, 193);
            this.disciplineLbl.Name = "disciplineLbl";
            this.disciplineLbl.Size = new System.Drawing.Size(55, 13);
            this.disciplineLbl.TabIndex = 19;
            this.disciplineLbl.Text = "Discipline:";
            // 
            // editorLbl
            // 
            this.editorLbl.AutoSize = true;
            this.editorLbl.Location = new System.Drawing.Point(37, 219);
            this.editorLbl.Name = "editorLbl";
            this.editorLbl.Size = new System.Drawing.Size(37, 13);
            this.editorLbl.TabIndex = 20;
            this.editorLbl.Text = "Editor:";
            // 
            // volumeTxtBox
            // 
            this.volumeTxtBox.Location = new System.Drawing.Point(78, 138);
            this.volumeTxtBox.Name = "volumeTxtBox";
            this.volumeTxtBox.Size = new System.Drawing.Size(100, 20);
            this.volumeTxtBox.TabIndex = 21;
            // 
            // numTxtBox
            // 
            this.numTxtBox.Location = new System.Drawing.Point(78, 164);
            this.numTxtBox.Name = "numTxtBox";
            this.numTxtBox.Size = new System.Drawing.Size(100, 20);
            this.numTxtBox.TabIndex = 22;
            // 
            // disciplineTxtBox
            // 
            this.disciplineTxtBox.Location = new System.Drawing.Point(77, 190);
            this.disciplineTxtBox.Name = "disciplineTxtBox";
            this.disciplineTxtBox.Size = new System.Drawing.Size(100, 20);
            this.disciplineTxtBox.TabIndex = 23;
            // 
            // editorTxtBox
            // 
            this.editorTxtBox.Location = new System.Drawing.Point(78, 216);
            this.editorTxtBox.Name = "editorTxtBox";
            this.editorTxtBox.Size = new System.Drawing.Size(100, 20);
            this.editorTxtBox.TabIndex = 24;
            // 
            // JournalForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(250, 293);
            this.Controls.Add(this.editorTxtBox);
            this.Controls.Add(this.disciplineTxtBox);
            this.Controls.Add(this.numTxtBox);
            this.Controls.Add(this.volumeTxtBox);
            this.Controls.Add(this.editorLbl);
            this.Controls.Add(this.disciplineLbl);
            this.Controls.Add(this.numLbl);
            this.Controls.Add(this.volLbl);
            this.Name = "JournalForm";
            this.Text = "Edit Journal";
            this.Controls.SetChildIndex(this.itemTitleLbl, 0);
            this.Controls.SetChildIndex(this.itemTitleTxt, 0);
            this.Controls.SetChildIndex(this.itemPublisherLbl, 0);
            this.Controls.SetChildIndex(this.itemPublisherTxt, 0);
            this.Controls.SetChildIndex(this.itemCopyrightLbl, 0);
            this.Controls.SetChildIndex(this.itemCopyrightTxt, 0);
            this.Controls.SetChildIndex(this.itemLoanPeriodLbl, 0);
            this.Controls.SetChildIndex(this.itemLoanPeriodTxt, 0);
            this.Controls.SetChildIndex(this.itemCallNumberLbl, 0);
            this.Controls.SetChildIndex(this.itemCallNumberTxt, 0);
            this.Controls.SetChildIndex(this.okBtn, 0);
            this.Controls.SetChildIndex(this.cancelBtn, 0);
            this.Controls.SetChildIndex(this.volLbl, 0);
            this.Controls.SetChildIndex(this.numLbl, 0);
            this.Controls.SetChildIndex(this.disciplineLbl, 0);
            this.Controls.SetChildIndex(this.editorLbl, 0);
            this.Controls.SetChildIndex(this.volumeTxtBox, 0);
            this.Controls.SetChildIndex(this.numTxtBox, 0);
            this.Controls.SetChildIndex(this.disciplineTxtBox, 0);
            this.Controls.SetChildIndex(this.editorTxtBox, 0);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label volLbl;
        private System.Windows.Forms.Label numLbl;
        private System.Windows.Forms.Label disciplineLbl;
        private System.Windows.Forms.Label editorLbl;
        private System.Windows.Forms.TextBox volumeTxtBox;
        private System.Windows.Forms.TextBox numTxtBox;
        private System.Windows.Forms.TextBox disciplineTxtBox;
        private System.Windows.Forms.TextBox editorTxtBox;
    }
}