﻿// Program 1B
// CIS 200-01
// Grading ID: D4929
// Due: 2/22/2017

// File: LibraryMediaItem.cs
// This class serves as a derived class of LibraryItem, and a base class for LibraryMovie and LibraryMusic. 
//It extends LibraryItem and adds a Duration property as well as a MediaType enum.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public abstract class LibraryMediaItem : LibraryItem
    {
    private string _title;      // The item's title
    private string _publisher;  // The item's publisher
    private int _copyrightYear; // The item's year of copyright
    private int _loanPeriod; // The item's loan period
    private string _callNumber; // The item's call number in the library
    private double _duration; // The item's duration

    // Precondition:  theCopyrightYear >= 0, loanPeriod > 0, duration > 0
    // Postcondition: The library item has been initialized with the specified
    //                values for title, publisher, copyright year, loan period, call number, and duration. The item is not checked out.
    public LibraryMediaItem(string theTitle, string thePublisher,
        int theCopyrightYear, int loanPeriod, string theCallNumber, double duration)
        :base(theTitle, thePublisher, theCopyrightYear, loanPeriod, theCallNumber)
    {
        Title = theTitle;
        Publisher = thePublisher;
        CopyrightYear = theCopyrightYear;
        LoanPeriod = loanPeriod;
        CallNumber = theCallNumber;
        Duration = duration;

        ReturnToShelf(); // Make sure item is not checked out
    }

    public enum MediaType { DVD, BLURAY, VHS, CD, SACD, VINYL };

    public double Duration
    {
        // Precondition:  None
        // Postcondition: The duration has been returned
        get
        {
            return _duration;
        }

        // Precondition:  value > 0
        // Postcondition: The duration has been set to the specified value
        set
        {
            if (value > 0)
                _duration = value;
            else
                throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
                    $"{nameof(Duration)} must be > 0");
        }
    }

    // Precondition:  None
    // Postcondition: The enum MediaType has been set/changed
    public abstract MediaType Medium { get; set; }

    // Precondition:  None
    // Postcondition: A string is returned presenting the library book's data on
    //                separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut
        string checkedOutBy; // Holds checked out message

        if (IsCheckedOut())
            checkedOutBy = $"Checked Out By: {NL}{Patron}";
        else
            checkedOutBy = "Not Checked Out";

        return $"Title: {Title}{NL}Publisher: {Publisher}{NL}" +
            $"Copyright: {CopyrightYear:D4}{NL}LoanPeriod: {LoanPeriod}{NL}Duration: {Duration}{NL}{checkedOutBy}";
    }
}
