﻿// Program 1B
// CIS 200-01
// Grading ID: D4929
// Due: 2/22/2017

// File: LibraryBook.cs
// This file creates a simple LibraryBook class capable of tracking
// the book's title, author, publisher, copyright year, call number,
// and checked out status.

// Started with Version 3 of Prog 0
// Added validation in set accessors of properties, trims strings
// Used string.IsNullOrWhitespace to test

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class LibraryBook : LibraryItem
{
    public const int DEFAULT_YEAR = 2016; // Default copyright year
    public const decimal LATE_FEE = 0.25m; //Const decimal storing the late fee per day for calculations

    private string _author;     // The book's author
    private bool _checkedOut;   // The book's checked out status

    // Precondition:  theCopyrightYear >= 0, loanPeriod > 0
    // Postcondition: The library book has been initialized with the specified
    //                values for title, author, publisher, copyright year, and
    //                call number. The book is not checked out.
    public LibraryBook(string theTitle, string theAuthor, string thePublisher,
        int theCopyrightYear, int loanPeriod, string theCallNumber) 
        :base(theTitle, thePublisher, theCopyrightYear, loanPeriod, theCallNumber)
    {
        Title = theTitle;
        Author = theAuthor;
        Publisher = thePublisher;
        CopyrightYear = theCopyrightYear;
        CallNumber = theCallNumber;

        ReturnToShelf(); // Make sure book is not checked out
    }

    public string Author
    {
        // Precondition:  None
        // Postcondition: The author has been returned
        get
        {
            return _author;
        }

        // Precondition:  None
        // Postcondition: The author has been set to the specified value
        set
        {
            // Since empty author is OK, just change null to empty string
            _author = (value == null ? string.Empty : value.Trim());
        }
    }

    // Precondition:  daysLate should be positive, but validation is performed
    // Postcondition: If daysLate is valid, a decimal late fee is returned. If not, an exception is thrown with error message
    public override decimal CalcLateFee(int daysLate)
    {
        if(daysLate > 0)
        {
            decimal calcedFee = daysLate * LATE_FEE; //temporary decimal variable to store calculated late fee
            return calcedFee;
        }
        else
        {
            throw new ArgumentOutOfRangeException($"{nameof(daysLate)}", daysLate,
                    $"{nameof(daysLate)} must be positive");
        }
    }

    // Precondition:  None
    // Postcondition: A string is returned presenting the library book's data on
    //                separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut
        string checkedOutBy; // Holds checked out message

        if (IsCheckedOut())
            checkedOutBy = $"Checked Out By: {NL}{Patron}";
        else
            checkedOutBy = "Not Checked Out";

        return $"Title: {Title}{NL}Author: {Author}{NL}Publisher: {Publisher}{NL}" +
            $"Copyright: {CopyrightYear:D4}{NL}LoanPeriod: {LoanPeriod}{NL}{checkedOutBy}";
    }
}
