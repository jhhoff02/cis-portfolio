﻿// Program 1B
// CIS 200-01
// Grading ID: D4929
// Due: 2/22/2017

// File: LibraryMusic.cs
// This is a derived class of LibraryMediaItem.
//It adds properties for Artist, Medium, and NumTracks and completes 
//the CalcLateFee() method.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

    public class LibraryMusic : LibraryMediaItem
    {
    public const decimal LATE_FEE = 0.50m; //Const decimal storing the late fee per day 
    public const decimal FEE_LIMIT = 20.00m; //Const decimal storing the fee limit for media items
    private string _artist; // The item's artist
    private MediaType _medium; //The item's MediaType
    private int _trackCount; //The item's number of tracks

    // Precondition:  theCopyrightYear >= 0, loanPeriod > 0, trackCount > 0
    // Postcondition: The library item has been initialized with the specified
    //                values for title, publisher, copyright year, loan period,
    //                call number, duration, artist, medium, and number of tracks. The item is not checked out.
    public LibraryMusic(string theTitle, string thePublisher,
        int theCopyrightYear, int loanPeriod, string theCallNumber, double duration, string artist, MediaType medium, int trackCount)
        :base(theTitle, thePublisher, theCopyrightYear, loanPeriod, theCallNumber, duration)
    {
        Title = theTitle;
        Publisher = thePublisher;
        CopyrightYear = theCopyrightYear;
        LoanPeriod = loanPeriod;
        CallNumber = theCallNumber;
        Duration = duration;
        Artist = artist;
        Medium = medium;
        NumTracks = trackCount;

        ReturnToShelf(); // Make sure item is not checked out
    }

    public string Artist
    {
        // Precondition:  None
        // Postcondition: The artist has been returned
        get
        {
            return _artist;
        }

        // Precondition:  None
        // Postcondition: The artist has been set to the specified value
        set
        {
            // Since empty artist is OK, just change null to empty string
            _artist = (value == null ? string.Empty : value.Trim());
        }
    }

    public override MediaType Medium
    {
        // Precondition:  None
        // Postcondition: The medium has been returned
        get
        {
            return _medium;
        }

        // Precondition:  value should exist in MediaType enums
        // Postcondition: The medium has been set to the specified value
        set
        {
            if (Enum.IsDefined(typeof(MediaType), value)) // Checks to see if Medium exists in MediaType enum
                _medium = value;
            else
                throw new ArgumentException($"{nameof(Medium)} is not a valid Media Type");
        }
    }

    public int NumTracks
    {
        // Precondition:  None
        // Postcondition: The number of tracks has been returned
        get
        {
            return _trackCount;
        }

        // Precondition:  value > 0
        // Postcondition: The number of tracks has been set to the specified value
        set
        {
            if (value > 0)
                _trackCount = value;
            else
                throw new ArgumentOutOfRangeException($"{nameof(NumTracks)}", value,
                    $"{nameof(NumTracks)} must be > 0");
        }
    }

    // Precondition:  daysLate should be positive, but validation is performed
    // Postcondition: If daysLate is valid, a decimal late fee is returned. If not, an exception is thrown with error message
    public override decimal CalcLateFee(int daysLate)
    {
        if (daysLate > 0)
        {
            decimal calcedFee = daysLate * LATE_FEE; //temporary decimal variable to store calculated late fee
            return (calcedFee >= FEE_LIMIT) ? FEE_LIMIT : calcedFee; //Conditional return, return calced fee if it is less than limit, otherwise return limit
        }
        else
        {
            throw new ArgumentOutOfRangeException($"{nameof(daysLate)}", daysLate,
                    $"{nameof(daysLate)} must be positive");
        }
    }

    // Precondition:  None
    // Postcondition: A string is returned presenting the library music's data on
    //                separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut
        string checkedOutBy; // Holds checked out message

        if (IsCheckedOut())
            checkedOutBy = $"Checked Out By: {NL}{Patron}";
        else
            checkedOutBy = "Not Checked Out";

        return $"Title: {Title}{NL}Publisher: {Publisher}{NL}" +
            $"Copyright: {CopyrightYear:D4}{NL}LoanPeriod: {LoanPeriod}{NL}Duration: {Duration}{NL}" +
            $"Artist: {Artist:D4}{NL}Medium: {Medium}{NL}Number of Tracks: {NumTracks}{NL}{checkedOutBy}";
    }
}
