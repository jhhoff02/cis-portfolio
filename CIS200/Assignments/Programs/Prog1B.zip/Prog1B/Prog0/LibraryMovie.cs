﻿// Program 1B
// CIS 200-01
// Grading ID: D4929
// Due: 2/22/2017

// File: LibraryMovie.cs
// This is a derived class of LibraryMediaItem.
//It adds properties for Director, Medium, and Rating as well as an enum 
//for movie ratings. It also includes a complete CalcLateFee() method.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

    public class LibraryMovie : LibraryMediaItem
    {
    public const decimal DVD_VHS_FEE = 1.00m; //Const decimal storing the late fee per day for dvd and vhs
    public const decimal BLURAY_FEE = 1.50m; //Const decimal storing the late fee per day for bluray
    public const decimal FEE_LIMIT = 25.00m; //Const decimal storing the fee limit for media items
    private string _director; // The item's director
    private MediaType _medium; //The item's MediaType
    private MPAARatings _rating; //The item's MPAA Rating

    // Precondition:  theCopyrightYear >= 0, loanPeriod > 0
    // Postcondition: The library item has been initialized with the specified
    //                values for title, publisher, copyright year, loan period,
    //                call number, duration, director, medium, and rating. The item is not checked out.
    public LibraryMovie(string theTitle, string thePublisher,
        int theCopyrightYear, int loanPeriod, string theCallNumber, double duration, string director, MediaType medium, MPAARatings rating)
        :base(theTitle, thePublisher, theCopyrightYear, loanPeriod, theCallNumber, duration)
    {
        Title = theTitle;
        Publisher = thePublisher;
        CopyrightYear = theCopyrightYear;
        LoanPeriod = loanPeriod;
        CallNumber = theCallNumber;
        Duration = duration;
        Director = director;
        Medium = medium;
        Rating = rating;

        ReturnToShelf(); // Make sure item is not checked out
    }

    public enum MPAARatings { G, PG, PG13, R, NC17, U };

    public string Director
    {
        // Precondition:  None
        // Postcondition: The director has been returned
        get
        {
            return _director;
        }

        // Precondition:  None
        // Postcondition: The director has been set to the specified value
        set
        {
            // Since empty director is OK, just change null to empty string
            _director = (value == null ? string.Empty : value.Trim());
        }
    }

    public override MediaType Medium
    {
        // Precondition:  None
        // Postcondition: The medium has been returned
        get
        {
            return _medium;
        }

        // Precondition:  value should exist in MediaType enums
        // Postcondition: The medium has been set to the specified value
        set
        {
            if ( Enum.IsDefined(typeof(MediaType), value) ) // Checks to see if Medium exists in MediaType enum
                _medium = value;
            else
                throw new ArgumentException($"{nameof(Medium)} is not a valid Media Type");
        }
    }

    public MPAARatings Rating
    {
        // Precondition:  None
        // Postcondition: The rating has been returned
        get
        {
            return _rating;
        }

        // Precondition:  value should exist in MPAARatings enum
        // Postcondition: The rating has been set to the specified value
        set
        {
            if (Enum.IsDefined(typeof(MPAARatings), value)) // Checks to see if Rating exists in MPAARatings enum
                _rating = value;
            else
                throw new ArgumentException($"{nameof(Rating)} is not a valid Rating");
        }
    }

    // Precondition:  daysLate should be positive, but validation is performed
    // Postcondition: If daysLate is valid, a decimal late fee is returned. If not, an exception is thrown with error message
    public override decimal CalcLateFee(int daysLate)
    {
        if (daysLate > 0)
        {
            decimal calcedFee = 0.0m; //temporary decimal variable to store calculated late fee
            if (Medium == MediaType.DVD || Medium == MediaType.VHS)
            {
                calcedFee = daysLate * DVD_VHS_FEE; 
            } else if (Medium == MediaType.BLURAY)
            {
                calcedFee = daysLate * BLURAY_FEE; 
            }
            return (calcedFee >= FEE_LIMIT) ? FEE_LIMIT : calcedFee; //Conditional return, return calced fee if it is less than limit, otherwise return limit
        }
        else
        {
            throw new ArgumentOutOfRangeException($"{nameof(daysLate)}", daysLate,
                    $"{nameof(daysLate)} must be positive");
        }
    }

    // Precondition:  None
    // Postcondition: A string is returned presenting the library movie's data on
    //                separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut
        string checkedOutBy; // Holds checked out message

        if (IsCheckedOut())
            checkedOutBy = $"Checked Out By: {NL}{Patron}";
        else
            checkedOutBy = "Not Checked Out";

        return $"Title: {Title}{NL}Publisher: {Publisher}{NL}" +
            $"Copyright: {CopyrightYear:D4}{NL}LoanPeriod: {LoanPeriod}{NL}Duration: {Duration}{NL}" +
            $"Director: {Director:D4}{NL}Medium: {Medium}{NL}Rating: {Rating}{NL}{checkedOutBy}";
    }
}
