﻿//// Program 1B
// CIS 200-01
// Grading ID: D4929
// Due: 2/22/2017

// File: Program.cs
// This file creates a test application class that creates
// a List of LibraryItem objects, LibraryBook objects, some LibraryPatron objects, performs LINQ queries, and displays tests to the console.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class Program
{
    // Precondition:  None
    // Postcondition: The LibraryItem and children have been tested
    public static void Main(string[] args)
    {   //LibraryBook objects//
        LibraryBook book1 = new LibraryBook("The Wright Guide to C#", "Andrew Wright", "UofL Press",
            2010, 3, "ZZ25 3G");  // 1st test book
        LibraryBook book2 = new LibraryBook("Harriet Pooter", "IP Thief", "Stealer Books",
            2000, 1, "AG773 ZF"); // 2nd test book
        LibraryBook book3 = new LibraryBook("The Color Mauve", "Mary Smith", "Beautiful Books Ltd.",
            1985, 5, "JJ438 4T"); // 3rd test book
        LibraryBook book4 = new LibraryBook("The Guan Guide to SQL", "Jeff Guan", "UofL Press",
            2017, 8, "ZZ24 4F");  // 4th test book
        LibraryBook book5 = new LibraryBook("    The Big Book of Doughnuts   ", "   Homer Simpson   ", "   Doh Books   ",
            2001, 10, "   AE842 7A   "); // 5th test book - Trims?

        //LibraryJournal objects//
        LibraryJournal journal1 = new LibraryJournal("Program Reflection Journal", "CIS200 Student", 2017, 1, "ZI29 4P", 2, 3, "Programming", "Andrew Wright"); //1st test journal
        LibraryJournal journal2 = new LibraryJournal("LINQedIn", "Microsoft", 2015, 4, "PL010 R9", 5, 6, "Programming", "Mrs. Editor"); //2nd test journal

        //LibraryMagazine objects//
        LibraryMagazine magazine1 = new LibraryMagazine("Reader's Try-Catch", "Stack Press", 2006, 7, "MM099 4G", 8, 9); //1st test magazine
        LibraryMagazine magazine2 = new LibraryMagazine("Reader's Try-Catch", "Stack Press", 2009, 10, "SH554 9F", 11, 12); //2nd test magazine
        LibraryMagazine magazine3 = new LibraryMagazine(".NETional Geographic", "BBC", 2007, 13, "WG777 7F", 14, 15); //3rd test magazine

        //LibraryMovie objects//
        LibraryMovie movie1 = new LibraryMovie("Singing in the Main(string[] args)", "Universal", 2004, 16, "YH834 L0", 100, "Andrew Wright", LibraryMediaItem.MediaType.BLURAY, LibraryMovie.MPAARatings.PG13); //1st test movie
        LibraryMovie movie2 = new LibraryMovie("Schindler's List<T>", "Warner", 2005, 17, "JJ545 B2", 200, "Prof. McIntosh", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.R); //2nd test movie

        //LibraryMusic objects//
        LibraryMusic music1 = new LibraryMusic("Comfortably enum", "Rock Studios", 2011, 1, "IG992 W6", 100, "Pink Floyd", LibraryMediaItem.MediaType.DVD, 10); //1st test music
        LibraryMusic music2 = new LibraryMusic("Ticket to Override", "UK Studios", 2015, 2, "CV888 S2", 15, "The Beatles", LibraryMediaItem.MediaType.VHS, 1); //2nd test music

        //LibraryPatron objects//
        LibraryPatron patron1 = new LibraryPatron("Bill Gates", "123456"); // 1st test patron
        LibraryPatron patron2 = new LibraryPatron("Tim Berners-Lee", "112233");  // 2nd test patron
        LibraryPatron patron3 = new LibraryPatron("   William Hewlett   ", "   654321   "); // 3rd test patron - Trims?
        LibraryPatron patron4 = new LibraryPatron("Linus Torvalds", "434342");  // 4th test patron
        LibraryPatron patron5 = new LibraryPatron("James Gosling", "545455");  // 5th test patron

        List<LibraryItem> libraryItems = new List<LibraryItem>(); // Test list of items
        // Add items to the list
        libraryItems.Add(book1);
        libraryItems.Add(book2);
        libraryItems.Add(book3);
        libraryItems.Add(book4);
        libraryItems.Add(book5);
        libraryItems.Add(journal1);
        libraryItems.Add(journal2);
        libraryItems.Add(magazine1);
        libraryItems.Add(magazine2);
        libraryItems.Add(magazine3);
        libraryItems.Add(movie1);
        libraryItems.Add(movie2);
        libraryItems.Add(music1);
        libraryItems.Add(music2);

        List<LibraryPatron> thePatrons = new List<LibraryPatron>(); // Test list of patrons
        // Add patrons to the list
        thePatrons.Add(patron1);
        thePatrons.Add(patron2);
        thePatrons.Add(patron3);
        thePatrons.Add(patron4);
        thePatrons.Add(patron5);

//BEGIN OUTPUT//
        Console.WriteLine("========== Original list of LibraryItems ==========");
        PrintItems(libraryItems);
        Console.WriteLine("Enter a key to continue");
        Console.ReadLine(); //Lets user type in console

// Task: Check out 5 items
        book1.CheckOut(patron1);
        journal2.CheckOut(patron2);
        magazine1.CheckOut(patron3);
        movie2.CheckOut(patron4);
        music1.CheckOut(patron5);
        Console.WriteLine("========== Task: Check out 5 items ==========");
        Console.WriteLine();
        Console.WriteLine("After changes");
        PrintItems(libraryItems);
        Console.WriteLine("Enter a key to continue");
        Console.ReadLine();

// LINQ 1 select all checked out items
        Console.WriteLine("========== LINQ 1: Select checked out items and count ==========");
        Console.WriteLine();
        IEnumerable<LibraryItem> checkedOut = //LINQ result variable storing the checked out items
                from item in libraryItems
                where item.IsCheckedOut()
                select item;
        foreach (LibraryItem item in checkedOut)
        {
            Console.WriteLine(item);
            Console.WriteLine();
        }
        int checkedOutCount = checkedOut.Count(); //int variable for storing the count of checked out items
        Console.WriteLine($"Count: {checkedOutCount}");
        Console.WriteLine();
        Console.WriteLine("Enter a key to continue");
        Console.ReadLine();

// LINQ 2 select all checked out LibraryMediaItems
        Console.WriteLine("========== LINQ 2: Select checked out LibraryMediaItems ==========");
        Console.WriteLine();
        IEnumerable<LibraryItem> checkedOutMedia = //LINQ result variable storing the checked out LibraryMediaItems
                from item in checkedOut
                where item is LibraryMediaItem
                select item;
        foreach (LibraryItem item in checkedOutMedia)
        {
            Console.WriteLine(item);
            Console.WriteLine();
        }
        Console.WriteLine("Enter a key to continue");
        Console.ReadLine();

// LINQ 3 select unique LibraryMagazines
        Console.WriteLine("========== LINQ 3: Select unique LibraryMagazines ==========");
        Console.WriteLine();
        IEnumerable<LibraryItem> uniqueMagazines = //LINQ result variable storing the unique LibraryMagazine titles
                from item in libraryItems
                where item is LibraryMagazine
                group item by new {item.Title} //using projection to group items by title
                into uniqueItems
                select uniqueItems.FirstOrDefault(); //selects the first unique LibraryMagazine based on title
        foreach (LibraryItem item in uniqueMagazines)
        {
            Console.WriteLine(item);
            Console.WriteLine();
        }
        Console.WriteLine("Enter a key to continue");
        Console.ReadLine();

// Task: Calculate 14 day late fees
        Console.WriteLine("========== Task: Calculate 14 day late fees ==========");
        Console.WriteLine();
        Console.WriteLine("Title                               Call Number  Late Fee"); // Column Headers
        Console.WriteLine("-----                               -----------  --------");
        foreach (LibraryItem item in libraryItems)
        {
            int daysLate = 14; //int variable for storing 2 weeks late value
            decimal calcedFee = item.CalcLateFee(daysLate); //decimal value for storing calculated late fee
            Console.WriteLine($"{item.Title,-35} {item.CallNumber,-12} {calcedFee,-5:C}");
            Console.WriteLine();
        }
        Console.WriteLine("Enter a key to continue");
        Console.ReadLine();

// Task: Return all the items
        Console.WriteLine("========== Task: Return all the items ==========");
        Console.WriteLine();
        for (int i = 0; i < libraryItems.Count; ++i)
            libraryItems[i].ReturnToShelf();
        PrintItems(libraryItems);
        int updatedCheckedOutCt = checkedOut.Count(); //int variable for storing new count of checked out items
        Console.WriteLine($"Checked out Count: {updatedCheckedOutCt}");
        Console.WriteLine();
        Console.WriteLine("Enter a key to continue");
        Console.ReadLine();

// Task: Modify loan period for LibraryBooks and display old/new loan periods
        Console.WriteLine("========== Task: Modify loan period for LibraryBooks ==========");
        Console.WriteLine();
        Console.WriteLine("Title                     Old Loan Period"); // Column Headers
        Console.WriteLine("-----                     ---------------");
        List<LibraryBook> libraryBooks = new List<LibraryBook>(); // New list for storing only LibraryBooks
        // Add books to the list
        libraryBooks.Add(book1);
        libraryBooks.Add(book2);
        libraryBooks.Add(book3);
        libraryBooks.Add(book4);
        libraryBooks.Add(book5);

        foreach (LibraryBook item in libraryBooks)
        {
            Console.WriteLine($"{item.Title,-25} {item.LoanPeriod,-5}");
            Console.WriteLine();
        }
        Console.WriteLine("Title                     New Loan Period"); // Column Headers
        Console.WriteLine("-----                     ---------------");
        foreach (LibraryBook item in libraryBooks)
        {
            int loanWeek = 7; //int variable for storing 7 days to be added to loan period for each book
            item.LoanPeriod += loanWeek; //Add loanWeek amount to each item's loan period
            Console.WriteLine($"{item.Title,-25} {item.LoanPeriod,-5}");
            Console.WriteLine();
        }
        Console.WriteLine("Enter a key to continue");
        Console.ReadLine();

// Task: Display all LibraryItems//
        Console.WriteLine("========== List of LibraryItems ==========");
        Console.WriteLine();
        PrintItems(libraryItems);
    }
     
    // Precondition:  Argument is of type List<LibraryItem> 
    // Postcondition: The items have been printed to the console
    public static void PrintItems(List<LibraryItem> items)
    {
        foreach (LibraryItem item in items)
        {
            Console.WriteLine(item);
            Console.WriteLine();
        }
    
    }
}