﻿// Program 2
// Grading ID: D4929
// Due Date: 3/9/17
// Course Section: CIS 200-01

//This file is the main form of the application. It contains a menu with various options and items 
//that allow the user to interact with the Library class data through their methods. It also
//provides reports that display data. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class Form1 : Form
    {
        internal static Library lib = new Library(); //Variable used across Library hierarchy classes to access/use Library class fields and methods
        // Precondition:  None
        // Postcondition: The library object above was used to add 5 patrons, 10 items, and check out 5 items.
        public Form1() //Main form constructor
        {
            InitializeComponent();
            //Create test patrons
            lib.AddPatron("Bill Gates", "123456");
            lib.AddPatron("Tim Berners-Lee", "112233");
            lib.AddPatron("Linus Torvalds", "434342");
            lib.AddPatron("James Gosling", "545455");
            lib.AddPatron("Andrew Wright", "12344321");
            //Create test Library items
            lib.AddLibraryBook("The Wright Guide to C#", "UofL Press", 2010, 2, "ZZ25 3G", "Andrew Wright");
            lib.AddLibraryBook("Harriet Pooter", "Stealer Books", 2000, 3, "AG773 ZF", "IP Thief");
            lib.AddLibraryJournal("Program Reflection Journal", "CIS200 Student", 2017, 1, "ZI29 4P", 2, 3, "Programming", "Andrew Wright");
            lib.AddLibraryJournal("LINQedIn", "Microsoft", 2015, 4, "PL010 R9", 5, 6, "Programming", "Mrs. Editor");
            lib.AddLibraryMagazine("Reader's Try-Catch", "Stack Press", 2009, 10, "SH554 9F", 11, 12);
            lib.AddLibraryMagazine(".NETional Geographic", "BBC", 2007, 13, "WG777 7F", 14, 15);
            lib.AddLibraryMovie("Singing in the Main(string[] args)", "Universal", 2004, 16, "YH834 L0", 100, "Andrew Wright", LibraryMediaItem.MediaType.BLURAY, LibraryMovie.MPAARatings.PG13);
            lib.AddLibraryMovie("Schindler's List<T>", "Warner", 2005, 17, "JJ545 B2", 200, "Prof. McIntosh", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.R);
            lib.AddLibraryMusic("Comfortably enum", "Rock Studios", 2011, 1, "IG992 W6", 100, "Pink Floyd", LibraryMediaItem.MediaType.CD, 10);
            lib.AddLibraryMusic("Ticket to Override", "UK Studios", 2015, 2, "CV888 S2", 15, "The Beatles", LibraryMediaItem.MediaType.SACD, 1);
            //Index variables to avoid magic numbers
            int idx0 = 0;
            int idx1 = 1;
            int idx2 = 2;
            int idx3 = 3;
            int idx4 = 4;
            //Check out some items using patron/item indices
            lib.CheckOut(idx0, idx0);
            lib.CheckOut(idx1, idx1);
            lib.CheckOut(idx2, idx2);
            lib.CheckOut(idx3, idx3);
            lib.CheckOut(idx4, idx4);
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Opens a MessageBox with basic info about the assignment
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string NL = Environment.NewLine; // NewLine shortcut
            MessageBox.Show("ABOUT PROG 2"+ NL + NL +
                            "Grading ID: D4929" + NL +
                            "Program: 2" + NL + 
                            "Due Date: 3/9/17" + NL +
                            "Course Section: CIS 200-01");
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Exits the application
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit(); //Closes application
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Instantiates the InsertPatron form
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertPatron patronForm = new InsertPatron(); //Creates new InsertPatron form in memory
            DialogResult result; //Creates DialogResult variable to be used for displaying form
            result = patronForm.ShowDialog();
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Instantiates the InsertBook form
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertBook bookForm = new InsertBook(); //Creates new InsertBook form in memory
            DialogResult result; //Creates DialogResult variable to be used for displaying form
            result = bookForm.ShowDialog();
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Instantiates the ItemCheckOut form
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ItemCheckOut checkOutForm = new ItemCheckOut(); //Creates new ItemCheckOut form in memory
            DialogResult result; //Creates DialogResult variable to be used for displaying form
            result = checkOutForm.ShowDialog();
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Instantiates the ItemReturn form
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ItemReturn returnForm = new ItemReturn(); //Creates new ItemReturn form in memory
            DialogResult result; //Creates DialogResult variable to be used for displaying form
            result = returnForm.ShowDialog();
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Instantiates the ReportPatrons form
        private void patronListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportPatrons patronForm = new ReportPatrons(); //Creates new ReportPatrons form in memory
            DialogResult result; //Creates DialogResult variable to be used for displaying form
            result = patronForm.ShowDialog();
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Instantiates the ReportItems form
        private void itemListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportItems itemForm = new ReportItems(); //Creates new ReportItems form in memory
            DialogResult result; //Creates DialogResult variable to be used for displaying form
            result = itemForm.ShowDialog();
        }

        // Precondition:  Form1 has been instantiated
        // Postcondition: Instantiates the checkedOutForm form
        private void checkedOutItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            checkedOutForm checkedOut = new checkedOutForm(); //Creates new checkedOutForm form in memory
            DialogResult result; //Creates DialogResult variable to be used for displaying form
            result = checkedOut.ShowDialog();
        }
    }
}
