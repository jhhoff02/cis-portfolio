﻿// Program 2
// Grading ID: D4929
// Due Date: 3/9/17
// Course Section: CIS 200-01

//This file is a subform of Form1. It allows the user to insert a 
//Library Patron. It contains textboxes to enter the related info 
//and closes the form if the data is valid and the patron object is successfully created.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class InsertPatron : Form
    {
        // Precondition:  Form1 was instantiated
        // Postcondition: InsertPatron is instantiated
        public InsertPatron()
        {
            InitializeComponent();
        }

        // Precondition:  Name and ID are not empty or null for patron input
        // Postcondition: Using Library class object, an library patron is added to the library if the input is valid
        // If not, messages are displayed to user.
        private void addPatronBtn_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(nameTxtBox.Text))
            {
                if (!String.IsNullOrEmpty(idTxtBox.Text))
                {
                    string patronName = nameTxtBox.Text; //string variable for holding the user input patron name
                    string patronID = idTxtBox.Text; //string variable for holding the user input patron ID

                    LibraryPatron patron = new LibraryPatron(patronName, patronID); //Creates new patron using user input info
                    Form1.lib._patrons.Add(patron);

                    //Close InsertPatron form
                    this.DialogResult = DialogResult.Cancel;
                } else //Empty ID
                {
                    feedbackLbl.ForeColor = Color.Red;
                    feedbackLbl.Text = "ID cannot be empty";
                }
            } else //Empty Name
            {
                feedbackLbl.ForeColor = Color.Red;
                feedbackLbl.Text = "Name cannot be empty";
            }
        }
    }
}
