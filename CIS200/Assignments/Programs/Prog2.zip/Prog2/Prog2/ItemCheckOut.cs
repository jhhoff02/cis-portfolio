﻿// Program 2
// Grading ID: D4929
// Due Date: 3/9/17
// Course Section: CIS 200-01

//This file is a subform of Form1. It allows the user to check out 
//an existing library item by assigning it to a library patron in the system. 
//It consists of dropdown menus populated by the library items and patrons, and 
//buttons for checking out the items and going back.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ItemCheckOut : Form
    {
        // Precondition:  Form1 was instantiated
        // Postcondition: ItemCheckOut is instantiated and comboboxes are populated
        // with data from Library about current items and patrons to choose from.
        public ItemCheckOut()
        {
            InitializeComponent();
            List<LibraryPatron> patronList = new List<LibraryPatron>(); //List to hold current library patrons
            List<LibraryItem> itemList = new List<LibraryItem>(); //List to hold current library items
            itemList = Form1.lib.GetItemsList();
            patronList = Form1.lib.GetPatronsList();
            foreach (LibraryItem item in itemList)
            {
                string displayStr = $"{item.Title}, {item.CallNumber}"; //String variable for displaying specific data in dropdown
                itemsCombo.Items.Add(displayStr);
            }
            foreach (LibraryPatron patron in patronList)
            {
                string displayStr = $"{patron.PatronName}, {patron.PatronID}"; //String variable for displaying specific data in dropdown
                patronsCombo.Items.Add(displayStr);
            }
        }

        // Precondition:  A Library item and patron have both been selected from dropdowns
        // Postcondition: The chosen library item is assigned to the selected library patron and the form closes.
        private void checkOutBtn_Click(object sender, EventArgs e)
        {
                if(patronsCombo.SelectedIndex > -1 && itemsCombo.SelectedIndex > -1)
                {
                    Form1.lib.CheckOut(itemsCombo.SelectedIndex, patronsCombo.SelectedIndex);
                    this.DialogResult = DialogResult.Cancel; //Close form after successful checkout
                }
                else //Less than 2 items selected
                {
                    feedbackLbl.ForeColor = Color.Red;
                    feedbackLbl.Text = "Please select an item from both";
                }
        }

        // Precondition:  None
        // Postcondition: The ItemCheckOut form has been closed and returns user to the main form.
        private void backBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
