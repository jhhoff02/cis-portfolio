﻿// Program 2
// Grading ID: D4929
// Due Date: 3/9/17
// Course Section: CIS 200-01

//This file is a subform of Form1. It allows the user to return a 
//library item by selecting it from a dropdown and clicking the return button. 
//There is also a back button.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ItemReturn : Form
    {
        // Precondition:  Form1 was instantiated
        // Postcondition: ItemReturn is instantiated and combobox is populated
        // with data from Library about current items to choose from.
        public ItemReturn()
        {
            InitializeComponent();
            List<LibraryItem> itemList = new List<LibraryItem>(); //List to hold current library items
            itemList = Form1.lib.GetItemsList();
            foreach (LibraryItem item in itemList)
            {
                string displayStr = $"{item.Title}, {item.CallNumber}"; //String variable for displaying specific data in dropdown
                itemsReturnCombo.Items.Add(displayStr);
            }
        }

        // Precondition:  A Library item has been selected from the dropdown
        // Postcondition: The chosen library item is returned and no longer assigned to a patron.
        private void returnBtn_Click(object sender, EventArgs e)
        {
                if (itemsReturnCombo.SelectedIndex > -1)
                {
                    Form1.lib.ReturnToShelf(itemsReturnCombo.SelectedIndex);
                    this.DialogResult = DialogResult.Cancel; //Close form after successful return
                }
                else //No item chosen
                {
                feedbackLbl.ForeColor = Color.Red;
                feedbackLbl.Text = "Please select an item to return";
            }
        }

        // Precondition:  None
        // Postcondition: The ItemCheckOut form has been closed and returns user to the main form.
        private void backReturnBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
