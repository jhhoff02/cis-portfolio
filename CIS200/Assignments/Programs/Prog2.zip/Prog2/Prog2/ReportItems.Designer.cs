﻿namespace LibraryItems
{
    partial class ReportItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.itemsTxtBox = new System.Windows.Forms.TextBox();
            this.closeItemsBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // itemsTxtBox
            // 
            this.itemsTxtBox.Location = new System.Drawing.Point(13, 13);
            this.itemsTxtBox.Multiline = true;
            this.itemsTxtBox.Name = "itemsTxtBox";
            this.itemsTxtBox.ReadOnly = true;
            this.itemsTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.itemsTxtBox.Size = new System.Drawing.Size(259, 213);
            this.itemsTxtBox.TabIndex = 1;
            this.itemsTxtBox.TabStop = false;
            // 
            // closeItemsBtn
            // 
            this.closeItemsBtn.Location = new System.Drawing.Point(101, 232);
            this.closeItemsBtn.Name = "closeItemsBtn";
            this.closeItemsBtn.Size = new System.Drawing.Size(83, 23);
            this.closeItemsBtn.TabIndex = 2;
            this.closeItemsBtn.Text = "Close Report";
            this.closeItemsBtn.UseVisualStyleBackColor = true;
            this.closeItemsBtn.Click += new System.EventHandler(this.closeItemsBtn_Click);
            // 
            // ReportItems
            // 
            this.AcceptButton = this.closeItemsBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.closeItemsBtn);
            this.Controls.Add(this.itemsTxtBox);
            this.Name = "ReportItems";
            this.Text = "Report Items";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox itemsTxtBox;
        private System.Windows.Forms.Button closeItemsBtn;
    }
}