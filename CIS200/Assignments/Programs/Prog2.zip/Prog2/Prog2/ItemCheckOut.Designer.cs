﻿namespace LibraryItems
{
    partial class ItemCheckOut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.itemsCombo = new System.Windows.Forms.ComboBox();
            this.itemLbl = new System.Windows.Forms.Label();
            this.patronLbl = new System.Windows.Forms.Label();
            this.patronsCombo = new System.Windows.Forms.ComboBox();
            this.checkOutBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.feedbackLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // itemsCombo
            // 
            this.itemsCombo.FormattingEnabled = true;
            this.itemsCombo.Location = new System.Drawing.Point(136, 37);
            this.itemsCombo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.itemsCombo.Name = "itemsCombo";
            this.itemsCombo.Size = new System.Drawing.Size(299, 24);
            this.itemsCombo.TabIndex = 0;
            // 
            // itemLbl
            // 
            this.itemLbl.AutoSize = true;
            this.itemLbl.Location = new System.Drawing.Point(41, 41);
            this.itemLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.itemLbl.Name = "itemLbl";
            this.itemLbl.Size = new System.Drawing.Size(38, 17);
            this.itemLbl.TabIndex = 1;
            this.itemLbl.Text = "Item:";
            // 
            // patronLbl
            // 
            this.patronLbl.AutoSize = true;
            this.patronLbl.Location = new System.Drawing.Point(41, 84);
            this.patronLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.patronLbl.Name = "patronLbl";
            this.patronLbl.Size = new System.Drawing.Size(54, 17);
            this.patronLbl.TabIndex = 2;
            this.patronLbl.Text = "Patron:";
            // 
            // patronsCombo
            // 
            this.patronsCombo.FormattingEnabled = true;
            this.patronsCombo.Location = new System.Drawing.Point(136, 84);
            this.patronsCombo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.patronsCombo.Name = "patronsCombo";
            this.patronsCombo.Size = new System.Drawing.Size(299, 24);
            this.patronsCombo.TabIndex = 3;
            // 
            // checkOutBtn
            // 
            this.checkOutBtn.Location = new System.Drawing.Point(339, 149);
            this.checkOutBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkOutBtn.Name = "checkOutBtn";
            this.checkOutBtn.Size = new System.Drawing.Size(100, 28);
            this.checkOutBtn.TabIndex = 4;
            this.checkOutBtn.Text = "Check Out";
            this.checkOutBtn.UseVisualStyleBackColor = true;
            this.checkOutBtn.Click += new System.EventHandler(this.checkOutBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.backBtn.Location = new System.Drawing.Point(136, 149);
            this.backBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(100, 28);
            this.backBtn.TabIndex = 5;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // feedbackLbl
            // 
            this.feedbackLbl.AutoSize = true;
            this.feedbackLbl.Location = new System.Drawing.Point(136, 116);
            this.feedbackLbl.Name = "feedbackLbl";
            this.feedbackLbl.Size = new System.Drawing.Size(0, 17);
            this.feedbackLbl.TabIndex = 6;
            // 
            // ItemCheckOut
            // 
            this.AcceptButton = this.checkOutBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.backBtn;
            this.ClientSize = new System.Drawing.Size(452, 190);
            this.Controls.Add(this.feedbackLbl);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.checkOutBtn);
            this.Controls.Add(this.patronsCombo);
            this.Controls.Add(this.patronLbl);
            this.Controls.Add(this.itemLbl);
            this.Controls.Add(this.itemsCombo);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ItemCheckOut";
            this.Text = "Check Out Items";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox itemsCombo;
        private System.Windows.Forms.Label itemLbl;
        private System.Windows.Forms.Label patronLbl;
        private System.Windows.Forms.ComboBox patronsCombo;
        private System.Windows.Forms.Button checkOutBtn;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label feedbackLbl;
    }
}