﻿namespace LibraryItems
{
    partial class InsertPatron
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLbl = new System.Windows.Forms.Label();
            this.idLbl = new System.Windows.Forms.Label();
            this.addPatronBtn = new System.Windows.Forms.Button();
            this.nameTxtBox = new System.Windows.Forms.TextBox();
            this.idTxtBox = new System.Windows.Forms.TextBox();
            this.feedbackLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(16, 31);
            this.nameLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(49, 17);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "Name:";
            // 
            // idLbl
            // 
            this.idLbl.AutoSize = true;
            this.idLbl.Location = new System.Drawing.Point(17, 71);
            this.idLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.idLbl.Name = "idLbl";
            this.idLbl.Size = new System.Drawing.Size(25, 17);
            this.idLbl.TabIndex = 1;
            this.idLbl.Text = "ID:";
            // 
            // addPatronBtn
            // 
            this.addPatronBtn.Location = new System.Drawing.Point(105, 129);
            this.addPatronBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addPatronBtn.Name = "addPatronBtn";
            this.addPatronBtn.Size = new System.Drawing.Size(100, 28);
            this.addPatronBtn.TabIndex = 2;
            this.addPatronBtn.Text = "Save";
            this.addPatronBtn.UseVisualStyleBackColor = true;
            this.addPatronBtn.Click += new System.EventHandler(this.addPatronBtn_Click);
            // 
            // nameTxtBox
            // 
            this.nameTxtBox.Location = new System.Drawing.Point(89, 32);
            this.nameTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.nameTxtBox.Name = "nameTxtBox";
            this.nameTxtBox.Size = new System.Drawing.Size(132, 22);
            this.nameTxtBox.TabIndex = 3;
            // 
            // idTxtBox
            // 
            this.idTxtBox.Location = new System.Drawing.Point(89, 73);
            this.idTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.idTxtBox.Name = "idTxtBox";
            this.idTxtBox.Size = new System.Drawing.Size(132, 22);
            this.idTxtBox.TabIndex = 4;
            // 
            // feedbackLbl
            // 
            this.feedbackLbl.AutoSize = true;
            this.feedbackLbl.Location = new System.Drawing.Point(19, 104);
            this.feedbackLbl.Name = "feedbackLbl";
            this.feedbackLbl.Size = new System.Drawing.Size(0, 17);
            this.feedbackLbl.TabIndex = 5;
            // 
            // InsertPatron
            // 
            this.AcceptButton = this.addPatronBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 170);
            this.Controls.Add(this.feedbackLbl);
            this.Controls.Add(this.idTxtBox);
            this.Controls.Add(this.nameTxtBox);
            this.Controls.Add(this.addPatronBtn);
            this.Controls.Add(this.idLbl);
            this.Controls.Add(this.nameLbl);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "InsertPatron";
            this.Text = "Insert Patron";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label idLbl;
        public System.Windows.Forms.Button addPatronBtn;
        private System.Windows.Forms.TextBox nameTxtBox;
        private System.Windows.Forms.TextBox idTxtBox;
        private System.Windows.Forms.Label feedbackLbl;
    }
}