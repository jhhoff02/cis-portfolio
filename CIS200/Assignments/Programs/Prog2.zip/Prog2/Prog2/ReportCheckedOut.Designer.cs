﻿namespace LibraryItems
{
    partial class checkedOutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.itemsTxtBox = new System.Windows.Forms.TextBox();
            this.closeCheckedOutItemsBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // itemsTxtBox
            // 
            this.itemsTxtBox.Location = new System.Drawing.Point(13, 12);
            this.itemsTxtBox.Multiline = true;
            this.itemsTxtBox.Name = "itemsTxtBox";
            this.itemsTxtBox.ReadOnly = true;
            this.itemsTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.itemsTxtBox.Size = new System.Drawing.Size(259, 213);
            this.itemsTxtBox.TabIndex = 2;
            this.itemsTxtBox.TabStop = false;
            // 
            // closeCheckedOutItemsBtn
            // 
            this.closeCheckedOutItemsBtn.Location = new System.Drawing.Point(101, 231);
            this.closeCheckedOutItemsBtn.Name = "closeCheckedOutItemsBtn";
            this.closeCheckedOutItemsBtn.Size = new System.Drawing.Size(83, 23);
            this.closeCheckedOutItemsBtn.TabIndex = 3;
            this.closeCheckedOutItemsBtn.Text = "Close Report";
            this.closeCheckedOutItemsBtn.UseVisualStyleBackColor = true;
            this.closeCheckedOutItemsBtn.Click += new System.EventHandler(this.closeCheckedOutItemsBtn_Click);
            // 
            // checkedOutForm
            // 
            this.AcceptButton = this.closeCheckedOutItemsBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.closeCheckedOutItemsBtn);
            this.Controls.Add(this.itemsTxtBox);
            this.Name = "checkedOutForm";
            this.Text = "Checked Out Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox itemsTxtBox;
        private System.Windows.Forms.Button closeCheckedOutItemsBtn;
    }
}