﻿// Program 2
// Grading ID: D4929
// Due Date: 3/9/17
// Course Section: CIS 200-01

//This file is a subform of Form1. It allows the user to view a report
//that returns info about patrons in the Library system.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ReportPatrons : Form
    {
        // Precondition:  Form1 was instantiated
        // Postcondition: ReportPatrons is instantiated and textbox displays all patrons in library, as well as the total count.
        public ReportPatrons()
        {
            InitializeComponent();
            List<LibraryPatron> patronList = new List<LibraryPatron>(); //List to hold current library items
            patronList = Form1.lib.GetPatronsList();
            StringBuilder sb = new StringBuilder(); //StringBuilder object for building report output
            foreach (LibraryPatron item in patronList)
            {
                sb.AppendLine(item.ToString());
                sb.AppendLine();
            }
            sb.AppendLine("Total Patrons: " + Form1.lib.GetPatronCount().ToString());
            patronsTxtBox.Text = sb.ToString();
        }

        // Precondition:  None
        // Postcondition: The ReportPatrons form has been closed and returns user to the main form.
        private void closePatronsBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
