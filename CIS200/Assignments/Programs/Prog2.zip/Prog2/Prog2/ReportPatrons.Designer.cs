﻿namespace LibraryItems
{
    partial class ReportPatrons
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.patronsTxtBox = new System.Windows.Forms.TextBox();
            this.closePatronsBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // patronsTxtBox
            // 
            this.patronsTxtBox.Location = new System.Drawing.Point(13, 13);
            this.patronsTxtBox.Multiline = true;
            this.patronsTxtBox.Name = "patronsTxtBox";
            this.patronsTxtBox.ReadOnly = true;
            this.patronsTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.patronsTxtBox.Size = new System.Drawing.Size(259, 214);
            this.patronsTxtBox.TabIndex = 0;
            this.patronsTxtBox.TabStop = false;
            // 
            // closePatronsBtn
            // 
            this.closePatronsBtn.Location = new System.Drawing.Point(101, 233);
            this.closePatronsBtn.Name = "closePatronsBtn";
            this.closePatronsBtn.Size = new System.Drawing.Size(83, 23);
            this.closePatronsBtn.TabIndex = 1;
            this.closePatronsBtn.Text = "Close Report";
            this.closePatronsBtn.UseVisualStyleBackColor = true;
            this.closePatronsBtn.Click += new System.EventHandler(this.closePatronsBtn_Click);
            // 
            // ReportPatrons
            // 
            this.AcceptButton = this.closePatronsBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.closePatronsBtn);
            this.Controls.Add(this.patronsTxtBox);
            this.Name = "ReportPatrons";
            this.Text = "Patrons Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox patronsTxtBox;
        private System.Windows.Forms.Button closePatronsBtn;
    }
}