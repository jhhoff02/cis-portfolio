﻿// Program 2
// Grading ID: D4929
// Due Date: 3/9/17
// Course Section: CIS 200-01

//This file is a subform of Form1. It allows the user to insert a 
//Library item. It contains textboxes to enter the related info 
//and closes the form if the data is valid and the library object is successfully created.
//It also includes a dropdown for the user to select the type of library item, and
//then displays the related input fields for that item.

//!! Note to Prof. Wright: 
//I tried this library item selection for fun and practice. The groupboxes are 
//overlapping because I set their Location properties to have the same coordinates. I did this to avoid any 
//groupbox becoming a child of another if I drag and drop it over it. Sorry if this takes longer to grade!

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class InsertBook : Form
    {
        int idx0 = 0; //int variable for storing index value
        // Precondition:  Form1 was instantiated
        // Postcondition: InsertBook is instantiated
        public InsertBook()
        {
            InitializeComponent();
            List<string> itemTypeList = new List<string>() {"Book", "Journal", "Magazine", "Movie", "Music"}; //List to hold library item types
            foreach (string type in itemTypeList)
            {
                chooseItemCombo.Items.Add(type);
            }
            chooseItemCombo.SelectedIndex = idx0;
            movieGroupBox.Visible = false; //Initially hide groupboxes for types besides Book
            musicGroupBox.Visible = false; //Initially hide groupboxes for types besides Book
            journalGroupBox.Visible = false; //Initially hide groupboxes for types besides Book
            magazineGroupBox.Visible = false; //Initially hide groupboxes for types besides Book
        }

        // Precondition:  None of the required fields are empty or null
        // Postcondition: Using Library class object, an library item is added to the library if the input is valid
        // If not, messages are displayed to user.
        private void addBookBtn_Click(object sender, EventArgs e)
        {
            //This decision tree checks to make sure the fields library items have in common
            //are not empty or not (at least one per if-statement, meaning something is filled in
            //for that required field)
            if (!String.IsNullOrEmpty(titleTxtBox.Text) ||
                !String.IsNullOrEmpty(titleJournalTxt.Text) ||
                !String.IsNullOrEmpty(titleMagazineTxt.Text) ||
                !String.IsNullOrEmpty(titleMovieTxt.Text) ||
                !String.IsNullOrEmpty(titleMusicTxt.Text))
            {
                if (!String.IsNullOrEmpty(publisherTxtBox.Text) ||
                    !String.IsNullOrEmpty(publisherJournalTxt.Text) ||
                    !String.IsNullOrEmpty(publisherMagTxt.Text) ||
                    !String.IsNullOrEmpty(publisherMovieTxt.Text) ||
                    !String.IsNullOrEmpty(publisherMusicTxt.Text))
                {
                    if (!String.IsNullOrEmpty(crYrTxtBox.Text) ||
                        !String.IsNullOrEmpty(crJournalTxt.Text) ||
                        !String.IsNullOrEmpty(crMagazineTxt.Text) ||
                        !String.IsNullOrEmpty(crMovieTxt.Text) ||
                        !String.IsNullOrEmpty(crMusicTxt.Text))
                    {
                        if (!String.IsNullOrEmpty(loanPeriodTxtBox.Text) ||
                            !String.IsNullOrEmpty(loanJournalTxt.Text) ||
                            !String.IsNullOrEmpty(loanMagTxt.Text) ||
                            !String.IsNullOrEmpty(loanMovieTxt.Text) ||
                            !String.IsNullOrEmpty(loanMusicTxt.Text))
                        {
                            if (!String.IsNullOrEmpty(callNumTxtBox.Text) ||
                                !String.IsNullOrEmpty(callNumJournalTxt.Text) ||
                                !String.IsNullOrEmpty(callNumMagTxt.Text) ||
                                !String.IsNullOrEmpty(callNumMovieTxt.Text) ||
                                !String.IsNullOrEmpty(callNumMusicTxt.Text))
                            {
                                //Switch statement for determining which fields to validate and use to create a library item
                                switch (chooseItemCombo.SelectedItem.ToString())
                                {
                                    //Validate Book fields
                                    case "Book":
                                        ParseBook();
                                        break;
                                    //Validate Journal fields
                                    case "Journal":
                                        ParseJournal();
                                        break;
                                    //Validate Magazine fields
                                    case "Magazine":
                                        ParseMagazine();
                                        break;
                                    //Validate Movie fields
                                    case "Movie":
                                        ParseMovie();
                                        break;
                                    //Validate Music fields
                                    case "Music":
                                        ParseMusic();
                                        break;
                                    //Do nothing, don't try to validate fields (will probably never run)
                                    default:
                                        break;
                                }
                            }
                            else //Call Number empty
                            {
                                feedbackLbl.ForeColor = Color.Red;
                                feedbackLbl.Text = "Call Number cannot be empty";
                            }
                        }
                        else //Loan period empty
                        {
                            feedbackLbl.ForeColor = Color.Red;
                            feedbackLbl.Text = "Loan Period cannot be empty";
                        }
                    } else //Copyright empty
                    {
                        feedbackLbl.ForeColor = Color.Red;
                        feedbackLbl.Text = "Copyright Year cannot be empty";
                    }
                }
                else //Publisher empty
                {
                    feedbackLbl.ForeColor = Color.Red;
                    feedbackLbl.Text = "Publisher cannot be empty";
                }
            }
            else //Title empty
            {
                feedbackLbl.ForeColor = Color.Red;
                feedbackLbl.Text = "Title cannot be empty";
            }
        }

        // Precondition:  User has made a selection from the library item type dropdown
        // Postcondition: Correct groupbox is displayed with input fields related to the
        // selected item type, and other groupboxes are hidden.
        private void chooseItemCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            //switch statement to determine which groupbox/input fields to display based on dropdown selection
            switch(chooseItemCombo.SelectedItem.ToString())
            {
                //Show bookGroupBox, hides others
                case "Book":
                    bookGroupBox.Visible = true;
                    movieGroupBox.Visible = !bookGroupBox.Visible;
                    musicGroupBox.Visible = !bookGroupBox.Visible;
                    journalGroupBox.Visible = !bookGroupBox.Visible;
                    magazineGroupBox.Visible = !bookGroupBox.Visible;
                    break;
                //Show journalGroupBox, hides others
                case "Journal":
                    journalGroupBox.Visible = true;
                    movieGroupBox.Visible = !journalGroupBox.Visible;
                    musicGroupBox.Visible = !journalGroupBox.Visible;
                    bookGroupBox.Visible = !journalGroupBox.Visible;
                    magazineGroupBox.Visible = !journalGroupBox.Visible;
                    break;
                //Show magazineGroupBox, hides others
                case "Magazine":
                    magazineGroupBox.Visible = true;
                    movieGroupBox.Visible = !magazineGroupBox.Visible;
                    bookGroupBox.Visible = !magazineGroupBox.Visible;
                    musicGroupBox.Visible = !magazineGroupBox.Visible;
                    journalGroupBox.Visible = !magazineGroupBox.Visible;
                    break;
                //Show movieGroupBox, hides others
                case "Movie":
                    movieGroupBox.Visible = true;
                    bookGroupBox.Visible = !movieGroupBox.Visible;
                    musicGroupBox.Visible = !movieGroupBox.Visible;
                    journalGroupBox.Visible = !movieGroupBox.Visible;
                    magazineGroupBox.Visible = !movieGroupBox.Visible;
                    break;
                //Show musicGroupBox, hides others
                case "Music":
                    musicGroupBox.Visible = true;
                    movieGroupBox.Visible = !musicGroupBox.Visible;
                    journalGroupBox.Visible = !musicGroupBox.Visible;
                    bookGroupBox.Visible = !musicGroupBox.Visible;
                    magazineGroupBox.Visible = !musicGroupBox.Visible;
                    break;
                //Show bookGroupBox by default (probably will never run)
                default:
                    bookGroupBox.Visible = true;
                    movieGroupBox.Visible = !bookGroupBox.Visible;
                    musicGroupBox.Visible = !bookGroupBox.Visible;
                    journalGroupBox.Visible = !bookGroupBox.Visible;
                    magazineGroupBox.Visible = !bookGroupBox.Visible;
                    break;
            }
        }

        // Precondition:  User has selected Book as the library item type and has entered info in all fields
        // Postcondition: A new library item of type LibraryBook is added to the library with user input
        private void ParseBook()
        {
            string bookTitle = titleTxtBox.Text; //string variable for holding the book title
            string bookPublisher = publisherTxtBox.Text; //string variable for holding the book publisher
            string crInput = crYrTxtBox.Text; //string variable for holding the book copyright year
            string loanInput = loanPeriodTxtBox.Text; //string variable for holding the book loan period
            string bookCallNum = callNumTxtBox.Text; //string variable for holding the book call number
            string bookAuthor = authorTxtBox.Text; //string variable for holding the book author
            int bookCR; //int variable for storing parsed copyright year
            int bookLoan; //int variable for storing parsed loan period

            if (int.TryParse(crInput, out bookCR))
            {
                if (int.TryParse(loanInput, out bookLoan))
                {
                    Form1.lib.AddLibraryBook(bookTitle, bookPublisher, bookCR, bookLoan, bookCallNum, bookAuthor);
                    //Close InsertPatron form
                    this.DialogResult = DialogResult.Cancel;

                }
                else //Invalid Loan Period
                {
                    feedbackLbl.ForeColor = Color.Red;
                    feedbackLbl.Text = "Loan Period must be an integer";
                }
            }
            else //Invalid Copyright
            {
                feedbackLbl.ForeColor = Color.Red;
                feedbackLbl.Text = "Copyright must be an integer";
            }
        }

        // Precondition:  User has selected Journal as the library item type and has entered info in all fields
        // Postcondition: A new library item of type LibraryJournal is added to the library with user input
        private void ParseJournal()
        {
            string journalTitle = titleJournalTxt.Text; //string variable for holding the journal title
            string journalPublisher = publisherJournalTxt.Text; //string variable for holding the journal publisher
            string crInput = crJournalTxt.Text; //string variable for holding the journal copyright year
            string loanInput = loanJournalTxt.Text; //string variable for holding the journal loan period
            string journalCallNum = callNumJournalTxt.Text; //string variable for holding the journal call number
            string volume = volumeTxtBox.Text; //string variable for holding the journal volume
            string numberJournal = numberTxtBox.Text; //string variable for holding the journal number
            string discipline = disciplineTxtBox.Text; //string variable for holding the journal discipline
            string editor = editorTxtBox.Text; //string variable for holding the journal editor
            int journalCR; //int variable for storing parsed copyright year
            int journalLoan; //int variable for storing parsed loan period
            int journalVolume; //int variable for storing parsed volume
            int journalNumber; //int variable for storing parsed number

            if (int.TryParse(crInput, out journalCR))
            {
                if (int.TryParse(loanInput, out journalLoan))
                {
                    if (!String.IsNullOrEmpty(disciplineTxtBox.Text))
                    {
                        if (!String.IsNullOrEmpty(editorTxtBox.Text))
                        {
                            if (int.TryParse(volume, out journalVolume))
                            {
                                if (int.TryParse(numberJournal, out journalNumber))
                                {
                                   Form1.lib.AddLibraryJournal(journalTitle, journalPublisher, journalCR,
                                                               journalLoan, journalCallNum, journalVolume,
                                                               journalNumber, discipline, editor);
                                   //Close InsertPatron form
                                   this.DialogResult = DialogResult.Cancel;
                                }
                                else //Invalid Number
                                {
                                    feedbackLbl.ForeColor = Color.Red;
                                    feedbackLbl.Text = "Number must be an integer";
                                }
                            }
                            else //Invalid Volume
                            {
                                feedbackLbl.ForeColor = Color.Red;
                                feedbackLbl.Text = "Volume must be an integer";
                            }
                        }
                        else //Editor empty
                        {
                            feedbackLbl.ForeColor = Color.Red;
                            feedbackLbl.Text = "Editor cannot be empty";
                        }
                    }
                    else //Discipline empty
                    {
                        feedbackLbl.ForeColor = Color.Red;
                        feedbackLbl.Text = "Discipline cannot be empty";
                    }
                }
                else //Invalid Loan Period
                {
                    feedbackLbl.ForeColor = Color.Red;
                    feedbackLbl.Text = "Loan Period must be an integer";
                }
            }
            else //Invalid Copyright
            {
                feedbackLbl.ForeColor = Color.Red;
                feedbackLbl.Text = "Copyright must be an integer";
            }
        }

        // Precondition:  User has selected Magazine as the library item type and has entered info in all fields
        // Postcondition: A new library item of type LibraryMagazine is added to the library with user input
        private void ParseMagazine()
        {
            string magTitle = titleMagazineTxt.Text; //string variable for holding the magazine title
            string magPublisher = publisherMagTxt.Text; //string variable for holding the magazine publisher
            string magCR = crMagazineTxt.Text; //string variable for holding the magazine copyright year
            string magLoan = loanMagTxt.Text; //string variable for holding the magazine loan period
            string magCallNum = callNumMagTxt.Text; //string variable for holding the magazine call number
            string magVol = volumeMagTxt.Text; //string variable for holding the magazine volume
            string magNum = numberMagTxt.Text; //string variable for holding the magazine number
            int magazineCR; //int variable for storing parsed copyright year
            int magazineLoan; //int variable for storing parsed loan period
            int magazineVol; //int variable for storing parsed volume
            int magazineNumber; //int variable for storing parsed number

            if (int.TryParse(magCR, out magazineCR))
            {
                if (int.TryParse(magLoan, out magazineLoan))
                {
                    if (int.TryParse(magVol, out magazineVol))
                            {
                                if (int.TryParse(magNum, out magazineNumber))
                                {
                                    Form1.lib.AddLibraryMagazine(magTitle, magPublisher, magazineCR,
                                                                magazineLoan, magCallNum, magazineVol,
                                                                magazineNumber);
                                    //Close InsertPatron form
                                    this.DialogResult = DialogResult.Cancel;
                                }
                                else //Invalid Number
                                {
                                    feedbackLbl.ForeColor = Color.Red;
                                    feedbackLbl.Text = "Number must be an integer";
                                }
                            }
                            else //Invalid Volume
                            {
                                feedbackLbl.ForeColor = Color.Red;
                                feedbackLbl.Text = "Volume must be an integer";
                            }
                }
                else //Invalid Loan Period
                {
                    feedbackLbl.ForeColor = Color.Red;
                    feedbackLbl.Text = "Loan Period must be an integer";
                }
            }
            else //Invalid Copyright
            {
                feedbackLbl.ForeColor = Color.Red;
                feedbackLbl.Text = "Copyright must be an integer";
            }
        }

        // Precondition:  User has selected Movie as the library item type and has entered info in all fields
        // Postcondition: A new library item of type LibraryMovie is added to the library with user input
        private void ParseMovie()
        {
            string movieTitle = titleMovieTxt.Text; //string variable for holding the movie title
            string moviePublisher = publisherMovieTxt.Text; //string variable for holding the movie publisher
            string movieCR = crMovieTxt.Text; //string variable for holding the movie copyright year
            string movieLoan = loanMovieTxt.Text; //string variable for holding the movie loan period
            string movieCallNum = callNumMovieTxt.Text; //string variable for holding the movie call number
            string movieDuration = durationTxtBox.Text; //string variable for holding the movie duration
            string movieDirector = directorTxtBox.Text; //string variable for holding the movie director
            string movieMedium = mediumTxtBox.Text.ToUpper(); //string variable for holding the movie medium
            string movieRating = ratingTxtBox.Text.ToUpper(); //string variable for holding the movie rating
            int movCR; //int variable for storing parsed copyright year
            int movLoan; //int variable for storing parsed loan period
            double movDuration; //int variable for storing parsed duration
            LibraryMovie.MediaType movMedia; //MediaType variable for storing the parsed media type
            LibraryMovie.MPAARatings movRating; //MediaType variable for storing the parsed rating

            if (int.TryParse(movieCR, out movCR))
            {
                if (int.TryParse(movieLoan, out movLoan))
                {
                    if (double.TryParse(movieDuration, out movDuration))
                    {
                        if (!String.IsNullOrEmpty(directorTxtBox.Text))
                        {
                            if (LibraryMediaItem.MediaType.TryParse(movieMedium, out movMedia))
                            {
                                if (LibraryMediaItem.MediaType.TryParse(movieRating, out movRating))
                                {
                                    Form1.lib.AddLibraryMovie(movieTitle, moviePublisher, movCR,
                                                            movLoan, movieCallNum, movDuration,
                                                            movieDirector, movMedia, movRating);
                                    //Close InsertPatron form
                                    this.DialogResult = DialogResult.Cancel;
                                }
                                else //Invalid Rating
                                {
                                    feedbackLbl.ForeColor = Color.Red;
                                    feedbackLbl.Text = "Rating must be G, PG, PG13, R, NC17, or U";
                                }
                            }
                            else //Invalid MediaType
                            {
                                feedbackLbl.ForeColor = Color.Red;
                                feedbackLbl.Text = "Media must be DVD, BLURAY, VHS, CD, SACD, VINYL";
                            }
                        }
                        else //Director empty
                        {
                            feedbackLbl.ForeColor = Color.Red;
                            feedbackLbl.Text = "Director cannot be empty";
                        }
                    }
                    else //Invalid Duration
                    {
                        feedbackLbl.ForeColor = Color.Red;
                        feedbackLbl.Text = "Duration must be a double";
                    }
                }
                else //Invalid Loan Period
                {
                    feedbackLbl.ForeColor = Color.Red;
                    feedbackLbl.Text = "Loan Period must be an integer";
                }
            }
            else //Invalid Copyright
            {
                feedbackLbl.ForeColor = Color.Red;
                feedbackLbl.Text = "Copyright must be an integer";
            }
        }

        // Precondition:  User has selected Music as the library item type and has entered info in all fields
        // Postcondition: A new library item of type LibraryMusic is added to the library with user input
        private void ParseMusic()
        {
            string musicTitle = titleMusicTxt.Text; //string variable for holding the music title
            string musicPublisher = publisherMusicTxt.Text; //string variable for holding the music publisher
            string musicCR = crMusicTxt.Text; //string variable for holding the music copyright year
            string musicLoan = loanMusicTxt.Text; //string variable for holding the music loan period
            string musicCallNum = callNumMusicTxt.Text; //string variable for holding the music call number
            string musicDuration = durationMusicTxt.Text; //string variable for holding the music duration
            string musicArtist = artistTxt.Text; //string variable for holding the music artist
            string musicMedium = mediumMusicTxt.Text.ToUpper(); //string variable for holding the music medium
            string musicTracks = numTracksTxt.Text.ToUpper(); //string variable for holding the music rating
            int musCR; //int variable for storing parsed copyright year
            int musLoan; //int variable for storing parsed loan period
            int numTracks; //int variable for storing parsed number of tracks
            double musDuration; //int variable for storing parsed duration
            LibraryMediaItem.MediaType musMedia; //MediaType variable for storing the parsed media type

            if (int.TryParse(musicCR, out musCR))
            {
                if (int.TryParse(musicLoan, out musLoan))
                {
                    if (double.TryParse(musicDuration, out musDuration))
                    {
                        if (!String.IsNullOrEmpty(artistTxt.Text))
                        {
                            if (LibraryMediaItem.MediaType.TryParse(musicMedium, out musMedia))
                            {
                                if (int.TryParse(musicTracks, out numTracks))
                                {
                                    Form1.lib.AddLibraryMusic(musicTitle, musicPublisher, musCR,
                                                            musLoan, musicCallNum, musDuration,
                                                            musicArtist, musMedia, numTracks);
                                    //Close InsertPatron form
                                    this.DialogResult = DialogResult.Cancel;
                                }
                                else //Invalid Track Count
                                {
                                    feedbackLbl.ForeColor = Color.Red;
                                    feedbackLbl.Text = "Track Count must be an integer";
                                }
                            }
                            else //Invalid MediaType
                            {
                                feedbackLbl.ForeColor = Color.Red;
                                feedbackLbl.Text = "Media must be CD, SACD, VINYL";
                            }
                        }
                        else //Artist empty
                        {
                            feedbackLbl.ForeColor = Color.Red;
                            feedbackLbl.Text = "Artist cannot be empty";
                        }
                    }
                    else //Invalid Duration
                    {
                        feedbackLbl.ForeColor = Color.Red;
                        feedbackLbl.Text = "Duration must be a double";
                    }
                }
                else //Invalid Loan Period
                {
                    feedbackLbl.ForeColor = Color.Red;
                    feedbackLbl.Text = "Loan Period must be an integer";
                }
            }
            else //Invalid Copyright
            {
                feedbackLbl.ForeColor = Color.Red;
                feedbackLbl.Text = "Copyright must be an integer";
            }
        }
    }
}
