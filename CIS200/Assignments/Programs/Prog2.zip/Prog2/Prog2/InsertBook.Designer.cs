﻿namespace LibraryItems
{
    partial class InsertBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLbl = new System.Windows.Forms.Label();
            this.publisherLbl = new System.Windows.Forms.Label();
            this.copyrightYrLbl = new System.Windows.Forms.Label();
            this.loanPeriodLbl = new System.Windows.Forms.Label();
            this.callNumLbl = new System.Windows.Forms.Label();
            this.authorLbl = new System.Windows.Forms.Label();
            this.titleTxtBox = new System.Windows.Forms.TextBox();
            this.publisherTxtBox = new System.Windows.Forms.TextBox();
            this.crYrTxtBox = new System.Windows.Forms.TextBox();
            this.loanPeriodTxtBox = new System.Windows.Forms.TextBox();
            this.callNumTxtBox = new System.Windows.Forms.TextBox();
            this.authorTxtBox = new System.Windows.Forms.TextBox();
            this.addBookBtn = new System.Windows.Forms.Button();
            this.chooseItemLbl = new System.Windows.Forms.Label();
            this.chooseItemCombo = new System.Windows.Forms.ComboBox();
            this.bookGroupBox = new System.Windows.Forms.GroupBox();
            this.movieGroupBox = new System.Windows.Forms.GroupBox();
            this.ratingTxtBox = new System.Windows.Forms.TextBox();
            this.ratingLbl = new System.Windows.Forms.Label();
            this.mediumTxtBox = new System.Windows.Forms.TextBox();
            this.mediumLbl = new System.Windows.Forms.Label();
            this.directorTxtBox = new System.Windows.Forms.TextBox();
            this.directorLbl = new System.Windows.Forms.Label();
            this.titleMovieLbl = new System.Windows.Forms.Label();
            this.publisherMovieLbl = new System.Windows.Forms.Label();
            this.crMovieLbl = new System.Windows.Forms.Label();
            this.loanMovieLbl = new System.Windows.Forms.Label();
            this.durationTxtBox = new System.Windows.Forms.TextBox();
            this.callNumMovieLbl = new System.Windows.Forms.Label();
            this.callNumMovieTxt = new System.Windows.Forms.TextBox();
            this.durationLbl = new System.Windows.Forms.Label();
            this.loanMovieTxt = new System.Windows.Forms.TextBox();
            this.titleMovieTxt = new System.Windows.Forms.TextBox();
            this.crMovieTxt = new System.Windows.Forms.TextBox();
            this.publisherMovieTxt = new System.Windows.Forms.TextBox();
            this.musicGroupBox = new System.Windows.Forms.GroupBox();
            this.numTracksTxt = new System.Windows.Forms.TextBox();
            this.trackCtLbl = new System.Windows.Forms.Label();
            this.mediumMusicTxt = new System.Windows.Forms.TextBox();
            this.mediumMusicLbl = new System.Windows.Forms.Label();
            this.artistTxt = new System.Windows.Forms.TextBox();
            this.artistLbl = new System.Windows.Forms.Label();
            this.titleMusicLbl = new System.Windows.Forms.Label();
            this.publisherMusicLbl = new System.Windows.Forms.Label();
            this.crMusicLbl = new System.Windows.Forms.Label();
            this.loanMusicLbl = new System.Windows.Forms.Label();
            this.durationMusicTxt = new System.Windows.Forms.TextBox();
            this.callNumMusicLbl = new System.Windows.Forms.Label();
            this.callNumMusicTxt = new System.Windows.Forms.TextBox();
            this.durationMusicLbl = new System.Windows.Forms.Label();
            this.loanMusicTxt = new System.Windows.Forms.TextBox();
            this.titleMusicTxt = new System.Windows.Forms.TextBox();
            this.crMusicTxt = new System.Windows.Forms.TextBox();
            this.publisherMusicTxt = new System.Windows.Forms.TextBox();
            this.journalGroupBox = new System.Windows.Forms.GroupBox();
            this.editorTxtBox = new System.Windows.Forms.TextBox();
            this.editorLbl = new System.Windows.Forms.Label();
            this.disciplineTxtBox = new System.Windows.Forms.TextBox();
            this.disciplineLbl = new System.Windows.Forms.Label();
            this.numberTxtBox = new System.Windows.Forms.TextBox();
            this.numberLbl = new System.Windows.Forms.Label();
            this.titleJournalLbl = new System.Windows.Forms.Label();
            this.publisherJournalLbl = new System.Windows.Forms.Label();
            this.crJournalLbl = new System.Windows.Forms.Label();
            this.loanJournalLbl = new System.Windows.Forms.Label();
            this.volumeTxtBox = new System.Windows.Forms.TextBox();
            this.callNumJournalLbl = new System.Windows.Forms.Label();
            this.callNumJournalTxt = new System.Windows.Forms.TextBox();
            this.volumeLbl = new System.Windows.Forms.Label();
            this.loanJournalTxt = new System.Windows.Forms.TextBox();
            this.titleJournalTxt = new System.Windows.Forms.TextBox();
            this.crJournalTxt = new System.Windows.Forms.TextBox();
            this.publisherJournalTxt = new System.Windows.Forms.TextBox();
            this.magazineGroupBox = new System.Windows.Forms.GroupBox();
            this.numberMagTxt = new System.Windows.Forms.TextBox();
            this.numberMagLbl = new System.Windows.Forms.Label();
            this.titleMagazineLbl = new System.Windows.Forms.Label();
            this.publisherMagLbl = new System.Windows.Forms.Label();
            this.crMagazineLbl = new System.Windows.Forms.Label();
            this.loanMagLbl = new System.Windows.Forms.Label();
            this.volumeMagTxt = new System.Windows.Forms.TextBox();
            this.callNumMagLbl = new System.Windows.Forms.Label();
            this.callNumMagTxt = new System.Windows.Forms.TextBox();
            this.volumeMagLbl = new System.Windows.Forms.Label();
            this.loanMagTxt = new System.Windows.Forms.TextBox();
            this.titleMagazineTxt = new System.Windows.Forms.TextBox();
            this.crMagazineTxt = new System.Windows.Forms.TextBox();
            this.publisherMagTxt = new System.Windows.Forms.TextBox();
            this.feedbackLbl = new System.Windows.Forms.Label();
            this.bookGroupBox.SuspendLayout();
            this.movieGroupBox.SuspendLayout();
            this.musicGroupBox.SuspendLayout();
            this.journalGroupBox.SuspendLayout();
            this.magazineGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Location = new System.Drawing.Point(51, 20);
            this.titleLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(39, 17);
            this.titleLbl.TabIndex = 0;
            this.titleLbl.Text = "Title:";
            // 
            // publisherLbl
            // 
            this.publisherLbl.AutoSize = true;
            this.publisherLbl.Location = new System.Drawing.Point(51, 57);
            this.publisherLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.publisherLbl.Name = "publisherLbl";
            this.publisherLbl.Size = new System.Drawing.Size(71, 17);
            this.publisherLbl.TabIndex = 1;
            this.publisherLbl.Text = "Publisher:";
            // 
            // copyrightYrLbl
            // 
            this.copyrightYrLbl.AutoSize = true;
            this.copyrightYrLbl.Location = new System.Drawing.Point(51, 94);
            this.copyrightYrLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.copyrightYrLbl.Name = "copyrightYrLbl";
            this.copyrightYrLbl.Size = new System.Drawing.Size(106, 17);
            this.copyrightYrLbl.TabIndex = 2;
            this.copyrightYrLbl.Text = "Copyright Year:";
            // 
            // loanPeriodLbl
            // 
            this.loanPeriodLbl.AutoSize = true;
            this.loanPeriodLbl.Location = new System.Drawing.Point(51, 130);
            this.loanPeriodLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.loanPeriodLbl.Name = "loanPeriodLbl";
            this.loanPeriodLbl.Size = new System.Drawing.Size(89, 17);
            this.loanPeriodLbl.TabIndex = 3;
            this.loanPeriodLbl.Text = "Loan Period:";
            // 
            // callNumLbl
            // 
            this.callNumLbl.AutoSize = true;
            this.callNumLbl.Location = new System.Drawing.Point(51, 167);
            this.callNumLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.callNumLbl.Name = "callNumLbl";
            this.callNumLbl.Size = new System.Drawing.Size(89, 17);
            this.callNumLbl.TabIndex = 4;
            this.callNumLbl.Text = "Call Number:";
            // 
            // authorLbl
            // 
            this.authorLbl.AutoSize = true;
            this.authorLbl.Location = new System.Drawing.Point(51, 204);
            this.authorLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.authorLbl.Name = "authorLbl";
            this.authorLbl.Size = new System.Drawing.Size(54, 17);
            this.authorLbl.TabIndex = 5;
            this.authorLbl.Text = "Author:";
            // 
            // titleTxtBox
            // 
            this.titleTxtBox.Location = new System.Drawing.Point(164, 16);
            this.titleTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.titleTxtBox.Name = "titleTxtBox";
            this.titleTxtBox.Size = new System.Drawing.Size(132, 22);
            this.titleTxtBox.TabIndex = 6;
            // 
            // publisherTxtBox
            // 
            this.publisherTxtBox.Location = new System.Drawing.Point(164, 53);
            this.publisherTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.publisherTxtBox.Name = "publisherTxtBox";
            this.publisherTxtBox.Size = new System.Drawing.Size(132, 22);
            this.publisherTxtBox.TabIndex = 7;
            // 
            // crYrTxtBox
            // 
            this.crYrTxtBox.Location = new System.Drawing.Point(164, 90);
            this.crYrTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.crYrTxtBox.Name = "crYrTxtBox";
            this.crYrTxtBox.Size = new System.Drawing.Size(132, 22);
            this.crYrTxtBox.TabIndex = 8;
            // 
            // loanPeriodTxtBox
            // 
            this.loanPeriodTxtBox.Location = new System.Drawing.Point(164, 127);
            this.loanPeriodTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loanPeriodTxtBox.Name = "loanPeriodTxtBox";
            this.loanPeriodTxtBox.Size = new System.Drawing.Size(132, 22);
            this.loanPeriodTxtBox.TabIndex = 9;
            // 
            // callNumTxtBox
            // 
            this.callNumTxtBox.Location = new System.Drawing.Point(164, 164);
            this.callNumTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.callNumTxtBox.Name = "callNumTxtBox";
            this.callNumTxtBox.Size = new System.Drawing.Size(132, 22);
            this.callNumTxtBox.TabIndex = 10;
            // 
            // authorTxtBox
            // 
            this.authorTxtBox.Location = new System.Drawing.Point(164, 201);
            this.authorTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.authorTxtBox.Name = "authorTxtBox";
            this.authorTxtBox.Size = new System.Drawing.Size(132, 22);
            this.authorTxtBox.TabIndex = 11;
            // 
            // addBookBtn
            // 
            this.addBookBtn.Location = new System.Drawing.Point(243, 414);
            this.addBookBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.addBookBtn.Name = "addBookBtn";
            this.addBookBtn.Size = new System.Drawing.Size(100, 28);
            this.addBookBtn.TabIndex = 12;
            this.addBookBtn.Text = "Save";
            this.addBookBtn.UseVisualStyleBackColor = true;
            this.addBookBtn.Click += new System.EventHandler(this.addBookBtn_Click);
            // 
            // chooseItemLbl
            // 
            this.chooseItemLbl.AutoSize = true;
            this.chooseItemLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseItemLbl.Location = new System.Drawing.Point(21, 11);
            this.chooseItemLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.chooseItemLbl.Name = "chooseItemLbl";
            this.chooseItemLbl.Size = new System.Drawing.Size(143, 17);
            this.chooseItemLbl.TabIndex = 13;
            this.chooseItemLbl.Text = "Choose Item Type:";
            // 
            // chooseItemCombo
            // 
            this.chooseItemCombo.FormattingEnabled = true;
            this.chooseItemCombo.Location = new System.Drawing.Point(181, 11);
            this.chooseItemCombo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chooseItemCombo.Name = "chooseItemCombo";
            this.chooseItemCombo.Size = new System.Drawing.Size(160, 24);
            this.chooseItemCombo.TabIndex = 14;
            this.chooseItemCombo.SelectedIndexChanged += new System.EventHandler(this.chooseItemCombo_SelectedIndexChanged);
            // 
            // bookGroupBox
            // 
            this.bookGroupBox.Controls.Add(this.titleLbl);
            this.bookGroupBox.Controls.Add(this.publisherLbl);
            this.bookGroupBox.Controls.Add(this.copyrightYrLbl);
            this.bookGroupBox.Controls.Add(this.loanPeriodLbl);
            this.bookGroupBox.Controls.Add(this.authorTxtBox);
            this.bookGroupBox.Controls.Add(this.callNumLbl);
            this.bookGroupBox.Controls.Add(this.callNumTxtBox);
            this.bookGroupBox.Controls.Add(this.authorLbl);
            this.bookGroupBox.Controls.Add(this.loanPeriodTxtBox);
            this.bookGroupBox.Controls.Add(this.titleTxtBox);
            this.bookGroupBox.Controls.Add(this.crYrTxtBox);
            this.bookGroupBox.Controls.Add(this.publisherTxtBox);
            this.bookGroupBox.Location = new System.Drawing.Point(25, 48);
            this.bookGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bookGroupBox.Name = "bookGroupBox";
            this.bookGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bookGroupBox.Size = new System.Drawing.Size(317, 238);
            this.bookGroupBox.TabIndex = 15;
            this.bookGroupBox.TabStop = false;
            this.bookGroupBox.Text = "Book";
            // 
            // movieGroupBox
            // 
            this.movieGroupBox.Controls.Add(this.ratingTxtBox);
            this.movieGroupBox.Controls.Add(this.ratingLbl);
            this.movieGroupBox.Controls.Add(this.mediumTxtBox);
            this.movieGroupBox.Controls.Add(this.mediumLbl);
            this.movieGroupBox.Controls.Add(this.directorTxtBox);
            this.movieGroupBox.Controls.Add(this.directorLbl);
            this.movieGroupBox.Controls.Add(this.titleMovieLbl);
            this.movieGroupBox.Controls.Add(this.publisherMovieLbl);
            this.movieGroupBox.Controls.Add(this.crMovieLbl);
            this.movieGroupBox.Controls.Add(this.loanMovieLbl);
            this.movieGroupBox.Controls.Add(this.durationTxtBox);
            this.movieGroupBox.Controls.Add(this.callNumMovieLbl);
            this.movieGroupBox.Controls.Add(this.callNumMovieTxt);
            this.movieGroupBox.Controls.Add(this.durationLbl);
            this.movieGroupBox.Controls.Add(this.loanMovieTxt);
            this.movieGroupBox.Controls.Add(this.titleMovieTxt);
            this.movieGroupBox.Controls.Add(this.crMovieTxt);
            this.movieGroupBox.Controls.Add(this.publisherMovieTxt);
            this.movieGroupBox.Location = new System.Drawing.Point(25, 48);
            this.movieGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.movieGroupBox.Name = "movieGroupBox";
            this.movieGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.movieGroupBox.Size = new System.Drawing.Size(317, 330);
            this.movieGroupBox.TabIndex = 16;
            this.movieGroupBox.TabStop = false;
            this.movieGroupBox.Text = "Movie";
            this.movieGroupBox.Visible = false;
            // 
            // ratingTxtBox
            // 
            this.ratingTxtBox.Location = new System.Drawing.Point(164, 292);
            this.ratingTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ratingTxtBox.Name = "ratingTxtBox";
            this.ratingTxtBox.Size = new System.Drawing.Size(132, 22);
            this.ratingTxtBox.TabIndex = 17;
            // 
            // ratingLbl
            // 
            this.ratingLbl.AutoSize = true;
            this.ratingLbl.Location = new System.Drawing.Point(55, 295);
            this.ratingLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ratingLbl.Name = "ratingLbl";
            this.ratingLbl.Size = new System.Drawing.Size(53, 17);
            this.ratingLbl.TabIndex = 16;
            this.ratingLbl.Text = "Rating:";
            // 
            // mediumTxtBox
            // 
            this.mediumTxtBox.Location = new System.Drawing.Point(164, 257);
            this.mediumTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mediumTxtBox.Name = "mediumTxtBox";
            this.mediumTxtBox.Size = new System.Drawing.Size(132, 22);
            this.mediumTxtBox.TabIndex = 15;
            // 
            // mediumLbl
            // 
            this.mediumLbl.AutoSize = true;
            this.mediumLbl.Location = new System.Drawing.Point(51, 261);
            this.mediumLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.mediumLbl.Name = "mediumLbl";
            this.mediumLbl.Size = new System.Drawing.Size(61, 17);
            this.mediumLbl.TabIndex = 14;
            this.mediumLbl.Text = "Medium:";
            // 
            // directorTxtBox
            // 
            this.directorTxtBox.Location = new System.Drawing.Point(164, 223);
            this.directorTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.directorTxtBox.Name = "directorTxtBox";
            this.directorTxtBox.Size = new System.Drawing.Size(132, 22);
            this.directorTxtBox.TabIndex = 13;
            // 
            // directorLbl
            // 
            this.directorLbl.AutoSize = true;
            this.directorLbl.Location = new System.Drawing.Point(51, 226);
            this.directorLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.directorLbl.Name = "directorLbl";
            this.directorLbl.Size = new System.Drawing.Size(62, 17);
            this.directorLbl.TabIndex = 12;
            this.directorLbl.Text = "Director:";
            // 
            // titleMovieLbl
            // 
            this.titleMovieLbl.AutoSize = true;
            this.titleMovieLbl.Location = new System.Drawing.Point(51, 20);
            this.titleMovieLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titleMovieLbl.Name = "titleMovieLbl";
            this.titleMovieLbl.Size = new System.Drawing.Size(39, 17);
            this.titleMovieLbl.TabIndex = 0;
            this.titleMovieLbl.Text = "Title:";
            // 
            // publisherMovieLbl
            // 
            this.publisherMovieLbl.AutoSize = true;
            this.publisherMovieLbl.Location = new System.Drawing.Point(51, 54);
            this.publisherMovieLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.publisherMovieLbl.Name = "publisherMovieLbl";
            this.publisherMovieLbl.Size = new System.Drawing.Size(71, 17);
            this.publisherMovieLbl.TabIndex = 1;
            this.publisherMovieLbl.Text = "Publisher:";
            // 
            // crMovieLbl
            // 
            this.crMovieLbl.AutoSize = true;
            this.crMovieLbl.Location = new System.Drawing.Point(51, 89);
            this.crMovieLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.crMovieLbl.Name = "crMovieLbl";
            this.crMovieLbl.Size = new System.Drawing.Size(106, 17);
            this.crMovieLbl.TabIndex = 2;
            this.crMovieLbl.Text = "Copyright Year:";
            // 
            // loanMovieLbl
            // 
            this.loanMovieLbl.AutoSize = true;
            this.loanMovieLbl.Location = new System.Drawing.Point(51, 123);
            this.loanMovieLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.loanMovieLbl.Name = "loanMovieLbl";
            this.loanMovieLbl.Size = new System.Drawing.Size(89, 17);
            this.loanMovieLbl.TabIndex = 3;
            this.loanMovieLbl.Text = "Loan Period:";
            // 
            // durationTxtBox
            // 
            this.durationTxtBox.Location = new System.Drawing.Point(164, 188);
            this.durationTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.durationTxtBox.Name = "durationTxtBox";
            this.durationTxtBox.Size = new System.Drawing.Size(132, 22);
            this.durationTxtBox.TabIndex = 11;
            // 
            // callNumMovieLbl
            // 
            this.callNumMovieLbl.AutoSize = true;
            this.callNumMovieLbl.Location = new System.Drawing.Point(51, 158);
            this.callNumMovieLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.callNumMovieLbl.Name = "callNumMovieLbl";
            this.callNumMovieLbl.Size = new System.Drawing.Size(89, 17);
            this.callNumMovieLbl.TabIndex = 4;
            this.callNumMovieLbl.Text = "Call Number:";
            // 
            // callNumMovieTxt
            // 
            this.callNumMovieTxt.Location = new System.Drawing.Point(164, 154);
            this.callNumMovieTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.callNumMovieTxt.Name = "callNumMovieTxt";
            this.callNumMovieTxt.Size = new System.Drawing.Size(132, 22);
            this.callNumMovieTxt.TabIndex = 10;
            // 
            // durationLbl
            // 
            this.durationLbl.AutoSize = true;
            this.durationLbl.Location = new System.Drawing.Point(51, 192);
            this.durationLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.durationLbl.Name = "durationLbl";
            this.durationLbl.Size = new System.Drawing.Size(66, 17);
            this.durationLbl.TabIndex = 5;
            this.durationLbl.Text = "Duration:";
            // 
            // loanMovieTxt
            // 
            this.loanMovieTxt.Location = new System.Drawing.Point(164, 119);
            this.loanMovieTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loanMovieTxt.Name = "loanMovieTxt";
            this.loanMovieTxt.Size = new System.Drawing.Size(132, 22);
            this.loanMovieTxt.TabIndex = 9;
            // 
            // titleMovieTxt
            // 
            this.titleMovieTxt.Location = new System.Drawing.Point(164, 16);
            this.titleMovieTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.titleMovieTxt.Name = "titleMovieTxt";
            this.titleMovieTxt.Size = new System.Drawing.Size(132, 22);
            this.titleMovieTxt.TabIndex = 6;
            // 
            // crMovieTxt
            // 
            this.crMovieTxt.Location = new System.Drawing.Point(164, 85);
            this.crMovieTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.crMovieTxt.Name = "crMovieTxt";
            this.crMovieTxt.Size = new System.Drawing.Size(132, 22);
            this.crMovieTxt.TabIndex = 8;
            // 
            // publisherMovieTxt
            // 
            this.publisherMovieTxt.Location = new System.Drawing.Point(164, 50);
            this.publisherMovieTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.publisherMovieTxt.Name = "publisherMovieTxt";
            this.publisherMovieTxt.Size = new System.Drawing.Size(132, 22);
            this.publisherMovieTxt.TabIndex = 7;
            // 
            // musicGroupBox
            // 
            this.musicGroupBox.Controls.Add(this.numTracksTxt);
            this.musicGroupBox.Controls.Add(this.trackCtLbl);
            this.musicGroupBox.Controls.Add(this.mediumMusicTxt);
            this.musicGroupBox.Controls.Add(this.mediumMusicLbl);
            this.musicGroupBox.Controls.Add(this.artistTxt);
            this.musicGroupBox.Controls.Add(this.artistLbl);
            this.musicGroupBox.Controls.Add(this.titleMusicLbl);
            this.musicGroupBox.Controls.Add(this.publisherMusicLbl);
            this.musicGroupBox.Controls.Add(this.crMusicLbl);
            this.musicGroupBox.Controls.Add(this.loanMusicLbl);
            this.musicGroupBox.Controls.Add(this.durationMusicTxt);
            this.musicGroupBox.Controls.Add(this.callNumMusicLbl);
            this.musicGroupBox.Controls.Add(this.callNumMusicTxt);
            this.musicGroupBox.Controls.Add(this.durationMusicLbl);
            this.musicGroupBox.Controls.Add(this.loanMusicTxt);
            this.musicGroupBox.Controls.Add(this.titleMusicTxt);
            this.musicGroupBox.Controls.Add(this.crMusicTxt);
            this.musicGroupBox.Controls.Add(this.publisherMusicTxt);
            this.musicGroupBox.Location = new System.Drawing.Point(25, 48);
            this.musicGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.musicGroupBox.Name = "musicGroupBox";
            this.musicGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.musicGroupBox.Size = new System.Drawing.Size(317, 330);
            this.musicGroupBox.TabIndex = 17;
            this.musicGroupBox.TabStop = false;
            this.musicGroupBox.Text = "Music";
            this.musicGroupBox.Visible = false;
            // 
            // numTracksTxt
            // 
            this.numTracksTxt.Location = new System.Drawing.Point(164, 292);
            this.numTracksTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numTracksTxt.Name = "numTracksTxt";
            this.numTracksTxt.Size = new System.Drawing.Size(132, 22);
            this.numTracksTxt.TabIndex = 17;
            // 
            // trackCtLbl
            // 
            this.trackCtLbl.AutoSize = true;
            this.trackCtLbl.Location = new System.Drawing.Point(51, 295);
            this.trackCtLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.trackCtLbl.Name = "trackCtLbl";
            this.trackCtLbl.Size = new System.Drawing.Size(89, 17);
            this.trackCtLbl.TabIndex = 16;
            this.trackCtLbl.Text = "Track Count:";
            // 
            // mediumMusicTxt
            // 
            this.mediumMusicTxt.Location = new System.Drawing.Point(164, 257);
            this.mediumMusicTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mediumMusicTxt.Name = "mediumMusicTxt";
            this.mediumMusicTxt.Size = new System.Drawing.Size(132, 22);
            this.mediumMusicTxt.TabIndex = 15;
            // 
            // mediumMusicLbl
            // 
            this.mediumMusicLbl.AutoSize = true;
            this.mediumMusicLbl.Location = new System.Drawing.Point(51, 261);
            this.mediumMusicLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.mediumMusicLbl.Name = "mediumMusicLbl";
            this.mediumMusicLbl.Size = new System.Drawing.Size(61, 17);
            this.mediumMusicLbl.TabIndex = 14;
            this.mediumMusicLbl.Text = "Medium:";
            // 
            // artistTxt
            // 
            this.artistTxt.Location = new System.Drawing.Point(164, 223);
            this.artistTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.artistTxt.Name = "artistTxt";
            this.artistTxt.Size = new System.Drawing.Size(132, 22);
            this.artistTxt.TabIndex = 13;
            // 
            // artistLbl
            // 
            this.artistLbl.AutoSize = true;
            this.artistLbl.Location = new System.Drawing.Point(51, 226);
            this.artistLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.artistLbl.Name = "artistLbl";
            this.artistLbl.Size = new System.Drawing.Size(44, 17);
            this.artistLbl.TabIndex = 12;
            this.artistLbl.Text = "Artist:";
            // 
            // titleMusicLbl
            // 
            this.titleMusicLbl.AutoSize = true;
            this.titleMusicLbl.Location = new System.Drawing.Point(51, 20);
            this.titleMusicLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titleMusicLbl.Name = "titleMusicLbl";
            this.titleMusicLbl.Size = new System.Drawing.Size(39, 17);
            this.titleMusicLbl.TabIndex = 0;
            this.titleMusicLbl.Text = "Title:";
            // 
            // publisherMusicLbl
            // 
            this.publisherMusicLbl.AutoSize = true;
            this.publisherMusicLbl.Location = new System.Drawing.Point(51, 54);
            this.publisherMusicLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.publisherMusicLbl.Name = "publisherMusicLbl";
            this.publisherMusicLbl.Size = new System.Drawing.Size(71, 17);
            this.publisherMusicLbl.TabIndex = 1;
            this.publisherMusicLbl.Text = "Publisher:";
            // 
            // crMusicLbl
            // 
            this.crMusicLbl.AutoSize = true;
            this.crMusicLbl.Location = new System.Drawing.Point(51, 89);
            this.crMusicLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.crMusicLbl.Name = "crMusicLbl";
            this.crMusicLbl.Size = new System.Drawing.Size(106, 17);
            this.crMusicLbl.TabIndex = 2;
            this.crMusicLbl.Text = "Copyright Year:";
            // 
            // loanMusicLbl
            // 
            this.loanMusicLbl.AutoSize = true;
            this.loanMusicLbl.Location = new System.Drawing.Point(51, 123);
            this.loanMusicLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.loanMusicLbl.Name = "loanMusicLbl";
            this.loanMusicLbl.Size = new System.Drawing.Size(89, 17);
            this.loanMusicLbl.TabIndex = 3;
            this.loanMusicLbl.Text = "Loan Period:";
            // 
            // durationMusicTxt
            // 
            this.durationMusicTxt.Location = new System.Drawing.Point(164, 188);
            this.durationMusicTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.durationMusicTxt.Name = "durationMusicTxt";
            this.durationMusicTxt.Size = new System.Drawing.Size(132, 22);
            this.durationMusicTxt.TabIndex = 11;
            // 
            // callNumMusicLbl
            // 
            this.callNumMusicLbl.AutoSize = true;
            this.callNumMusicLbl.Location = new System.Drawing.Point(51, 158);
            this.callNumMusicLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.callNumMusicLbl.Name = "callNumMusicLbl";
            this.callNumMusicLbl.Size = new System.Drawing.Size(89, 17);
            this.callNumMusicLbl.TabIndex = 4;
            this.callNumMusicLbl.Text = "Call Number:";
            // 
            // callNumMusicTxt
            // 
            this.callNumMusicTxt.Location = new System.Drawing.Point(164, 154);
            this.callNumMusicTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.callNumMusicTxt.Name = "callNumMusicTxt";
            this.callNumMusicTxt.Size = new System.Drawing.Size(132, 22);
            this.callNumMusicTxt.TabIndex = 10;
            // 
            // durationMusicLbl
            // 
            this.durationMusicLbl.AutoSize = true;
            this.durationMusicLbl.Location = new System.Drawing.Point(51, 192);
            this.durationMusicLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.durationMusicLbl.Name = "durationMusicLbl";
            this.durationMusicLbl.Size = new System.Drawing.Size(66, 17);
            this.durationMusicLbl.TabIndex = 5;
            this.durationMusicLbl.Text = "Duration:";
            // 
            // loanMusicTxt
            // 
            this.loanMusicTxt.Location = new System.Drawing.Point(164, 119);
            this.loanMusicTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loanMusicTxt.Name = "loanMusicTxt";
            this.loanMusicTxt.Size = new System.Drawing.Size(132, 22);
            this.loanMusicTxt.TabIndex = 9;
            // 
            // titleMusicTxt
            // 
            this.titleMusicTxt.Location = new System.Drawing.Point(164, 16);
            this.titleMusicTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.titleMusicTxt.Name = "titleMusicTxt";
            this.titleMusicTxt.Size = new System.Drawing.Size(132, 22);
            this.titleMusicTxt.TabIndex = 6;
            // 
            // crMusicTxt
            // 
            this.crMusicTxt.Location = new System.Drawing.Point(164, 85);
            this.crMusicTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.crMusicTxt.Name = "crMusicTxt";
            this.crMusicTxt.Size = new System.Drawing.Size(132, 22);
            this.crMusicTxt.TabIndex = 8;
            // 
            // publisherMusicTxt
            // 
            this.publisherMusicTxt.Location = new System.Drawing.Point(164, 50);
            this.publisherMusicTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.publisherMusicTxt.Name = "publisherMusicTxt";
            this.publisherMusicTxt.Size = new System.Drawing.Size(132, 22);
            this.publisherMusicTxt.TabIndex = 7;
            // 
            // journalGroupBox
            // 
            this.journalGroupBox.Controls.Add(this.editorTxtBox);
            this.journalGroupBox.Controls.Add(this.editorLbl);
            this.journalGroupBox.Controls.Add(this.disciplineTxtBox);
            this.journalGroupBox.Controls.Add(this.disciplineLbl);
            this.journalGroupBox.Controls.Add(this.numberTxtBox);
            this.journalGroupBox.Controls.Add(this.numberLbl);
            this.journalGroupBox.Controls.Add(this.titleJournalLbl);
            this.journalGroupBox.Controls.Add(this.publisherJournalLbl);
            this.journalGroupBox.Controls.Add(this.crJournalLbl);
            this.journalGroupBox.Controls.Add(this.loanJournalLbl);
            this.journalGroupBox.Controls.Add(this.volumeTxtBox);
            this.journalGroupBox.Controls.Add(this.callNumJournalLbl);
            this.journalGroupBox.Controls.Add(this.callNumJournalTxt);
            this.journalGroupBox.Controls.Add(this.volumeLbl);
            this.journalGroupBox.Controls.Add(this.loanJournalTxt);
            this.journalGroupBox.Controls.Add(this.titleJournalTxt);
            this.journalGroupBox.Controls.Add(this.crJournalTxt);
            this.journalGroupBox.Controls.Add(this.publisherJournalTxt);
            this.journalGroupBox.Location = new System.Drawing.Point(25, 48);
            this.journalGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.journalGroupBox.Name = "journalGroupBox";
            this.journalGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.journalGroupBox.Size = new System.Drawing.Size(317, 330);
            this.journalGroupBox.TabIndex = 18;
            this.journalGroupBox.TabStop = false;
            this.journalGroupBox.Text = "Journal";
            this.journalGroupBox.Visible = false;
            // 
            // editorTxtBox
            // 
            this.editorTxtBox.Location = new System.Drawing.Point(164, 292);
            this.editorTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editorTxtBox.Name = "editorTxtBox";
            this.editorTxtBox.Size = new System.Drawing.Size(132, 22);
            this.editorTxtBox.TabIndex = 17;
            // 
            // editorLbl
            // 
            this.editorLbl.AutoSize = true;
            this.editorLbl.Location = new System.Drawing.Point(51, 295);
            this.editorLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.editorLbl.Name = "editorLbl";
            this.editorLbl.Size = new System.Drawing.Size(49, 17);
            this.editorLbl.TabIndex = 16;
            this.editorLbl.Text = "Editor:";
            // 
            // disciplineTxtBox
            // 
            this.disciplineTxtBox.Location = new System.Drawing.Point(164, 257);
            this.disciplineTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.disciplineTxtBox.Name = "disciplineTxtBox";
            this.disciplineTxtBox.Size = new System.Drawing.Size(132, 22);
            this.disciplineTxtBox.TabIndex = 15;
            // 
            // disciplineLbl
            // 
            this.disciplineLbl.AutoSize = true;
            this.disciplineLbl.Location = new System.Drawing.Point(51, 261);
            this.disciplineLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.disciplineLbl.Name = "disciplineLbl";
            this.disciplineLbl.Size = new System.Drawing.Size(72, 17);
            this.disciplineLbl.TabIndex = 14;
            this.disciplineLbl.Text = "Discipline:";
            // 
            // numberTxtBox
            // 
            this.numberTxtBox.Location = new System.Drawing.Point(164, 223);
            this.numberTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numberTxtBox.Name = "numberTxtBox";
            this.numberTxtBox.Size = new System.Drawing.Size(132, 22);
            this.numberTxtBox.TabIndex = 13;
            // 
            // numberLbl
            // 
            this.numberLbl.AutoSize = true;
            this.numberLbl.Location = new System.Drawing.Point(51, 226);
            this.numberLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.numberLbl.Name = "numberLbl";
            this.numberLbl.Size = new System.Drawing.Size(62, 17);
            this.numberLbl.TabIndex = 12;
            this.numberLbl.Text = "Number:";
            // 
            // titleJournalLbl
            // 
            this.titleJournalLbl.AutoSize = true;
            this.titleJournalLbl.Location = new System.Drawing.Point(51, 20);
            this.titleJournalLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titleJournalLbl.Name = "titleJournalLbl";
            this.titleJournalLbl.Size = new System.Drawing.Size(39, 17);
            this.titleJournalLbl.TabIndex = 0;
            this.titleJournalLbl.Text = "Title:";
            // 
            // publisherJournalLbl
            // 
            this.publisherJournalLbl.AutoSize = true;
            this.publisherJournalLbl.Location = new System.Drawing.Point(51, 54);
            this.publisherJournalLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.publisherJournalLbl.Name = "publisherJournalLbl";
            this.publisherJournalLbl.Size = new System.Drawing.Size(71, 17);
            this.publisherJournalLbl.TabIndex = 1;
            this.publisherJournalLbl.Text = "Publisher:";
            // 
            // crJournalLbl
            // 
            this.crJournalLbl.AutoSize = true;
            this.crJournalLbl.Location = new System.Drawing.Point(51, 89);
            this.crJournalLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.crJournalLbl.Name = "crJournalLbl";
            this.crJournalLbl.Size = new System.Drawing.Size(106, 17);
            this.crJournalLbl.TabIndex = 2;
            this.crJournalLbl.Text = "Copyright Year:";
            // 
            // loanJournalLbl
            // 
            this.loanJournalLbl.AutoSize = true;
            this.loanJournalLbl.Location = new System.Drawing.Point(51, 123);
            this.loanJournalLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.loanJournalLbl.Name = "loanJournalLbl";
            this.loanJournalLbl.Size = new System.Drawing.Size(89, 17);
            this.loanJournalLbl.TabIndex = 3;
            this.loanJournalLbl.Text = "Loan Period:";
            // 
            // volumeTxtBox
            // 
            this.volumeTxtBox.Location = new System.Drawing.Point(164, 188);
            this.volumeTxtBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.volumeTxtBox.Name = "volumeTxtBox";
            this.volumeTxtBox.Size = new System.Drawing.Size(132, 22);
            this.volumeTxtBox.TabIndex = 11;
            // 
            // callNumJournalLbl
            // 
            this.callNumJournalLbl.AutoSize = true;
            this.callNumJournalLbl.Location = new System.Drawing.Point(51, 158);
            this.callNumJournalLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.callNumJournalLbl.Name = "callNumJournalLbl";
            this.callNumJournalLbl.Size = new System.Drawing.Size(89, 17);
            this.callNumJournalLbl.TabIndex = 4;
            this.callNumJournalLbl.Text = "Call Number:";
            // 
            // callNumJournalTxt
            // 
            this.callNumJournalTxt.Location = new System.Drawing.Point(164, 154);
            this.callNumJournalTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.callNumJournalTxt.Name = "callNumJournalTxt";
            this.callNumJournalTxt.Size = new System.Drawing.Size(132, 22);
            this.callNumJournalTxt.TabIndex = 10;
            // 
            // volumeLbl
            // 
            this.volumeLbl.AutoSize = true;
            this.volumeLbl.Location = new System.Drawing.Point(51, 192);
            this.volumeLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.volumeLbl.Name = "volumeLbl";
            this.volumeLbl.Size = new System.Drawing.Size(59, 17);
            this.volumeLbl.TabIndex = 5;
            this.volumeLbl.Text = "Volume:";
            // 
            // loanJournalTxt
            // 
            this.loanJournalTxt.Location = new System.Drawing.Point(164, 119);
            this.loanJournalTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loanJournalTxt.Name = "loanJournalTxt";
            this.loanJournalTxt.Size = new System.Drawing.Size(132, 22);
            this.loanJournalTxt.TabIndex = 9;
            // 
            // titleJournalTxt
            // 
            this.titleJournalTxt.Location = new System.Drawing.Point(164, 16);
            this.titleJournalTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.titleJournalTxt.Name = "titleJournalTxt";
            this.titleJournalTxt.Size = new System.Drawing.Size(132, 22);
            this.titleJournalTxt.TabIndex = 6;
            // 
            // crJournalTxt
            // 
            this.crJournalTxt.Location = new System.Drawing.Point(164, 85);
            this.crJournalTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.crJournalTxt.Name = "crJournalTxt";
            this.crJournalTxt.Size = new System.Drawing.Size(132, 22);
            this.crJournalTxt.TabIndex = 8;
            // 
            // publisherJournalTxt
            // 
            this.publisherJournalTxt.Location = new System.Drawing.Point(164, 50);
            this.publisherJournalTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.publisherJournalTxt.Name = "publisherJournalTxt";
            this.publisherJournalTxt.Size = new System.Drawing.Size(132, 22);
            this.publisherJournalTxt.TabIndex = 7;
            // 
            // magazineGroupBox
            // 
            this.magazineGroupBox.Controls.Add(this.numberMagTxt);
            this.magazineGroupBox.Controls.Add(this.numberMagLbl);
            this.magazineGroupBox.Controls.Add(this.titleMagazineLbl);
            this.magazineGroupBox.Controls.Add(this.publisherMagLbl);
            this.magazineGroupBox.Controls.Add(this.crMagazineLbl);
            this.magazineGroupBox.Controls.Add(this.loanMagLbl);
            this.magazineGroupBox.Controls.Add(this.volumeMagTxt);
            this.magazineGroupBox.Controls.Add(this.callNumMagLbl);
            this.magazineGroupBox.Controls.Add(this.callNumMagTxt);
            this.magazineGroupBox.Controls.Add(this.volumeMagLbl);
            this.magazineGroupBox.Controls.Add(this.loanMagTxt);
            this.magazineGroupBox.Controls.Add(this.titleMagazineTxt);
            this.magazineGroupBox.Controls.Add(this.crMagazineTxt);
            this.magazineGroupBox.Controls.Add(this.publisherMagTxt);
            this.magazineGroupBox.Location = new System.Drawing.Point(25, 48);
            this.magazineGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.magazineGroupBox.Name = "magazineGroupBox";
            this.magazineGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.magazineGroupBox.Size = new System.Drawing.Size(317, 260);
            this.magazineGroupBox.TabIndex = 19;
            this.magazineGroupBox.TabStop = false;
            this.magazineGroupBox.Text = "Magazine";
            this.magazineGroupBox.Visible = false;
            // 
            // numberMagTxt
            // 
            this.numberMagTxt.Location = new System.Drawing.Point(164, 223);
            this.numberMagTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numberMagTxt.Name = "numberMagTxt";
            this.numberMagTxt.Size = new System.Drawing.Size(132, 22);
            this.numberMagTxt.TabIndex = 13;
            // 
            // numberMagLbl
            // 
            this.numberMagLbl.AutoSize = true;
            this.numberMagLbl.Location = new System.Drawing.Point(51, 226);
            this.numberMagLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.numberMagLbl.Name = "numberMagLbl";
            this.numberMagLbl.Size = new System.Drawing.Size(62, 17);
            this.numberMagLbl.TabIndex = 12;
            this.numberMagLbl.Text = "Number:";
            // 
            // titleMagazineLbl
            // 
            this.titleMagazineLbl.AutoSize = true;
            this.titleMagazineLbl.Location = new System.Drawing.Point(51, 20);
            this.titleMagazineLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.titleMagazineLbl.Name = "titleMagazineLbl";
            this.titleMagazineLbl.Size = new System.Drawing.Size(39, 17);
            this.titleMagazineLbl.TabIndex = 0;
            this.titleMagazineLbl.Text = "Title:";
            // 
            // publisherMagLbl
            // 
            this.publisherMagLbl.AutoSize = true;
            this.publisherMagLbl.Location = new System.Drawing.Point(51, 54);
            this.publisherMagLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.publisherMagLbl.Name = "publisherMagLbl";
            this.publisherMagLbl.Size = new System.Drawing.Size(71, 17);
            this.publisherMagLbl.TabIndex = 1;
            this.publisherMagLbl.Text = "Publisher:";
            // 
            // crMagazineLbl
            // 
            this.crMagazineLbl.AutoSize = true;
            this.crMagazineLbl.Location = new System.Drawing.Point(51, 89);
            this.crMagazineLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.crMagazineLbl.Name = "crMagazineLbl";
            this.crMagazineLbl.Size = new System.Drawing.Size(106, 17);
            this.crMagazineLbl.TabIndex = 2;
            this.crMagazineLbl.Text = "Copyright Year:";
            // 
            // loanMagLbl
            // 
            this.loanMagLbl.AutoSize = true;
            this.loanMagLbl.Location = new System.Drawing.Point(51, 123);
            this.loanMagLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.loanMagLbl.Name = "loanMagLbl";
            this.loanMagLbl.Size = new System.Drawing.Size(89, 17);
            this.loanMagLbl.TabIndex = 3;
            this.loanMagLbl.Text = "Loan Period:";
            // 
            // volumeMagTxt
            // 
            this.volumeMagTxt.Location = new System.Drawing.Point(164, 188);
            this.volumeMagTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.volumeMagTxt.Name = "volumeMagTxt";
            this.volumeMagTxt.Size = new System.Drawing.Size(132, 22);
            this.volumeMagTxt.TabIndex = 11;
            // 
            // callNumMagLbl
            // 
            this.callNumMagLbl.AutoSize = true;
            this.callNumMagLbl.Location = new System.Drawing.Point(51, 158);
            this.callNumMagLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.callNumMagLbl.Name = "callNumMagLbl";
            this.callNumMagLbl.Size = new System.Drawing.Size(89, 17);
            this.callNumMagLbl.TabIndex = 4;
            this.callNumMagLbl.Text = "Call Number:";
            // 
            // callNumMagTxt
            // 
            this.callNumMagTxt.Location = new System.Drawing.Point(164, 154);
            this.callNumMagTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.callNumMagTxt.Name = "callNumMagTxt";
            this.callNumMagTxt.Size = new System.Drawing.Size(132, 22);
            this.callNumMagTxt.TabIndex = 10;
            // 
            // volumeMagLbl
            // 
            this.volumeMagLbl.AutoSize = true;
            this.volumeMagLbl.Location = new System.Drawing.Point(51, 192);
            this.volumeMagLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.volumeMagLbl.Name = "volumeMagLbl";
            this.volumeMagLbl.Size = new System.Drawing.Size(59, 17);
            this.volumeMagLbl.TabIndex = 5;
            this.volumeMagLbl.Text = "Volume:";
            // 
            // loanMagTxt
            // 
            this.loanMagTxt.Location = new System.Drawing.Point(164, 119);
            this.loanMagTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loanMagTxt.Name = "loanMagTxt";
            this.loanMagTxt.Size = new System.Drawing.Size(132, 22);
            this.loanMagTxt.TabIndex = 9;
            // 
            // titleMagazineTxt
            // 
            this.titleMagazineTxt.Location = new System.Drawing.Point(164, 16);
            this.titleMagazineTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.titleMagazineTxt.Name = "titleMagazineTxt";
            this.titleMagazineTxt.Size = new System.Drawing.Size(132, 22);
            this.titleMagazineTxt.TabIndex = 6;
            // 
            // crMagazineTxt
            // 
            this.crMagazineTxt.Location = new System.Drawing.Point(164, 85);
            this.crMagazineTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.crMagazineTxt.Name = "crMagazineTxt";
            this.crMagazineTxt.Size = new System.Drawing.Size(132, 22);
            this.crMagazineTxt.TabIndex = 8;
            // 
            // publisherMagTxt
            // 
            this.publisherMagTxt.Location = new System.Drawing.Point(164, 50);
            this.publisherMagTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.publisherMagTxt.Name = "publisherMagTxt";
            this.publisherMagTxt.Size = new System.Drawing.Size(132, 22);
            this.publisherMagTxt.TabIndex = 7;
            // 
            // feedbackLbl
            // 
            this.feedbackLbl.AutoSize = true;
            this.feedbackLbl.Location = new System.Drawing.Point(25, 386);
            this.feedbackLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.feedbackLbl.Name = "feedbackLbl";
            this.feedbackLbl.Size = new System.Drawing.Size(0, 17);
            this.feedbackLbl.TabIndex = 20;
            // 
            // InsertBook
            // 
            this.AcceptButton = this.addBookBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 457);
            this.Controls.Add(this.feedbackLbl);
            this.Controls.Add(this.magazineGroupBox);
            this.Controls.Add(this.journalGroupBox);
            this.Controls.Add(this.musicGroupBox);
            this.Controls.Add(this.movieGroupBox);
            this.Controls.Add(this.bookGroupBox);
            this.Controls.Add(this.chooseItemCombo);
            this.Controls.Add(this.chooseItemLbl);
            this.Controls.Add(this.addBookBtn);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "InsertBook";
            this.Text = "Insert Book";
            this.bookGroupBox.ResumeLayout(false);
            this.bookGroupBox.PerformLayout();
            this.movieGroupBox.ResumeLayout(false);
            this.movieGroupBox.PerformLayout();
            this.musicGroupBox.ResumeLayout(false);
            this.musicGroupBox.PerformLayout();
            this.journalGroupBox.ResumeLayout(false);
            this.journalGroupBox.PerformLayout();
            this.magazineGroupBox.ResumeLayout(false);
            this.magazineGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Label publisherLbl;
        private System.Windows.Forms.Label copyrightYrLbl;
        private System.Windows.Forms.Label callNumLbl;
        private System.Windows.Forms.Label authorLbl;
        private System.Windows.Forms.TextBox titleTxtBox;
        private System.Windows.Forms.TextBox publisherTxtBox;
        private System.Windows.Forms.TextBox crYrTxtBox;
        private System.Windows.Forms.TextBox loanPeriodTxtBox;
        private System.Windows.Forms.TextBox callNumTxtBox;
        private System.Windows.Forms.TextBox authorTxtBox;
        private System.Windows.Forms.Button addBookBtn;
        private System.Windows.Forms.Label loanPeriodLbl;
        private System.Windows.Forms.Label chooseItemLbl;
        private System.Windows.Forms.ComboBox chooseItemCombo;
        private System.Windows.Forms.GroupBox bookGroupBox;
        private System.Windows.Forms.GroupBox movieGroupBox;
        private System.Windows.Forms.Label titleMovieLbl;
        private System.Windows.Forms.Label publisherMovieLbl;
        private System.Windows.Forms.Label crMovieLbl;
        private System.Windows.Forms.Label loanMovieLbl;
        private System.Windows.Forms.TextBox durationTxtBox;
        private System.Windows.Forms.Label callNumMovieLbl;
        private System.Windows.Forms.TextBox callNumMovieTxt;
        private System.Windows.Forms.Label durationLbl;
        private System.Windows.Forms.TextBox loanMovieTxt;
        private System.Windows.Forms.TextBox titleMovieTxt;
        private System.Windows.Forms.TextBox crMovieTxt;
        private System.Windows.Forms.TextBox publisherMovieTxt;
        private System.Windows.Forms.Label directorLbl;
        private System.Windows.Forms.TextBox directorTxtBox;
        private System.Windows.Forms.TextBox mediumTxtBox;
        private System.Windows.Forms.Label mediumLbl;
        private System.Windows.Forms.TextBox ratingTxtBox;
        private System.Windows.Forms.Label ratingLbl;
        private System.Windows.Forms.GroupBox musicGroupBox;
        private System.Windows.Forms.TextBox numTracksTxt;
        private System.Windows.Forms.Label trackCtLbl;
        private System.Windows.Forms.TextBox mediumMusicTxt;
        private System.Windows.Forms.Label mediumMusicLbl;
        private System.Windows.Forms.TextBox artistTxt;
        private System.Windows.Forms.Label artistLbl;
        private System.Windows.Forms.Label titleMusicLbl;
        private System.Windows.Forms.Label publisherMusicLbl;
        private System.Windows.Forms.Label crMusicLbl;
        private System.Windows.Forms.Label loanMusicLbl;
        private System.Windows.Forms.TextBox durationMusicTxt;
        private System.Windows.Forms.Label callNumMusicLbl;
        private System.Windows.Forms.TextBox callNumMusicTxt;
        private System.Windows.Forms.Label durationMusicLbl;
        private System.Windows.Forms.TextBox loanMusicTxt;
        private System.Windows.Forms.TextBox titleMusicTxt;
        private System.Windows.Forms.TextBox crMusicTxt;
        private System.Windows.Forms.TextBox publisherMusicTxt;
        private System.Windows.Forms.GroupBox journalGroupBox;
        private System.Windows.Forms.TextBox editorTxtBox;
        private System.Windows.Forms.Label editorLbl;
        private System.Windows.Forms.TextBox disciplineTxtBox;
        private System.Windows.Forms.Label disciplineLbl;
        private System.Windows.Forms.TextBox numberTxtBox;
        private System.Windows.Forms.Label numberLbl;
        private System.Windows.Forms.Label titleJournalLbl;
        private System.Windows.Forms.Label publisherJournalLbl;
        private System.Windows.Forms.Label crJournalLbl;
        private System.Windows.Forms.Label loanJournalLbl;
        private System.Windows.Forms.TextBox volumeTxtBox;
        private System.Windows.Forms.Label callNumJournalLbl;
        private System.Windows.Forms.TextBox callNumJournalTxt;
        private System.Windows.Forms.Label volumeLbl;
        private System.Windows.Forms.TextBox loanJournalTxt;
        private System.Windows.Forms.TextBox titleJournalTxt;
        private System.Windows.Forms.TextBox crJournalTxt;
        private System.Windows.Forms.TextBox publisherJournalTxt;
        private System.Windows.Forms.GroupBox magazineGroupBox;
        private System.Windows.Forms.TextBox numberMagTxt;
        private System.Windows.Forms.Label numberMagLbl;
        private System.Windows.Forms.Label titleMagazineLbl;
        private System.Windows.Forms.Label publisherMagLbl;
        private System.Windows.Forms.Label crMagazineLbl;
        private System.Windows.Forms.Label loanMagLbl;
        private System.Windows.Forms.TextBox volumeMagTxt;
        private System.Windows.Forms.Label callNumMagLbl;
        private System.Windows.Forms.TextBox callNumMagTxt;
        private System.Windows.Forms.Label volumeMagLbl;
        private System.Windows.Forms.TextBox loanMagTxt;
        private System.Windows.Forms.TextBox titleMagazineTxt;
        private System.Windows.Forms.TextBox crMagazineTxt;
        private System.Windows.Forms.TextBox publisherMagTxt;
        private System.Windows.Forms.Label feedbackLbl;
    }
}