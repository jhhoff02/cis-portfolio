﻿namespace LibraryItems
{
    partial class ItemReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backReturnBtn = new System.Windows.Forms.Button();
            this.returnBtn = new System.Windows.Forms.Button();
            this.itemReturnLbl = new System.Windows.Forms.Label();
            this.itemsReturnCombo = new System.Windows.Forms.ComboBox();
            this.feedbackLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // backReturnBtn
            // 
            this.backReturnBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.backReturnBtn.Location = new System.Drawing.Point(137, 91);
            this.backReturnBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.backReturnBtn.Name = "backReturnBtn";
            this.backReturnBtn.Size = new System.Drawing.Size(100, 28);
            this.backReturnBtn.TabIndex = 11;
            this.backReturnBtn.Text = "Back";
            this.backReturnBtn.UseVisualStyleBackColor = true;
            this.backReturnBtn.Click += new System.EventHandler(this.backReturnBtn_Click);
            // 
            // returnBtn
            // 
            this.returnBtn.Location = new System.Drawing.Point(333, 91);
            this.returnBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.returnBtn.Name = "returnBtn";
            this.returnBtn.Size = new System.Drawing.Size(100, 28);
            this.returnBtn.TabIndex = 10;
            this.returnBtn.Text = "Return";
            this.returnBtn.UseVisualStyleBackColor = true;
            this.returnBtn.Click += new System.EventHandler(this.returnBtn_Click);
            // 
            // itemReturnLbl
            // 
            this.itemReturnLbl.AutoSize = true;
            this.itemReturnLbl.Location = new System.Drawing.Point(43, 38);
            this.itemReturnLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.itemReturnLbl.Name = "itemReturnLbl";
            this.itemReturnLbl.Size = new System.Drawing.Size(38, 17);
            this.itemReturnLbl.TabIndex = 7;
            this.itemReturnLbl.Text = "Item:";
            // 
            // itemsReturnCombo
            // 
            this.itemsReturnCombo.FormattingEnabled = true;
            this.itemsReturnCombo.Location = new System.Drawing.Point(137, 34);
            this.itemsReturnCombo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.itemsReturnCombo.Name = "itemsReturnCombo";
            this.itemsReturnCombo.Size = new System.Drawing.Size(295, 24);
            this.itemsReturnCombo.TabIndex = 6;
            // 
            // feedbackLbl
            // 
            this.feedbackLbl.AutoSize = true;
            this.feedbackLbl.Location = new System.Drawing.Point(137, 67);
            this.feedbackLbl.Name = "feedbackLbl";
            this.feedbackLbl.Size = new System.Drawing.Size(0, 17);
            this.feedbackLbl.TabIndex = 12;
            // 
            // ItemReturn
            // 
            this.AcceptButton = this.returnBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.backReturnBtn;
            this.ClientSize = new System.Drawing.Size(449, 146);
            this.Controls.Add(this.feedbackLbl);
            this.Controls.Add(this.backReturnBtn);
            this.Controls.Add(this.returnBtn);
            this.Controls.Add(this.itemReturnLbl);
            this.Controls.Add(this.itemsReturnCombo);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ItemReturn";
            this.Text = "Return Item";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backReturnBtn;
        private System.Windows.Forms.Button returnBtn;
        private System.Windows.Forms.Label itemReturnLbl;
        private System.Windows.Forms.ComboBox itemsReturnCombo;
        private System.Windows.Forms.Label feedbackLbl;
    }
}