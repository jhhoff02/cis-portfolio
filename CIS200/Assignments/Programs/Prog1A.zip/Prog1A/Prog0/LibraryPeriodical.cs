﻿// Program 1A
// CIS 200-01
// Grading ID: D4929
// Due: 2/15/2017

// File: LibraryPeriodical.cs
// This class serves as a derived class of LibraryItem, and a base class for LibraryJournal and LibraryMagazine. 
//It adds properties for Volume and Number to the hierarchy.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public abstract class LibraryPeriodical : LibraryItem
{
    private string _title;      // The item's title
    private string _publisher;  // The item's publisher
    private int _copyrightYear; // The item's year of copyright
    private int _loanPeriod; // The item's loan period
    private string _callNumber; // The item's call number in the library
    private int _volume; // The periodical's volume
    private int _number; // The periodical's number

    // Precondition:  theCopyrightYear >= 0, loanPeriod > 0, volume >= 1, number >= 1
    // Postcondition: The library item has been initialized with the specified
    //                values for title, publisher, copyright year, loan period,
    //                call number, volume, and number. The item is not checked out.
    public LibraryPeriodical(string theTitle, string thePublisher,
        int theCopyrightYear, int loanPeriod, string theCallNumber, int volume, int theNumber)
        :base(theTitle, thePublisher, theCopyrightYear, loanPeriod, theCallNumber)
    {
        Title = theTitle;
        Publisher = thePublisher;
        CopyrightYear = theCopyrightYear;
        LoanPeriod = loanPeriod;
        CallNumber = theCallNumber;
        Volume = volume;
        Number = theNumber;

        ReturnToShelf(); // Make sure item is not checked out
    }

    public int Volume
    {
        // Precondition:  None
        // Postcondition: The periodical volume has been returned
        get
        {
            return _volume;
        }

        // Precondition:  value >= 1
        // Postcondition: The periodical volume has been set to the specified value
        set
        {
            if (value >= 1)
                _volume = value;
            else
                throw new ArgumentOutOfRangeException($"{nameof(Volume)}", value,
                    $"{nameof(Volume)} must be >= 1");
        }
    }



        public int Number
    {
        // Precondition:  None
        // Postcondition: The periodical number has been returned
        get
        {
            return _number;
        }

        // Precondition:  value >= 1
        // Postcondition: The periodical number has been set to the specified value
        set
        {
            if (value >= 1)
                _number = value;
            else
                throw new ArgumentOutOfRangeException($"{nameof(Number)}", value,
                    $"{nameof(Number)} must be >= 1");
        }
    }

    // Precondition:  None
    // Postcondition: A string is returned presenting the periodical's data on
    //                separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut
        string checkedOutBy; // Holds checked out message

        if (IsCheckedOut())
            checkedOutBy = $"Checked Out By: {NL}{Patron}";
        else
            checkedOutBy = "Not Checked Out";

        return $"Title: {Title}{NL}Publisher: {Publisher}{NL}" +
            $"Copyright: {CopyrightYear:D4}{NL}LoanPeriod: {LoanPeriod}{NL}Volume: {Volume}{NL}Number: {Number}{NL}{checkedOutBy}";
    }
}
