﻿// Program 1A
// CIS 200-01
// Grading ID: D4929
// Due: 2/15/2017

// File: LibraryMagazine.cs
// This is a derived class of LibraryPeriodical.
//It doesn't add properties to the hierarchy, but it completes the CalcLateFee() method for magazines

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

    public class LibraryMagazine : LibraryPeriodical
    {
    public const decimal LATE_FEE = 0.25m; //Const decimal storing the late fee per day
    public const decimal FEE_LIMIT = 20.00m; //Const decimal storing the fee limit for magazines

    // Precondition:  theCopyrightYear >= 0, loanPeriod > 0, volume >= 1, number >= 1
    // Postcondition: The library item has been initialized with the specified
    //                values for title, publisher, copyright year, loan period,
    //                call number, volume, and number. The item is not checked out.
    public LibraryMagazine(string theTitle, string thePublisher,
        int theCopyrightYear, int loanPeriod, string theCallNumber, int volume, int theNumber)
        :base(theTitle, thePublisher, theCopyrightYear, loanPeriod, theCallNumber, volume, theNumber)
    {
        Title = theTitle;
        Publisher = thePublisher;
        CopyrightYear = theCopyrightYear;
        LoanPeriod = loanPeriod;
        CallNumber = theCallNumber;
        Volume = volume;
        Number = theNumber;

        ReturnToShelf(); // Make sure item is not checked out
    }

    // Precondition:  daysLate should be positive, but validation is performed
    // Postcondition: If daysLate is valid, a decimal late fee is returned. If not, an exception is thrown with error message
    public override decimal CalcLateFee(int daysLate)
    {
        if (daysLate > 0)
        {
            decimal calcedFee = daysLate * LATE_FEE; //temporary decimal variable to store calculated late fee
            return (calcedFee >= FEE_LIMIT)? FEE_LIMIT : calcedFee; //Conditional return, return calced fee if it is less than limit, otherwise return limit
        }
        else
        {
            throw new ArgumentOutOfRangeException($"{nameof(daysLate)}", daysLate,
                    $"{nameof(daysLate)} must be positive");
        }
    }

    // Precondition:  None
    // Postcondition: A string is returned presenting the periodical's data on
    //                separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut
        string checkedOutBy; // Holds checked out message

        if (IsCheckedOut())
            checkedOutBy = $"Checked Out By: {NL}{Patron}";
        else
            checkedOutBy = "Not Checked Out";

        return $"Title: {Title}{NL}Publisher: {Publisher}{NL}" +
            $"Copyright: {CopyrightYear:D4}{NL}LoanPeriod: {LoanPeriod}{NL}Volume: {Volume}{NL}Number: {Number}{NL}{checkedOutBy}";
    }
}
