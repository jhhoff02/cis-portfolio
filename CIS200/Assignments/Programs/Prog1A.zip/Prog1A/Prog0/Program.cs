﻿//// Program 1A
// CIS 200-01
// Grading ID: D4929
// Due: 2/15/2017

// File: Program.cs
// This file creates a simple test application class that creates
// a List of LibraryBook objects, some LibraryPatron objects, and tests them.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class Program
{
    // Precondition:  None
    // Postcondition: The LibraryItem and children have been tested
    public static void Main(string[] args)
    {   //LibraryBook objects//
        LibraryBook book1 = new LibraryBook("The Wright Guide to C#", "Andrew Wright", "UofL Press",
            2010, 1, "ZZ25 3G");  // 1st test book
        LibraryBook book2 = new LibraryBook("Harriet Pooter", "IP Thief", "Stealer Books",
            2000, 1, "AG773 ZF"); // 2nd test book
        LibraryBook book3 = new LibraryBook("The Color Mauve", "Mary Smith", "Beautiful Books Ltd.",
            1985, 1, "JJ438 4T"); // 3rd test book
        LibraryBook book4 = new LibraryBook("The Guan Guide to SQL", "Jeff Guan", "UofL Press",
            2017, 1, "ZZ24 4F");  // 4th test book
        LibraryBook book5 = new LibraryBook("    The Big Book of Doughnuts   ", "   Homer Simpson   ", "   Doh Books   ",
            2001, 1, "   AE842 7A   "); // 5th test book - Trims?

        //LibraryJournal objects//
        LibraryJournal journal1 = new LibraryJournal("The Wright Guide to C#", "Andrew Wright", 2010, 1, "ZZ25 3G", 1, 1, "Programming", "Jeff Guan"); //1st test journal
        LibraryJournal journal2 = new LibraryJournal("Harriet Pooter", "IP Thief", 2005, 1, "AG773 ZF", 1, 1, "IP", "Mrs. Editor"); //2nd test journal
        LibraryJournal journal3 = new LibraryJournal("The Guan Guide to SQL", "Jeff Guan", 2009, 1, "ZZ24 4F", 1, 1, "Databases", "Andrew Wright"); //3rd test journal

        //LibraryMagazine objects//
        LibraryMagazine magazine1 = new LibraryMagazine("The Guan Guide to SQL", "Jeff Guan", 2009, 1, "ZZ25 3G", 1, 1); //1st test magazine
        LibraryMagazine magazine2 = new LibraryMagazine("The Color Mauve", "Mary Smith", 2006, 1, "JJ438 4T", 1, 1); //2nd test magazine
        LibraryMagazine magazine3 = new LibraryMagazine("    The Big Book of Doughnuts   ", "Andrew Wright", 2005, 1, "   AE842 7A   ", 1, 1); //3rd test magazine

        //LibraryMovie objects//
        LibraryMovie movie1 = new LibraryMovie("The Color Mauve", "Mary Smith", 2004, 1, "ZZ25 3G", 100, "Andrew Wright", LibraryMediaItem.MediaType.BLURAY, LibraryMovie.MPAARatings.PG13); //1st test movie
        LibraryMovie movie2 = new LibraryMovie("The Guan Guide to SQL", "Andrew Wright", 2005, 1, "AG773 ZF", 200, "   Homer Simpson   ", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.G); //1st test movie
        LibraryMovie movie3 = new LibraryMovie("Harriet Pooter", "IP Thief", 2002, 1, " AE842 7A", 300, "Stealer Books", LibraryMediaItem.MediaType.VHS, LibraryMovie.MPAARatings.U); //1st test movie

        //LibraryMusic objects//
        LibraryMusic music1 = new LibraryMusic("The Color Mauve", "Homer Simpson", 2011, 1, "ZZ25 3G", 100, "IP Thief", LibraryMediaItem.MediaType.DVD, 10); //1st test movie
        LibraryMusic music2 = new LibraryMusic("The Guan Guide to SQL", "IP Thief", 2015, 2, "JJ438 4T", 150, "Andrew Wright", LibraryMediaItem.MediaType.VHS, 1); //2nd test movie
        LibraryMusic music3 = new LibraryMusic("The Wright Guide to C#", "Mary Smith", 2001, 5, "   AE842 7A   ", 170, "UofL Press", LibraryMediaItem.MediaType.BLURAY, 50); //3rd test movie

        //LibraryPatron objects//
        LibraryPatron patron1 = new LibraryPatron("Ima Reader", "123456"); // 1st test patron
        LibraryPatron patron2 = new LibraryPatron("Jane Doe", "112233");  // 2nd test patron
        LibraryPatron patron3 = new LibraryPatron("   John Smith   ", "   654321   "); // 3rd test patron - Trims?


        List<LibraryBook> theBooks = new List<LibraryBook>(); // Test list of books
        // Add books to the list
        theBooks.Add(book1);
        theBooks.Add(book2);
        theBooks.Add(book3);
        theBooks.Add(book4);
        theBooks.Add(book5);

        List<LibraryJournal> theJournals = new List<LibraryJournal>(); // Test list of journals
        // Add journals to the list
        theJournals.Add(journal1);
        theJournals.Add(journal2);
        theJournals.Add(journal3);

        List<LibraryMagazine> theMagazines = new List<LibraryMagazine>(); // Test list of magazines
        // Add magazines to the list
        theMagazines.Add(magazine1);
        theMagazines.Add(magazine2);
        theMagazines.Add(magazine3);

        List<LibraryMovie> theMovies = new List<LibraryMovie>(); // Test list of movies
        // Add movies to the list
        theMovies.Add(movie1);
        theMovies.Add(movie2);
        theMovies.Add(movie3);

        List<LibraryMusic> theMusic = new List<LibraryMusic>(); // Test list of music
        // Add music to the list
        theMusic.Add(music1);
        theMusic.Add(music2);
        theMusic.Add(music3);

//TEST BOOKS//
        Console.WriteLine("Original list of books");
        PrintBooks(theBooks);

        // Make changes
        book1.CheckOut(patron1);
        book2.Publisher = "Borrowed Books";
        book3.CheckOut(patron2);
        book4.CallNumber = "AB123 4A";
        book5.CheckOut(patron3);

        Console.WriteLine("After changes");
        PrintBooks(theBooks);

        // Return all the books
        for (int i = 0; i < theBooks.Count; ++i)
            theBooks[i].ReturnToShelf();

        Console.WriteLine("After returning the books");
        PrintBooks(theBooks);
//TEST JOURNALS//
        Console.WriteLine("Original list of journals");
        PrintJournals(theJournals);

        // Make changes
        journal1.CheckOut(patron1);
        journal2.Publisher = "Borrowed Journals";
        journal3.CheckOut(patron2);
        journal2.CallNumber = "AB123 4A";
        journal1.CheckOut(patron3);

        Console.WriteLine("After changes");
        PrintJournals(theJournals);

        // Return all the items
        for (int i = 0; i < theJournals.Count; ++i)
            theJournals[i].ReturnToShelf();

        Console.WriteLine("After returning the items");
        PrintJournals(theJournals);
//TEST MAGAZINES//
        Console.WriteLine("Original list of magazines");
        PrintMagazines(theMagazines);

        // Make changes
        magazine1.CheckOut(patron1);
        magazine2.Publisher = "Borrowed Magazines";
        magazine3.CheckOut(patron2);
        magazine2.CallNumber = "AB123 4A";
        magazine1.CheckOut(patron3);

        Console.WriteLine("After changes");
        PrintMagazines(theMagazines);

        // Return all the items
        for (int i = 0; i < theMagazines.Count; ++i)
            theMagazines[i].ReturnToShelf();

        Console.WriteLine("After returning the items");
        PrintMagazines(theMagazines);
//TEST MOVIES//
        Console.WriteLine("Original list of movies");
        PrintMovies(theMovies);

        // Make changes
        movie1.CheckOut(patron1);
        movie2.Publisher = "Borrowed Movies";
        movie3.CheckOut(patron2);
        movie2.CallNumber = "AB123 4A";
        movie1.CheckOut(patron3);

        Console.WriteLine("After changes");
        PrintMovies(theMovies);

        // Return all the items
        for (int i = 0; i < theMovies.Count; ++i)
            theMovies[i].ReturnToShelf();

        Console.WriteLine("After returning the items");
        PrintMovies(theMovies);
//TEST MUSIC//
        Console.WriteLine("Original list of music");
        PrintMusic(theMusic);

        // Make changes
        music1.CheckOut(patron1);
        music2.Publisher = "Borrowed Music";
        music3.CheckOut(patron2);
        music2.CallNumber = "AB123 4A";
        music1.CheckOut(patron3);

        Console.WriteLine("After changes");
        PrintMusic(theMusic);

        // Return all the items
        for (int i = 0; i < theMusic.Count; ++i)
            theMusic[i].ReturnToShelf();

        Console.WriteLine("After returning the items");
        PrintMusic(theMusic);
    }

    // Precondition:  None
    // Postcondition: The books have been printed to the console
    public static void PrintBooks(List<LibraryBook> books)
    {
        foreach (LibraryBook b in books)
        {
            Console.WriteLine(b);
            Console.WriteLine();
        }
    }
    // Precondition:  None
    // Postcondition: The journals have been printed to the console
    public static void PrintJournals(List<LibraryJournal> journals)
    {
        foreach (LibraryJournal j in journals)
        {
            Console.WriteLine(j);
            Console.WriteLine();
        }
    }
    // Precondition:  None
    // Postcondition: The magazines have been printed to the console
    public static void PrintMagazines(List<LibraryMagazine> magazines)
    {
        foreach (LibraryMagazine ma in magazines)
        {
            Console.WriteLine(ma);
            Console.WriteLine();
        }
    }
    // Precondition:  None
    // Postcondition: The movies have been printed to the console
    public static void PrintMovies(List<LibraryMovie> movies)
    {
        foreach (LibraryMovie mo in movies)
        {
            Console.WriteLine(mo);
            Console.WriteLine();
        }
    }
    // Precondition:  None
    // Postcondition: The music has been printed to the console
    public static void PrintMusic(List<LibraryMusic> music)
    {
        foreach (LibraryMusic mu in music)
        {
            Console.WriteLine(mu);
            Console.WriteLine();
        }
    }
}