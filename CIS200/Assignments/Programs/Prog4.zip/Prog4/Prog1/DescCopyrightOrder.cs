﻿// Program 4
// CIS 200-01
// Due: 4/19/2017
// Grading ID: D4929

// File: DescendingTimeOrder.cs

// This class provides an IComparer for the LibraryItem class
// that orders the objects descending by copyright year.
using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryItems
{
    public class DescCopyrightOrder : Comparer<LibraryItem>
    {
        // Precondition:  None
        // Postcondition: Sorts descending by copyright year
        //                When item1 < item2, method returns positive #
        //                When item1 == item2, method returns zero
        //                When item1 > item2 method returns negative #
        public override int Compare(LibraryItem item1, LibraryItem item2)
        {
            // Ensure correct handling of null values (in .NET, null less than anything)
            if (item1.CopyrightYear.ToString() == null && item2.CopyrightYear.ToString() == null) // Both null?
                return 0;                 // Equal

            if (item1.CopyrightYear.ToString() == null) // only copyright year 1 is null?
                return -1;  // null is less than any actual copyright year

            if (item2.CopyrightYear.ToString() == null) // only copyright year 2 is null?
                return 1;   // Any actual copyright year is greater than null

            return (-1) * item1.CopyrightYear.CompareTo(item2.CopyrightYear); // Reverses natural order, so descending
        }
    }
}
