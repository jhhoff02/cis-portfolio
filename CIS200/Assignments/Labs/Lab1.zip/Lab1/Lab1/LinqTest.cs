﻿// Lab 1
// Grading ID: D4929
// Due Date: 2/6/17
// Course Section: CIS 200-01

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab1
{
    public class LinqTest
    {
        public static void Main(string[] args)
        {
            const int LOW_TOTAL = 200; //int const for storing the low range of an invoice total
            const int HIGH_TOTAL = 500; //int const for storing the high range of an invoice total
            // initialize array of invoices
            Invoice[] invoices = { 
                new Invoice( 83, "Electric sander", 7, 57.98M ), 
                new Invoice( 24, "Power saw", 18, 99.99M ), 
                new Invoice( 7, "Sledge hammer", 11, 21.5M ), 
                new Invoice( 77, "Hammer", 76, 11.99M ), 
                new Invoice( 39, "Lawn mower", 3, 79.5M ), 
                new Invoice( 68, "Screwdriver", 106, 6.99M ), 
                new Invoice( 56, "Jig saw", 21, 11M ), 
                new Invoice( 3, "Wrench", 34, 7.5M ) };

            // Display original array
            Console.WriteLine("Original Invoice Data\n");
            Console.WriteLine("P.Num Part Description     Quant Price"); // Column Headers
            Console.WriteLine("----- -------------------- ----- ------");

            foreach (Invoice inv in invoices)
                Console.WriteLine(inv);
            Console.WriteLine("\n");

            // Part a, sort by PartDescription

            IEnumerable<Invoice> sortPartDescr = //LINQ result variable storing the results of sorting query as an Invoice iterable
                from invoice in invoices
                orderby invoice.PartDescription
                select invoice;

            // Display sorted array
            Console.WriteLine("Part A: Sort by PartDescription\n");
            Console.WriteLine("P.Num Part Description     Quant Price"); // Column Headers
            Console.WriteLine("----- -------------------- ----- ------");

            foreach (Invoice inv in sortPartDescr)
                Console.WriteLine(inv);
            Console.WriteLine("\n");

            // Part b, sort by Price

            IEnumerable<Invoice> sortPrice = //LINQ result variable storing the results of sorting query as an Invoice iterable
                from invoice in invoices
                orderby invoice.Price
                select invoice;

            // Display sorted array
            Console.WriteLine("Part B: Sort by Price\n");
            Console.WriteLine("P.Num Part Description     Quant Price"); // Column Headers
            Console.WriteLine("----- -------------------- ----- ------");

            foreach (Invoice inv in sortPrice)
                Console.WriteLine(inv);
            Console.WriteLine("\n");

            // Part c, select the PartDescription and Quantity and sort the results by Quantity.

            var sortQuantity = //LINQ result variable storing the results of sorting query as a 'var'
                from invoice in invoices
                orderby invoice.Quantity
                select new { PartDescription = invoice.PartDescription, Quantity = invoice.Quantity };

            // Display sorted array
            Console.WriteLine("Part C: Select PartDescription and Quantity, sort by Quantity\n");
            Console.WriteLine("Part Description     Quant"); // Column Headers
            Console.WriteLine("-------------------- -----");

            foreach (var item in sortQuantity)
                Console.WriteLine($"{item.PartDescription,-20} {item.Quantity,-5}");
            Console.WriteLine("\n");

            // Part d, select the PartDescription and Invoice value, sort by invoice value.

            var sortInvoice = //LINQ result variable storing the results of sorting query as a 'var'
                from invoice in invoices
                let total = invoice.Quantity * invoice.Price
                orderby total
                select new { PartDescription = invoice.PartDescription, InvoiceTotal = invoice.Quantity * invoice.Price };

            // Display sorted array with calculated field
            Console.WriteLine("Part D: Select PartDescription and Invoice value, sort by Invoice value\n");
            Console.WriteLine("Part Description     Invoice Total"); // Column Headers
            Console.WriteLine("-------------------- -------------");

            foreach (var item in sortInvoice)
                Console.WriteLine($"{item.PartDescription,-20} {item.InvoiceTotal,-5:C}");
            Console.WriteLine("\n");

            // Part e, select InvoiceTotal in the range $200-500 inclusive

            var filterInvoice = //LINQ result variable storing the results of filtering query as a 'var'
                from invResult in sortInvoice
                where (invResult.InvoiceTotal >= LOW_TOTAL) && (invResult.InvoiceTotal <= HIGH_TOTAL)
                select invResult;

            // Display filtered array using sortInvoice query
            Console.WriteLine("Part E: Select InvoiceTotal for $200-500\n");
            Console.WriteLine("Part Description     Invoice Total"); // Column Headers
            Console.WriteLine("-------------------- -------------");

            foreach (var item in filterInvoice)
                Console.WriteLine($"{item.PartDescription,-20} {item.InvoiceTotal,-5:C}");
            Console.WriteLine("\n");
        }
    }
}
